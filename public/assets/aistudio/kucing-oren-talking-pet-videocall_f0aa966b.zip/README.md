<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/4852f95a-560d-44a0-89af-59d7898a41c3

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev` (opens on http://localhost:3000)

## AI Chat Features (Memory Mode — added)
- **Multi-turn conversation memory**: the last 12 chat turns are sent to Gemini so each pet remembers what was said earlier in the session.
- **Persistent user memory**: say "nama saya X" / "panggil saya X" and the pet will remember your name (stored in `localStorage`, shared across all characters).
- **Chat history panel**: tap the chat icon (next to the text-input button) to open the full transcript. Tap any pet bubble to replay its voice; clear history from the header.
- **Quick-reply chips**: 6 one-tap prompts including a memory demo ("Nama saya Budi").
- Without `GEMINI_API_KEY`, a smart in-character fallback generator handles all replies (name-aware).

## Video Call Feature (added)
- Tap the orange **Video** button in the action bar to start a video call with the active character.
- The app requests **front-camera** permission (`facingMode: 'user'`). Your camera appears as a small picture-in-picture preview (mirrored).
- The character **sees your face via Gemini Vision** (`gemini-3.5-flash`) and comments on your appearance/expression in character:
  - **ZAYN (Kucing Oren)**: light-hearted roasts/teases (jutek, never mean — no sensitive attributes).
  - **HERU (Anjing Golden)**: over-the-top enthusiastic compliments.
  - **RIZKY (Burung Hantu)**: calm, philosophical observations.
- Auto-comment every 18s + manual **"ROAST AKU!"** button; replies are spoken aloud in the character's voice.
- If camera is denied/off, it falls back to text-only commentary (and local roast lines if the API is unreachable).
- `metadata.json` now requests both `microphone` and `camera` frame permissions.
