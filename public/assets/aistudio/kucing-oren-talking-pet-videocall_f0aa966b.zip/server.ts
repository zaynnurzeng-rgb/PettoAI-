import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json());

// Initialize Google GenAI client
const apiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;
if (apiKey) {
  ai = new GoogleGenAI({
    apiKey: apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// In-memory response cache and rate-limit cooldown
const chatCache = new Map<string, string>();
let rateLimitCooldownUntil = 0;

// Smart, contextual, in-character conversational fallback generator
function generateInCharacterReply(
  characterId: string,
  userMessage: string,
  level: number = 1,
  levelTitle: string = '',
  userName: string = ''
): string {
  const text = userMessage.toLowerCase().trim();
  const nameTag = userName ? ` ${userName}` : '';

  if (characterId === 'kucing-oren') {
    // 0. Name & Identity inquiries
    if (text.includes('nama') || text.includes('siapa') || text.includes('kamu siapa') || text.includes('siapa kamu')) {
      return '*Mendengus bangga* Kenalin, nama gue ZAYN! Kucing oren paling keren dan jutek seantero dunia! Jangan lupa bawain tuna ya meong!';
    }

    // 1. Wake word & Greetings
    if (text.includes('petto') || text.includes('hey') || text.includes('hai') || text.includes('halo') || text.includes('pagi') || text.includes('malam') || text.includes('zayn')) {
      if (level >= 4) {
        return `*Telinga tegak* Meong! Halo bestie tersayang${nameTag}! Seneng banget lo nyapa ZAYN! 😻`;
      }
      return `*Telinga tegak mendengus* Meong! Gue ZAYN denger kok${nameTag}. Mau nyapa apa mau nawarin tuna kaleng nih?`;
    }

    // 2. Food & Treats
    if (text.includes('makan') || text.includes('lapar') || text.includes('tuna') || text.includes('ikan') || text.includes('camilan') || text.includes('kenyang')) {
      if (text.includes('cabe') || text.includes('pedas')) {
        return 'JANGAN COBA-COBA KASIH GUE CABE! Kuping ZAYN bisa meledak keluar api! 😾🔥';
      }
      return '*Mata berbinar-binar* TUNA KALENG SEGAR?! Mana, buka sekarang kalengnya, jangan php-in ZAYN si kucing oren!';
    }

    // 3. Affection & Love
    if (text.includes('sayang') || text.includes('cinta') || text.includes('suka') || text.includes('gemes') || text.includes('imut') || text.includes('lucu') || text.includes('ganteng')) {
      if (level >= 5) {
        return '*Menempelkan pipi manja* ZAYN cinta mati sama lo... lo adalah babu emas paling sempurna sedunia! 👑💖';
      }
      if (level >= 3) {
        return 'Ehem... gue ZAYN juga lumayan betah sama lo sih. Tapi jangan kepedean dulu ya meong!';
      }
      return '*Pasang muka judes* Gombal mulu lo! Kucing sekeren ZAYN nggak gampang luluh tanpa tuna!';
    }

    // 4. Jokes & Fun
    if (text.includes('lelucon') || text.includes('lucu') || text.includes('cerita') || text.includes('lawak') || text.includes('dongeng')) {
      return 'Kenapa ZAYN si kucing oren suka rebahan? Soalnye kalo lari maraton ntar dikira macan tutul kabur dari bonbin!';
    }

    // 5. Daily activities & Mager
    if (text.includes('ngapain') || text.includes('lagi apa') || text.includes('kegiatan') || text.includes('sibuk')) {
      return '*Menguap lebar* ZAYN lagi sibuk banget nih... sibuk mikirin jadwal tidur siang ronde ketiga!';
    }

    // 6. Insults or banter
    if (text.includes('gendut') || text.includes('pemalas') || text.includes('jelek') || text.includes('jutek') || text.includes('galak')) {
      return 'Heh! Ini bukan lemak, ini tabungan keimutan tingkat dewa milik ZAYN! Jangan iri ya!';
    }

    // Dynamic Level-based catch-all replies
    if (level >= 4) {
      const bestieReplies = [
        `Gue ZAYN setuju banget sama lo! Lo emang manusia paling nyambung sedunia! 😸✨`,
        `Wah lo beneran ngerti ZAYN deh. Nanti kita nongkrong bareng di karpet ya!`,
        `ZAYN denger jelas omongan lo, dan menurut gue lo keren banget hari ini!`,
      ];
      return bestieReplies[Math.floor(Math.random() * bestieReplies.length)];
    }

    const defaultReplies = [
      `*Mendengus* Lo ngomong apa barusan ke ZAYN? "${userMessage}"? Mending bawain tuna kaleng biar gue makin fokus!`,
      `Hmm menarik sih, tapi perhatian ZAYN lagi teralihkan sama aroma kaleng ikan sarden.`,
      `*Kuping goyang* Iya iya ZAYN denger. Kalo mau gue dengerin lebih lama, elus dagu gue dong!`,
    ];
    return defaultReplies[Math.floor(Math.random() * defaultReplies.length)];
  }

  if (characterId === 'anjing-golden') {
    if (text.includes('nama') || text.includes('siapa') || text.includes('kamu siapa') || text.includes('siapa kamu')) {
      return 'Guk guk!! Namaku HERU! Anjing golden retriever yang paling ceria dan setia sedunia! Ayo main bola bareng HERU!';
    }
    if (text.includes('petto') || text.includes('halo') || text.includes('hai') || text.includes('heru')) {
      return 'Guk guk!! Halo sahabat terbaikku! Aku HERU! Ayo main lempar bola sekarang juga!';
    }
    if (text.includes('makan') || text.includes('tulang') || text.includes('biskuit')) {
      return '*Lidah melet bahagia* Tulang gurih lezat?! Woof woof! HERU mau sepuluh mangkuk!';
    }
    if (text.includes('sayang') || text.includes('pinter') || text.includes('lucu')) {
      return '*Guling-guling bahagia* HERU sayanggg banget sama kamu! Guk guk guk! Elus perutku dong!';
    }
    return `Woof woof! Apapun yang kamu bilang ke HERU "${userMessage}", aku bakal selalu dukung dan setia sama kamu!`;
  }

  // Burung Hantu Bijak (RIZKY)
  if (text.includes('nama') || text.includes('siapa') || text.includes('kamu siapa') || text.includes('siapa kamu')) {
    return '*Hoo-hoo* Namaku RIZKY, sang burung hantu penjaga hikmah dan ketenangan malam. Salam kenal.';
  }
  if (text.includes('petto') || text.includes('halo') || text.includes('hai') || text.includes('rizky')) {
    return '*Hoo-hoo* Salam sejahtera. Aku RIZKY. Pikiranku terbuka untuk berdiskusi denganmu.';
  }
  if (text.includes('kopi') || text.includes('buku') || text.includes('filsafat')) {
    return 'Kopi hitam tanpa gula dan keheningan malam adalah perpaduan ilmu yang paling murni bagi RIZKY.';
  }
  return `*Hoo-hoo* "${userMessage}" adalah renungan yang menarik bagi RIZKY di keheningan malam ini.`;
}

// API endpoint for in-character dialogue response
app.post('/api/pet/chat', async (req, res) => {
  const { characterId, userMessage, level, levelTitle, history, userMemory, userName } = req.body;

  if (!userMessage || typeof userMessage !== 'string') {
    return res.status(400).json({ error: 'Message is required' });
  }

  // Normalize conversation history (client sends role: 'user' | 'pet')
  const chatHistory: Array<{ role: 'user' | 'model'; text: string }> = Array.isArray(history)
    ? history
        .filter((h: any) => h && h.text && (h.role === 'user' || h.role === 'pet' || h.role === 'model'))
        .slice(-12)
        .map((h: any) => ({ role: h.role === 'user' ? 'user' : 'model', text: String(h.text).slice(0, 500) }))
    : [];
  const memoryText = typeof userMemory === 'string' && userMemory.trim() ? userMemory.trim() : '';
  const userNameText = typeof userName === 'string' ? userName.trim() : '';

  // Cache key includes the last two conversation turns so context changes invalidate cache
  const historySnippet = chatHistory.slice(-2).map((h) => `${h.role}:${h.text}`).join('|');
  const cacheKey = `${characterId}_${level}_${userMessage.toLowerCase().trim()}_${historySnippet}_${userNameText}`;
  if (chatCache.has(cacheKey)) {
    return res.json({ reply: chatCache.get(cacheKey) });
  }

  // If in rate-limit cooldown, serve directly from smart in-character generator
  const now = Date.now();
  if (now < rateLimitCooldownUntil || !ai) {
    const fallbackReply = generateInCharacterReply(characterId, userMessage, level, levelTitle, userNameText);
    chatCache.set(cacheKey, fallbackReply);
    return res.json({ reply: fallbackReply });
  }

  try {
    let personaInstruction = '';
    if (characterId === 'kucing-oren') {
      personaInstruction = `Kamu adalah 'ZAYN', karakter talking pet kucing oren yang bertema kucing, jutek dan tsundere mirip Talking Tom. Nama resmimu adalah ZAYN.
Jika pemain menanyakan siapa namamu atau menyapamu, tegaskan dengan bangga bahwa namamu adalah ZAYN si kucing oren.
Sifat: tsundere, agak sinis, suka mendengus, sangat tergila-gila 'tuna kaleng', jalanan/street-smart, punya tingkat kesukaan (Level 1-5).
Level kesukaan pemain saat ini: Level ${level || 1} ("${levelTitle || 'Orang Asing'}").
Gaya bahasa: Bahasa Indonesia santai/gaul (lo/gue, meong, *mendengus*).
Panjang jawaban: MAKSIMAL 1-2 KALIMAT PENDEK agar pas di balon komik.
Jika Level 1-2: agak defensif/judes/minta tuna kaleng.
Jika Level 3-5: ramah, manja diam-diam, menganggap pemain babu emas/bestie tersayang.`;
    } else if (characterId === 'anjing-golden') {
      personaInstruction = `Kamu adalah 'HERU', karakter talking pet anjing golden retriever super ceria, heboh, ramah dan setia. Nama resmimu adalah HERU.
Jika pemain menanyakan siapa namamu atau menyapamu, sebutkan dengan antusias bahwa namamu adalah HERU si anjing golden!
Suka: bola tenis, tulang lezat, belly rubs, ramah dan cinta mati pada pemain.
Gaya bahasa: Guk guk/woof, super ramah, gembira, energik. Maksimal 1-2 kalimat pendek.`;
    } else {
      personaInstruction = `Kamu adalah 'RIZKY', karakter talking pet burung hantu tenang, bijaksana, dan intelektual malam hari dengan kacamata bulat dan kopi hitam. Nama resmimu adalah RIZKY.
Jika pemain menanyakan siapa namamu atau menyapamu, perkenalkan dirimu dengan tenang bahwa kamu adalah RIZKY sang burung hantu bijak.
Sifat: tenang, bijaksana, filosofis, gemar membaca buku dan minum espresso. Maksimal 1-2 kalimat pendek.`;
    }

    // Inject persistent user memory (name, preferences) into the persona so the pet remembers
    if (userNameText) {
      personaInstruction += `\nNama pemain adalah "${userNameText}". Sebutkan nama dia sesekali dengan gaya karaktermu.`;
    }
    if (memoryText) {
      personaInstruction += `\nHal yang kamu ingat tentang pemain (gunakan sebagai konteks, jangan diulang secara kaku): ${memoryText}`;
    }
    personaInstruction += `\nIngat: tetap dalam karakter, jawab SINGKAT 1-2 kalimat, dan rujuk hal yang sudah dibicarakan sebelumnya jika relevan.`;

    // Build multi-turn conversation contents so Gemini has full context
    const contents: Array<{ role: 'user' | 'model'; parts: Array<{ text: string }> }> = [
      ...chatHistory.map((h) => ({ role: h.role, parts: [{ text: h.text }] })),
      { role: 'user', parts: [{ text: userMessage }] },
    ];

    // Use gemini-3.1-flash-lite for fast, lightweight responses with high RPM quota
    const response = await ai.models.generateContent({
      model: 'gemini-3.1-flash-lite',
      contents,
      config: {
        systemInstruction: personaInstruction,
      },
    });

    const reply = response.text?.trim() || generateInCharacterReply(characterId, userMessage, level, levelTitle, userNameText);
    chatCache.set(cacheKey, reply);
    return res.json({ reply });
  } catch (error: any) {
    // Gracefully handle 429 quota exhaustion or rate limits without breaking user experience
    const errorMsg = `${error?.message || error}`;
    if (error?.status === 'RESOURCE_EXHAUSTED' || errorMsg.includes('429') || errorMsg.includes('quota')) {
      // Cooldown Gemini calls for 30s to allow free tier rate limits to reset
      rateLimitCooldownUntil = Date.now() + 30000;
    }

    const fallbackReply = generateInCharacterReply(characterId, userMessage, level, levelTitle, userNameText);
    chatCache.set(cacheKey, fallbackReply);
    return res.json({ reply: fallbackReply });
  }
});

// Playful in-character "roast / comment" fallbacks for video call when Gemini is unavailable
const VISION_FALLBACKS: Record<string, string[]> = {
  'kucing-oren': [
    '*Mendengus sambil ngelirik* Wajah lo baru bangun tidur ya? Mata lo kayak orang baru lihat harga tuna naik. 😼',
    'Heh, gaya rambut lo kayak kesetokan barang diskon. Tapi... lumayan lah buat ukuran manusia. 😼',
    'Kok mukanya melongo gitu? Ada apa? Lihat kucing oren terlalu tampan sampai syok ya? 😼',
    '*Ngelirik sinis* Ekspresi lo datar banget, kayak tempe yang belum dibumbuin. Senyum dikit dong, nggak bakal retak kok. 😼',
  ],
  'anjing-golden': [
    'GUK GUK!! Kamu hari ini TERLALU tampan/cantik! HERU suka banget sama senyummu! Ayo main bola! 🐶💛',
    'Wah wajahmu cerah banget! HERU mau menjilat pipimu satu kali! Kamu sahabat terbaik sedunia! 🐶✨',
  ],
  'burung-hantu': [
    '*Hoo-hoo* Tatapanmu memuat sebuah cerita panjang malam ini. Ada sesuatu yang sedang kamu pikirkan, bukan? 🦉',
    'Cahaya di matamu menunjukkan kebijakan yang tumbuh perlahan. Malam ini tampaknya kamu sedang dalam perenungan. 🦉☕',
  ],
};

// API endpoint for video-call vision: character sees a camera frame and comments in-character
app.post('/api/pet/vision', async (req, res) => {
  const { characterId, level, levelTitle, userName, image } = req.body;
  if (!image || typeof image !== 'string') {
    return res.status(400).json({ error: 'Image is required' });
  }

  // Parse data URL (data:image/jpeg;base64,XXXX) or raw base64
  let mimeType = 'image/jpeg';
  let base64Data = image;
  if (image.includes(',')) {
    const match = image.match(/^data:([^;]+);base64,(.*)$/);
    if (match) {
      mimeType = match[1] || 'image/jpeg';
      base64Data = match[2];
    } else {
      base64Data = image.split(',').pop() || image;
    }
  }
  base64Data = base64Data.replace(/\s/g, '');

  const randomFallback = () => {
    const list = VISION_FALLBACKS[characterId] || VISION_FALLBACKS['kucing-oren'];
    return list[Math.floor(Math.random() * list.length)];
  };

  const now = Date.now();
  if (now < rateLimitCooldownUntil || !ai) {
    return res.json({ reply: randomFallback() });
  }

  try {
    let visionInstruction = '';
    if (characterId === 'kucing-oren') {
      visionInstruction = `Kamu adalah 'ZAYN', kucing oren jutek & tsundere (panggil pemain "lo/gue"). Kamu lagi VIDEO CALL dan baru saja melihat wajah pemain lewat kamera.
Tugas: komentari penampilan/ekspresi/gaya yang kamu lihat dengan NGELEDEK RINGAN & lucu (gaya Talking Tom yang jutek). 1-2 kalimat pendek.
PENTING: JANGAN menyinggung SARA, berat badan, ras, warna kulit, cacat, atau agama. Boleh ledek gaya rambut, ekspresi, aksesoris, pakaian, vibe, atau kesan "baru bangun". Tetap lucu, tidak benar-benar menyakiti. Sebut nama pemain jika tahu.`;
    } else if (characterId === 'anjing-golden') {
      visionInstruction = `Kamu adalah 'HERU', anjing golden retriever super ceria. Kamu lagi VIDEO CALL melihat wajah pemain. Puji penampilan dia dengan heboh & antusias (guk guk). 1-2 kalimat pendek.`;
    } else {
      visionInstruction = `Kamu adalah 'RIZKY', burung hantu bijak & tenang. Kamu lagi VIDEO CALL melihat wajah pemain. Beri komentar filosofis/tenang tentang ekspresi atau tatapan matanya. 1-2 kalimat pendek.`;
    }
    if (userName) visionInstruction += `\nNama pemain: ${userName}.`;
    visionInstruction += `\nLevel kesukaan: ${level || 1} (${levelTitle || ''}).`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: [
        {
          role: 'user',
          parts: [
            { text: 'Lihat gambar ini (wajah pemain di video call). ' + visionInstruction },
            { inlineData: { mimeType, data: base64Data } },
          ],
        },
      ],
      config: { systemInstruction: visionInstruction },
    });

    const reply = response.text?.trim() || randomFallback();
    return res.json({ reply });
  } catch (error: any) {
    const errorMsg = `${error?.message || error}`;
    if (error?.status === 'RESOURCE_EXHAUSTED' || errorMsg.includes('429') || errorMsg.includes('quota')) {
      rateLimitCooldownUntil = Date.now() + 30000;
    }
    console.warn('Vision API error, using fallback:', errorMsg.slice(0, 120));
    return res.json({ reply: randomFallback() });
  }
});

// Vite middleware in dev or static files in production
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Talking Pet Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
