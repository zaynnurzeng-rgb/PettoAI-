import React from 'react';
import { Heart, Sparkles } from 'lucide-react';

interface AffectionBarProps {
  level: number;
  xp: number;
  levelTitle: string;
  characterName: string;
  onOpenLevelGuide?: () => void;
}

export const AffectionBar: React.FC<AffectionBarProps> = ({
  level,
  xp,
  levelTitle,
  characterName,
  onOpenLevelGuide,
}) => {
  const percentage = Math.min(100, Math.max(0, xp));

  return (
    <div className="w-[92%] mx-auto mb-2 z-20 select-none">
      <div
        onClick={onOpenLevelGuide}
        className="bg-white/85 backdrop-blur-md rounded-2xl p-2.5 px-3 border border-white/80 shadow-sm cursor-pointer hover:bg-white/95 transition-all"
        title="Klik untuk melihat status kesukaan karakter"
      >
        <div className="flex items-center justify-between mb-1">
          <div className="flex items-center gap-1.5">
            <span className="flex items-center justify-center w-6 h-6 rounded-full bg-rose-500 text-white font-black text-xs shadow-sm">
              <Heart className="w-3.5 h-3.5 fill-white" />
            </span>
            <span className="text-xs font-black text-neutral-800">
              Lv. {level} <span className="font-normal text-neutral-500">· {levelTitle}</span>
            </span>
          </div>

          <div className="flex items-center gap-1 text-[11px] font-bold text-rose-600 tabular-nums">
            <Sparkles className="w-3 h-3" />
            <span>{xp}/100 XP</span>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="w-full h-2.5 bg-neutral-200/80 rounded-full overflow-hidden p-0.5 shadow-inner">
          <div
            className="h-full bg-gradient-to-r from-rose-400 via-pink-500 to-rose-600 rounded-full transition-all duration-500 shadow-sm"
            style={{ width: `${percentage}%` }}
          />
        </div>
      </div>
    </div>
  );
};
