import React from 'react';
import { Hand, Fish, Shirt, Gamepad2, Video } from 'lucide-react';
interface ActionBarProps {
  onOpenTouchGuide: () => void;
  onOpenFood: () => void;
  onOpenWardrobe: () => void;
  onOpenMiniGame: () => void;
  onOpenVideoCall: () => void;
  activeDrawer: string | null;
}
export const ActionBar: React.FC<ActionBarProps> = ({
  onOpenTouchGuide,
  onOpenFood,
  onOpenWardrobe,
  onOpenMiniGame,
  onOpenVideoCall,
  activeDrawer,
}) => {
  return (
    <div className="relative z-30 mx-auto w-fit mb-3 select-none">
      {/* Rounded White Island Container matching user screenshot */}
      <div className="bg-white/95 backdrop-blur-md rounded-full px-3 py-2 shadow-[0_8px_20px_rgba(0,0,0,0.12)] border border-white/80 flex items-center gap-2.5">
        {/* Button 1: Hand / Petting (Pink/Red circle) */}
        <button
          type="button"
          onClick={onOpenTouchGuide}
          className={`w-11 h-11 rounded-full flex items-center justify-center transition-transform active:scale-90 shadow-md ${
            activeDrawer === 'touch'
              ? 'bg-rose-600 text-white ring-4 ring-rose-200 scale-105'
              : 'bg-[#FF4D6D] hover:bg-[#F43F5E] text-white'
          }`}
          title="Petting & Interaksi Tubuh"
        >
          <Hand className="w-5 h-5" />
        </button>
        {/* Button 2: Fish / Food (Teal/Green circle) */}
        <button
          type="button"
          onClick={onOpenFood}
          className={`w-11 h-11 rounded-full flex items-center justify-center transition-transform active:scale-90 shadow-md ${
            activeDrawer === 'food'
              ? 'bg-emerald-600 text-white ring-4 ring-emerald-200 scale-105'
              : 'bg-[#2DD4BF] hover:bg-[#14B8A6] text-white'
          }`}
          title="Beri Makan Favorit"
        >
          <Fish className="w-5 h-5" />
        </button>
        {/* Button 3: Shirt / Wardrobe (Blue circle) */}
        <button
          type="button"
          onClick={onOpenWardrobe}
          className={`w-11 h-11 rounded-full flex items-center justify-center transition-transform active:scale-90 shadow-md ${
            activeDrawer === 'wardrobe'
              ? 'bg-blue-600 text-white ring-4 ring-blue-200 scale-105'
              : 'bg-[#38BDF8] hover:bg-[#0284C7] text-white'
          }`}
          title="Ganti Baju & Aksesoris"
        >
          <Shirt className="w-5 h-5" />
        </button>
        {/* Button 4: Gamepad / Toy (Purple circle for Mini-game fun) */}
        <button
          type="button"
          onClick={onOpenMiniGame}
          className={`w-11 h-11 rounded-full flex items-center justify-center transition-transform active:scale-90 shadow-md ${
            activeDrawer === 'minigame'
              ? 'bg-purple-600 text-white ring-4 ring-purple-200 scale-105'
              : 'bg-[#A855F7] hover:bg-[#9333EA] text-white'
          }`}
          title="Main Mini Game Tangkap Makanan"
        >
          <Gamepad2 className="w-5 h-5" />
        </button>
        {/* Button 5: Video Call (Orange circle) */}
        <button
          type="button"
          onClick={onOpenVideoCall}
          className="w-11 h-11 rounded-full flex items-center justify-center transition-transform active:scale-90 shadow-md bg-gradient-to-br from-orange-400 to-rose-500 hover:brightness-110 text-white ring-2 ring-orange-200"
          title="Video Call dengan Karakter (AI melihat wajahmu)"
        >
          <Video className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
};
