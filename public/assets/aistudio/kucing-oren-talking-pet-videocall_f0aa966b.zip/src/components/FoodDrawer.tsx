import React from 'react';
import { X, Sparkles, AlertTriangle } from 'lucide-react';
import { FOOD_ITEMS } from '../data/characters';
import { FoodItem, CharacterId } from '../types/game';

interface FoodDrawerProps {
  characterId: CharacterId;
  userLevel: number;
  onFeed: (food: FoodItem) => void;
  onClose: () => void;
}

export const FoodDrawer: React.FC<FoodDrawerProps> = ({
  characterId,
  userLevel,
  onFeed,
  onClose,
}) => {
  return (
    <div className="absolute inset-x-0 bottom-0 z-50 bg-white/95 backdrop-blur-md rounded-t-3xl p-4 shadow-2xl border-t-2 border-amber-300 max-h-[80%] overflow-y-auto animate-in slide-in-from-bottom duration-300 select-none">
      <div className="w-12 h-1 bg-neutral-300 rounded-full mx-auto mb-3" />

      <div className="flex items-center justify-between mb-3">
        <div>
          <h3 className="text-base font-extrabold text-neutral-900">Pilih Makanan Favorit 🍽️</h3>
          <p className="text-xs text-neutral-500">
            Beri makan untuk menambah rasa sayang & XP pertemanan
          </p>
        </div>
        <button
          type="button"
          onClick={onClose}
          className="w-8 h-8 rounded-full bg-neutral-100 hover:bg-neutral-200 flex items-center justify-center text-neutral-600"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Grid of Food Items */}
      <div className="grid grid-cols-2 gap-2.5">
        {FOOD_ITEMS.map((food) => {
          const isLocked = food.minLevel ? food.minLevel > userLevel : false;
          const isFav =
            (characterId === 'kucing-oren' && food.id === 'tuna-kaleng') ||
            (characterId === 'anjing-golden' && food.id === 'tulang-lezat') ||
            (characterId === 'burung-hantu' && food.id === 'kopi-hitam');

          return (
            <button
              key={food.id}
              type="button"
              disabled={isLocked}
              onClick={() => {
                if (!isLocked) {
                  onFeed(food);
                }
              }}
              className={`relative p-3 rounded-2xl text-left border transition-all ${
                isLocked
                  ? 'bg-neutral-100 opacity-60 border-neutral-200 cursor-not-allowed'
                  : 'bg-white hover:bg-amber-50/60 border-neutral-200 hover:border-amber-300 shadow-sm active:scale-95'
              }`}
            >
              {/* Food Emoji & Badge */}
              <div className="flex items-center justify-between mb-1.5">
                <span className="text-3xl drop-shadow-sm">{food.emoji}</span>
                {isFav && (
                  <span className="text-[10px] font-extrabold bg-amber-100 text-amber-800 px-1.5 py-0.5 rounded-full flex items-center gap-0.5">
                    <Sparkles className="w-2.5 h-2.5 text-amber-600" />
                    Favorit!
                  </span>
                )}
                {food.id === 'cabe-rawit' && (
                  <span className="text-[10px] font-extrabold bg-rose-100 text-rose-800 px-1.5 py-0.5 rounded-full flex items-center gap-0.5">
                    <AlertTriangle className="w-2.5 h-2.5 text-rose-600" />
                    Jahil!
                  </span>
                )}
              </div>

              <div className="font-extrabold text-xs text-neutral-800 leading-tight">
                {food.name}
              </div>
              <div className="text-[11px] text-neutral-500 line-clamp-1 mt-0.5">
                {food.description}
              </div>

              <div className="mt-2 flex items-center justify-between">
                <span className="text-[11px] font-black text-rose-600">
                  +{food.xpGain} XP
                </span>
                {isLocked && (
                  <span className="text-[10px] font-bold text-neutral-400">
                    Buka Lv. {food.minLevel}
                  </span>
                )}
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
