import React, { useState, useEffect, useRef } from 'react';
import { Mic, MicOff, MessageSquare, Send, Sparkles, Radio, Volume2, ShieldCheck, AlertCircle, Ear, MessageCircle, RefreshCw, MessagesSquare } from 'lucide-react';
import { sound, speakInTomVoice } from '../utils/audio';
import { speech } from '../utils/speech';
import { CharacterId, ChatMessage } from '../types/game';
import { CHARACTERS } from '../data/characters';
import { ChatHistoryPanel } from './ChatHistoryPanel';

interface MicrophoneButtonProps {
  characterId: CharacterId;
  userLevel: number;
  levelTitle: string;
  isTalking?: boolean;
  onTalkingStart: () => void;
  onTalkingEnd: () => void;
  onNewDialogue: (line: string) => void;
  onAddXp: (amount: number) => void;
  onWakeWordTriggered?: () => void;
}

export const MicrophoneButton: React.FC<MicrophoneButtonProps> = ({
  characterId,
  userLevel,
  levelTitle,
  isTalking = false,
  onTalkingStart,
  onTalkingEnd,
  onNewDialogue,
  onAddXp,
  onWakeWordTriggered,
}) => {
  const [isRecording, setIsRecording] = useState(false);
  const [mode, setMode] = useState<'ai_chat' | 'mimic'>('ai_chat');
  const [isHandsFreeActive, setIsHandsFreeActive] = useState(true); // Continuous conversation loop!
  const [showTextInput, setShowTextInput] = useState(false);
  const [customText, setCustomText] = useState('');
  const [liveTranscript, setLiveTranscript] = useState('');
  const [isWakeWordActive, setIsWakeWordActive] = useState(false);
  const [wakeWordAlert, setWakeWordAlert] = useState<string | null>(null);
  const [wakeHeardText, setWakeHeardText] = useState<string>('');
  const [permissionStatus, setPermissionStatus] = useState<'prompt' | 'granted' | 'denied'>('prompt');
  const [showPermissionBanner, setShowPermissionBanner] = useState(false);

  // ===== AI Chat Memory (multi-turn + persistent user profile) =====
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>(() => {
    try {
      const saved = localStorage.getItem(`talking_pet_chat_${characterId}_v1`);
      if (saved) return JSON.parse(saved);
    } catch (_) {}
    return [];
  });
  const [showChatHistory, setShowChatHistory] = useState(false);
  const [userName, setUserName] = useState<string>(() => {
    try {
      const saved = localStorage.getItem('talking_pet_user_memory_v1');
      if (saved) return JSON.parse(saved)?.name || '';
    } catch (_) {}
    return '';
  });
  const [userFacts, setUserFacts] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('talking_pet_user_memory_v1');
      if (saved) return JSON.parse(saved)?.facts || [];
    } catch (_) {}
    return [];
  });
  const chatHistoryRef = useRef<ChatMessage[]>(chatHistory);
  const userNameRef = useRef<string>(userName);
  const userFactsRef = useRef<string[]>(userFacts);

  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const silenceTimerRef = useRef<any>(null);
  const latestTranscriptRef = useRef<string>('');
  const noSpeechTimeoutRef = useRef<any>(null);
  const wakeWordClearTimeoutRef = useRef<any>(null);
  const isSpeakingRef = useRef(false);

  useEffect(() => {
    isSpeakingRef.current = isTalking;
  }, [isTalking]);

  // Keep refs in sync for async access inside sendToAiChatAndSpeak
  useEffect(() => { chatHistoryRef.current = chatHistory; }, [chatHistory]);
  useEffect(() => { userNameRef.current = userName; }, [userName]);
  useEffect(() => { userFactsRef.current = userFacts; }, [userFacts]);

  // Persist chat history per character
  useEffect(() => {
    try {
      localStorage.setItem(`talking_pet_chat_${characterId}_v1`, JSON.stringify(chatHistory.slice(-100)));
    } catch (_) {}
  }, [chatHistory, characterId]);

  // Persist user memory (name + facts) shared across all characters
  useEffect(() => {
    try {
      localStorage.setItem('talking_pet_user_memory_v1', JSON.stringify({ name: userName, facts: userFacts }));
    } catch (_) {}
  }, [userName, userFacts]);

  // Reload chat history when switching characters
  useEffect(() => {
    try {
      const saved = localStorage.getItem(`talking_pet_chat_${characterId}_v1`);
      setChatHistory(saved ? JSON.parse(saved) : []);
    } catch (_) {
      setChatHistory([]);
    }
    setShowChatHistory(false);
  }, [characterId]);

  // Detect user name from message ("nama saya X", "panggil saya X", "aku adalah X")
  const extractUserName = (text: string): string | null => {
    const patterns = [
      /nama\s+saya\s+adalah\s+([A-Za-z0-9]{2,20})/i,
      /nama\s+saya\s+([A-Za-z0-9]{2,20})/i,
      /panggil\s+saya\s+([A-Za-z0-9]{2,20})/i,
      /saya\s+bernama\s+([A-Za-z0-9]{2,20})/i,
      /aku\s+adalah\s+([A-Za-z0-9]{2,20})/i,
      /namaku\s+([A-Za-z0-9]{2,20})/i,
    ];
    for (const re of patterns) {
      const m = text.match(re);
      if (m && m[1]) {
        const name = m[1].trim();
        if (!['gue','gwe','gw','saya','aku','kamu','lo','lu','nya'].includes(name.toLowerCase())) {
          return name.charAt(0).toUpperCase() + name.slice(1);
        }
      }
    }
    return null;
  };

  // Build a compact memory string sent to Gemini
  const buildUserMemory = (): string => {
    const parts: string[] = [];
    if (userNameRef.current) parts.push(`Nama pemain: ${userNameRef.current}.`);
    if (userFactsRef.current.length) parts.push(`Fakta tentang pemain: ${userFactsRef.current.join(', ')}.`);
    return parts.join(' ');
  };

  // Append a message to chat history (functional, safe for async)
  const pushChatMessage = (role: 'user' | 'pet', text: string) => {
    const entry: ChatMessage = { role, text, ts: Date.now() };
    setChatHistory((prev) => [...prev.slice(-99), entry]);
  };

  // Check initial permission status if supported
  useEffect(() => {
    if (navigator.permissions && navigator.permissions.query) {
      navigator.permissions
        .query({ name: 'microphone' as PermissionName })
        .then((permission) => {
          setPermissionStatus(permission.state as 'prompt' | 'granted' | 'denied');
          if (permission.state === 'granted') {
            startWakeWordSystem();
          }
          permission.onchange = () => {
            setPermissionStatus(permission.state as 'prompt' | 'granted' | 'denied');
            if (permission.state === 'granted') {
              startWakeWordSystem();
            }
          };
        })
        .catch(() => {});
    }
  }, []);

  // Request explicit microphone access via getUserMedia
  const requestMicPermission = async (): Promise<boolean> => {
    try {
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        return false;
      }
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      stream.getTracks().forEach((track) => track.stop());
      setPermissionStatus('granted');
      setShowPermissionBanner(false);
      return true;
    } catch (err: any) {
      console.warn('Microphone permission denied or error:', err);
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        setPermissionStatus('denied');
        setShowPermissionBanner(true);
      }
      return false;
    }
  };

  // Start the wake word listener
  const startWakeWordSystem = () => {
    setIsWakeWordActive(true);
    speech.startWakeWordListener(
      () => {
        handleWakeWordDetected();
      },
      (heardText) => {
        setWakeHeardText(heardText);
        if (wakeWordClearTimeoutRef.current) clearTimeout(wakeWordClearTimeoutRef.current);
        wakeWordClearTimeoutRef.current = setTimeout(() => {
          setWakeHeardText('');
        }, 3000);
      },
      (active, err) => {
        setIsWakeWordActive(active);
        if (err && err.includes('Izin')) {
          setPermissionStatus('denied');
          setShowPermissionBanner(true);
        }
      }
    );
  };

  // Toggle Wake Word Radar
  const handleToggleWakeWord = async () => {
    if (!isWakeWordActive) {
      const granted = await requestMicPermission();
      if (granted) {
        startWakeWordSystem();
        sound.playLevelUp();
        const line = characterId === 'kucing-oren'
          ? '*Telinga tegak* Radar suara aktif! Panggil ZAYN dengan "Hey Petto" kapan aja meong!'
          : characterId === 'anjing-golden'
          ? 'Radar suara aktif! Panggil HERU dengan "Hey Petto" untuk bicara!'
          : 'Radar suara aktif! Katakan "Hey Petto" untuk berdiskusi dengan RIZKY!';
        onNewDialogue(line);
        speakInTomVoice(line, characterId);
      }
    } else {
      speech.stopWakeWordListener();
      setIsWakeWordActive(false);
      setWakeHeardText('');
    }
  };

  // Handle Interruption / Sela Ngomong
  const handleBargeIn = () => {
    if (isSpeakingRef.current) {
      sound.interruptSpeech();
      onTalkingEnd();
      setWakeWordAlert('✋ Karakter disela! Mendengarkanmu...');
      setTimeout(() => setWakeWordAlert(null), 2000);
    }
  };

  // Handle Wake Word "Hey Petto" triggered
  const handleWakeWordDetected = () => {
    sound.interruptSpeech();
    sound.playLevelUp();
    setWakeWordAlert('🎯 "Hey Petto" Terdeteksi! Menjawab...');

    if (onWakeWordTriggered) onWakeWordTriggered();

    let wakeLine = '';
    if (characterId === 'kucing-oren') {
      wakeLine = userLevel >= 4
        ? '*Telinga tegak* Meong! Gue denger kok bestie! Mau ngobrol apa sama gue?'
        : '*Telinga tegak mendengus* Meong! Gue denger! Ada apa manggil-manggil "Hey Petto"? Mau kasih tuna kaleng?!';
    } else if (characterId === 'anjing-golden') {
      wakeLine = 'Guk guk! Aku denger kamu manggil "Hey Petto"! Aku siap dengerin!';
    } else {
      wakeLine = '*Hoo-hoo* "Hey Petto" diterima. Ada hal bijak yang ingin kamu sampaikan?';
    }

    onNewDialogue(wakeLine);
    pushChatMessage('pet', wakeLine);
    speakInTomVoice(
      wakeLine,
      characterId,
      () => onTalkingStart(),
      () => {
        onTalkingEnd();
        // Immediately start hands-free listening without pressing buttons!
        setTimeout(() => {
          startSpeechToTextSession();
        }, 300);
      }
    );

    setTimeout(() => setWakeWordAlert(null), 3500);
  };

  // Send message to AI backend, AUTOMATICALLY SPEAK with animal voice, then RESUME hands-free listening!
  const sendToAiChatAndSpeak = async (userMessage: string) => {
    try {
      if (silenceTimerRef.current) clearTimeout(silenceTimerRef.current);
      if (noSpeechTimeoutRef.current) clearTimeout(noSpeechTimeoutRef.current);

      setLiveTranscript(`Kamu: "${userMessage}"`);
      onNewDialogue('*Sedang berpikir meresponmu...* 🤔💭');
      onAddXp(15);

      // Persist user message to chat history + detect name for long-term memory
      pushChatMessage('user', userMessage);
      const detectedName = extractUserName(userMessage);
      if (detectedName && detectedName !== userNameRef.current) {
        setUserName(detectedName);
      }

      const res = await fetch('/api/pet/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          characterId,
          userMessage,
          level: userLevel,
          levelTitle,
          history: chatHistoryRef.current.slice(-12),
          userMemory: buildUserMemory(),
          userName: userNameRef.current || detectedName || '',
        }),
      });

      const data = await res.json();
      const reply = data.reply || 'Meong! Asik banget ngobrol sama lo!';
      onNewDialogue(reply);
      pushChatMessage('pet', reply);

      // AUTOMATICALLY SPEAK with unique animal sound model
      speakInTomVoice(
        reply,
        characterId,
        () => onTalkingStart(),
        () => {
          onTalkingEnd();
          setLiveTranscript('');

          // CONTINUOUS HANDS-FREE LOOP: Automatically listen for next user response!
          if (isHandsFreeActive) {
            setTimeout(() => {
              startSpeechToTextSession();
            }, 300);
          }
        }
      );
    } catch (err) {
      console.error(err);
      onNewDialogue('*Mendengus* Sinyal internet agak lemot nih meong.');
      pushChatMessage('pet', '*Mendengus* Sinyal internet agak lemot nih meong.');
      onTalkingEnd();

      if (isHandsFreeActive) {
        setTimeout(() => {
          startSpeechToTextSession();
        }, 800);
      }
    }
  };

  // Start Speech-To-Text session with AUTOMATIC silence detection, AUTO-SPEAK, and BARGE-IN support
  const startSpeechToTextSession = async () => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.resume();
    }

    latestTranscriptRef.current = '';

    const hasPermission = await requestMicPermission();
    if (!hasPermission) {
      setShowPermissionBanner(true);
      setShowTextInput(true);
      return;
    }

    if (!speech.isSupported()) {
      setShowTextInput(true);
      return;
    }

    setIsRecording(true);
    setLiveTranscript('Mendengarkan... Bicaralah sekarang 🎙️');

    if (!isSpeakingRef.current) {
      onNewDialogue('*Pasang kuping siap mendengarkan bicaramu...* 👂🐾');
    }

    // Gentle timeout if completely silent
    noSpeechTimeoutRef.current = setTimeout(() => {
      if (!latestTranscriptRef.current) {
        // If hands-free is active, keep listening or ask casually
        if (!isHandsFreeActive) {
          speech.stopSpeechToText();
          setIsRecording(false);
          const promptLine = characterId === 'kucing-oren'
            ? '*Mendengus* Kok diem aja? Mau ngobrol apa? Coba tanya sesuatu ke gue!'
            : 'Ayo ngomong, aku dengerin kok!';
          onNewDialogue(promptLine);
          speakInTomVoice(promptLine, characterId, () => onTalkingStart(), () => onTalkingEnd());
          setLiveTranscript('');
        }
      }
    }, 7000);

    speech.startSpeechToText(
      (transcript, isFinal) => {
        if (noSpeechTimeoutRef.current) clearTimeout(noSpeechTimeoutRef.current);

        latestTranscriptRef.current = transcript;
        setLiveTranscript(`Kamu: "${transcript}"`);

        // If character was speaking, user's voice cuts it off (barge-in)!
        handleBargeIn();

        if (silenceTimerRef.current) clearTimeout(silenceTimerRef.current);

        if (isFinal && transcript.trim()) {
          speech.stopSpeechToText();
          setIsRecording(false);
          sendToAiChatAndSpeak(transcript.trim());
          return;
        }

        // Automatic silence detection: after 1.2s pause, automatically send and speak!
        silenceTimerRef.current = setTimeout(() => {
          if (latestTranscriptRef.current.trim()) {
            speech.stopSpeechToText();
            setIsRecording(false);
            sendToAiChatAndSpeak(latestTranscriptRef.current.trim());
          }
        }, 1200);
      },
      () => {
        setIsRecording(false);
        if (latestTranscriptRef.current.trim()) {
          sendToAiChatAndSpeak(latestTranscriptRef.current.trim());
        }
      },
      (error) => {
        console.warn('Speech error:', error);
        setIsRecording(false);
        setLiveTranscript('');
        if (error === 'not-allowed') {
          setPermissionStatus('denied');
          setShowPermissionBanner(true);
        }
      },
      // onBargeIn callback: immediately cut off character speech as soon as user talks!
      () => {
        handleBargeIn();
      }
    );
  };

  // Talking Tom Pitch Shift Mimic
  const startMimicRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      setPermissionStatus('granted');
      setShowPermissionBanner(false);

      audioChunksRef.current = [];
      const mediaRecorder = new MediaRecorder(stream);

      mediaRecorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          audioChunksRef.current.push(event.data);
        }
      };

      mediaRecorder.onstop = async () => {
        stream.getTracks().forEach((track) => track.stop());

        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const arrayBuffer = await audioBlob.arrayBuffer();
        const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        const ctx = new AudioCtx();
        const decodedBuffer = await ctx.decodeAudioData(arrayBuffer);

        onTalkingStart();
        onNewDialogue('*Menirukan suaramu dengan nada melengking Tom!* 😹🎙️');
        onAddXp(15);

        await sound.playPitchShifted(decodedBuffer, 1.45);
        onTalkingEnd();
      };

      mediaRecorder.start();
      mediaRecorderRef.current = mediaRecorder;
      setIsRecording(true);
      onNewDialogue('*Pasang kuping merekam suaramu...* 👂🐾');
    } catch (err) {
      setPermissionStatus('denied');
      setShowPermissionBanner(true);
      setShowTextInput(true);
    }
  };

  // Microphone button click handler
  const handleMicClick = () => {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.resume();
    }

    // If character is currently speaking, click to interrupt!
    if (isSpeakingRef.current) {
      handleBargeIn();
      return;
    }

    if (isRecording) {
      if (mode === 'ai_chat') {
        speech.stopSpeechToText();
        setIsRecording(false);
        if (latestTranscriptRef.current.trim()) {
          sendToAiChatAndSpeak(latestTranscriptRef.current.trim());
        }
      } else {
        if (mediaRecorderRef.current) {
          mediaRecorderRef.current.stop();
          setIsRecording(false);
        }
      }
    } else {
      if (mode === 'ai_chat') {
        startSpeechToTextSession();
      } else {
        startMimicRecording();
      }
    }
  };

  // Submit custom text prompt
  const handleSendCustomText = (textToSend?: string) => {
    const text = textToSend || customText.trim();
    if (!text) return;

    setShowTextInput(false);
    setCustomText('');
    sendToAiChatAndSpeak(text);
  };

  const characterName = CHARACTERS[characterId]?.name || 'Teman';

  const handleClearChat = () => {
    setChatHistory([]);
    try {
      localStorage.removeItem(`talking_pet_chat_${characterId}_v1`);
    } catch (_) {}
  };

  const handleReplayMessage = (text: string) => {
    sound.interruptSpeech();
    onTalkingStart();
    onNewDialogue(text);
    speakInTomVoice(text, characterId, () => onTalkingStart(), () => onTalkingEnd());
  };

  // Get current animal model voice description
  const getAnimalVoiceLabel = () => {
    if (characterId === 'kucing-oren') return '🐱 Suara: ZAYN (Kucing)';
    if (characterId === 'anjing-golden') return '🐶 Suara: HERU (Anjing)';
    return '🦉 Suara: RIZKY (Burung Hantu)';
  };

  return (
    <div className="z-30 flex flex-col items-center justify-center pb-2 select-none">
      {/* Wake Word Trigger Alert / Interruption Toast (wrapped for positioning context) */}
      <div className="relative w-full flex justify-center">
      {wakeWordAlert && (
        <div className="absolute -top-12 z-50 bg-gradient-to-r from-amber-500 to-yellow-400 text-neutral-950 font-black text-xs px-4 py-1.5 rounded-full shadow-lg border border-yellow-200 flex items-center gap-1.5 animate-bounce">
          <Sparkles className="w-4 h-4 fill-neutral-950" />
          <span>{wakeWordAlert}</span>
        </div>
      )}
      </div>

      {/* Permission Warning / Prompt Banner if needed */}
      {showPermissionBanner && (
        <div className="w-[92%] max-w-[340px] mb-2 bg-amber-500 text-neutral-950 rounded-2xl p-2.5 shadow-xl border-2 border-amber-300 flex items-start gap-2 animate-in fade-in duration-200">
          <AlertCircle className="w-4 h-4 text-neutral-950 shrink-0 mt-0.5" />
          <div className="flex-1 text-[11px] leading-tight">
            <span className="font-extrabold block mb-0.5">Aktifkan Izin Mikrofon</span>
            <span>
              {permissionStatus === 'denied'
                ? 'Akses mikrofon diblokir. Klik ikon gembok di bar alamat browser Anda lalu pilih "Izinkan Mikrofon".'
                : 'Browser membutuhkan izin mikrofon agar percakapan bebas dan "Hey Petto" bisa berjalan lancar.'}
            </span>
            {permissionStatus !== 'denied' && (
              <button
                type="button"
                onClick={handleToggleWakeWord}
                className="mt-1.5 px-3 py-1 bg-neutral-950 hover:bg-neutral-800 text-white rounded-lg font-bold text-[10px] flex items-center gap-1 shadow"
              >
                <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
                <span>Izinkan Mikrofon Sekarang</span>
              </button>
            )}
          </div>
          <button
            type="button"
            onClick={() => setShowPermissionBanner(false)}
            className="text-neutral-800 hover:text-black font-black text-xs px-1"
          >
            ✕
          </button>
        </div>
      )}

      {/* Live Transcript Banner */}
      {liveTranscript && (
        <div className="w-[92%] max-w-[340px] mb-2 bg-neutral-900/90 text-white rounded-xl px-3 py-1.5 text-xs font-semibold backdrop-blur-md border border-neutral-700 shadow-md text-center truncate animate-pulse">
          {liveTranscript}
        </div>
      )}

      {/* Live Audio Heard by Wake Word Radar */}
      {wakeHeardText && isWakeWordActive && !isRecording && (
        <div className="w-[92%] max-w-[340px] mb-1.5 bg-emerald-950/80 text-emerald-200 rounded-lg px-2.5 py-1 text-[10px] font-medium backdrop-blur-sm border border-emerald-500/40 text-center truncate animate-fadeIn">
          👂 Radar mendengar: <span className="font-bold text-white">"{wakeHeardText}"</span>
        </div>
      )}

      {/* Animal Voice Model Badge */}
      <div className="text-[10px] font-black text-amber-950/90 bg-white/85 px-3 py-0.5 rounded-full border border-amber-300 shadow-xs mb-1.5 flex items-center gap-1">
        <span>{getAnimalVoiceLabel()}</span>
        <span className="text-emerald-700 font-bold">· Bisa Disela ✋</span>
      </div>

      {/* Controls row: Hands-Free Loop, Wake Word Radar, Text Input */}
      <div className="flex items-center gap-1.5 mb-2 flex-wrap justify-center px-2">
        {/* Continuous Hands-Free Chat Loop Toggle */}
        <button
          type="button"
          onClick={() => setIsHandsFreeActive(!isHandsFreeActive)}
          className={`text-[10px] font-extrabold px-2.5 py-1 rounded-full shadow-sm flex items-center gap-1 transition-all ${
            isHandsFreeActive
              ? 'bg-gradient-to-r from-emerald-500 to-teal-600 text-white ring-2 ring-emerald-200 shadow'
              : 'bg-neutral-200 text-neutral-600'
          }`}
          title="Obrolan Langsung Tanpa Perlu Tekan Mic Berulang Kali"
        >
          <RefreshCw className={`w-3 h-3 ${isHandsFreeActive ? 'animate-spin' : ''}`} style={{ animationDuration: '4s' }} />
          <span>Obrolan Otomatis: {isHandsFreeActive ? 'ON' : 'OFF'}</span>
        </button>

        {/* Wake Word "Hey Petto" Active Radar Button */}
        <button
          type="button"
          onClick={handleToggleWakeWord}
          className={`text-[10px] font-bold px-2.5 py-1 rounded-full shadow-sm flex items-center gap-1 transition-all ${
            isWakeWordActive
              ? 'bg-amber-500 text-white shadow'
              : 'bg-amber-100 hover:bg-amber-200 text-amber-950 border border-amber-300'
          }`}
          title="Klik untuk Mengaktifkan/Mematikan Radar Suara 'Hey Petto'"
        >
          <Ear className="w-3 h-3" />
          <span>{isWakeWordActive ? 'Hey Petto: ON 🟢' : 'Hey Petto 🔴'}</span>
        </button>

        {/* Quick Test / Trigger "Hey Petto" button */}
        <button
          type="button"
          onClick={handleWakeWordDetected}
          className="text-[10px] font-bold bg-white/90 hover:bg-white text-amber-900 px-2 py-1 rounded-full border border-amber-300 shadow-sm flex items-center gap-1 transition-all active:scale-95"
          title="Tes Langsung Respon 'Hey Petto'"
        >
          <span>🗣️ Tes</span>
        </button>

        {/* Text Input Toggle */}
        <button
          type="button"
          onClick={() => setShowTextInput(!showTextInput)}
          className="text-[10px] font-bold bg-white/90 hover:bg-white text-neutral-700 p-1.5 rounded-full border border-neutral-300 shadow-sm"
          title="Ketik Pesan Langsung"
        >
          <MessageSquare className="w-3 h-3" />
        </button>

        {/* Chat History / Memory Toggle */}
        <button
          type="button"
          onClick={() => setShowChatHistory(!showChatHistory)}
          className={`relative text-[10px] font-bold p-1.5 rounded-full border shadow-sm transition-all ${
            showChatHistory
              ? 'bg-amber-500 text-white border-amber-400'
              : 'bg-white/90 hover:bg-white text-neutral-700 border-neutral-300'
          }`}
          title="Lihat Riwayat Obrolan & Memori"
        >
          <MessagesSquare className="w-3 h-3" />
          {chatHistory.length > 0 && (
            <span className="absolute -top-1 -right-1 min-w-[14px] h-[14px] px-0.5 rounded-full bg-rose-500 text-white text-[8px] font-black flex items-center justify-center border border-white">
              {chatHistory.length > 99 ? '99+' : chatHistory.length}
            </span>
          )}
        </button>
      </div>

      {/* Floating text modal when typing custom phrase */}
      {showTextInput && (
        <div className="absolute bottom-20 z-50 w-[92%] max-w-[340px] bg-white rounded-2xl p-3 shadow-2xl border-2 border-amber-400 animate-in fade-in zoom-in-95">
          <div className="flex items-center justify-between mb-2">
            <p className="text-xs font-black text-neutral-900">
              Ngobrol dengan {characterId === 'kucing-oren' ? 'ZAYN' : characterId === 'anjing-golden' ? 'HERU' : 'RIZKY'}:
            </p>
            <span className="text-[10px] font-bold text-amber-800 bg-amber-100 px-1.5 py-0.5 rounded-md flex items-center gap-1">
              <Volume2 className="w-3 h-3" />
              Suara Hewan Nyata
            </span>
          </div>

          <div className="flex gap-1.5 mb-2">
            <input
              type="text"
              value={customText}
              onChange={(e) => setCustomText(e.target.value)}
              placeholder="Contoh: Hey Petto, kamu lagi ngapain?"
              className="flex-1 text-xs px-3 py-2 bg-neutral-100 rounded-xl outline-none focus:ring-2 focus:ring-amber-400 text-neutral-800"
              onKeyDown={(e) => e.key === 'Enter' && handleSendCustomText()}
            />
            <button
              type="button"
              onClick={() => handleSendCustomText()}
              className="px-3 py-2 bg-amber-500 hover:bg-amber-600 text-white rounded-xl text-xs font-bold flex items-center justify-center"
            >
              <Send className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Quick preset questions */}
          <div className="text-[10px] font-bold text-neutral-500 mb-1">Pertanyaan Cepat (Klik untuk Bicara Langsung):</div>
          <div className="flex flex-wrap gap-1">
            {[
              'Lagi ngapain meong?',
              'Mau tuna kaleng gak?',
              'Kamu sayang aku gak?',
              'Cerita lelucon dong!',
              'Tebak-tebakan yuk!',
              'Nama saya Budi',
            ].map((preset) => (
              <button
                key={preset}
                type="button"
                onClick={() => handleSendCustomText(preset)}
                className="text-[10px] bg-amber-50 hover:bg-amber-100 text-amber-900 px-2 py-0.5 rounded-md border border-amber-200 flex items-center gap-0.5"
              >
                <span>💬</span>
                <span>{preset}</span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Main Golden Glowing Microphone Button matching the reference image */}
      <div className="relative flex items-center justify-center">
        {/* Outer ambient glow ring */}
        <div
          className={`absolute w-20 h-20 rounded-full transition-all duration-300 ${
            isSpeakingRef.current
              ? 'bg-rose-400/40 animate-pulse'
              : isRecording
              ? 'bg-rose-500/50 animate-ping'
              : isHandsFreeActive
              ? 'bg-emerald-400/30 blur-md animate-pulse'
              : 'bg-amber-400/20'
          }`}
        />

        {/* Outer ring */}
        <div className="w-16 h-16 rounded-full bg-gradient-to-b from-[#FDE68A] via-[#F59E0B] to-[#D97706] p-1 shadow-[0_6px_20px_rgba(217,119,6,0.4)] flex items-center justify-center">
          {/* Inner Button */}
          <button
            type="button"
            onClick={handleMicClick}
            className={`w-full h-full rounded-full flex items-center justify-center shadow-inner transition-transform active:scale-90 ${
              isSpeakingRef.current
                ? 'bg-gradient-to-b from-rose-500 to-rose-700 text-white animate-pulse'
                : isRecording
                ? 'bg-gradient-to-b from-rose-500 to-rose-700 text-white animate-pulse'
                : 'bg-gradient-to-b from-[#FCD34D] via-[#F59E0B] to-[#B45309] text-amber-950 hover:brightness-105'
            }`}
            title={
              isSpeakingRef.current
                ? 'Karakter sedang bicara! Tekan untuk MENYELA (potong suara) ⏹️'
                : isRecording
                ? 'Sedang mendengar... Bicara saja terus, karakter otomatis membalas!'
                : 'Tekan untuk mulai ngobrol langsung!'
            }
          >
            {isSpeakingRef.current ? (
              <span className="text-xs font-black text-white flex flex-col items-center">
                <span>SELA</span>
              </span>
            ) : isRecording ? (
              <MicOff className="w-7 h-7 drop-shadow-sm text-white" />
            ) : (
              <Mic className="w-7 h-7 drop-shadow-sm text-amber-950" />
            )}
          </button>
        </div>
      </div>

      <div className="flex flex-col items-center mt-1">
        <span className="text-[10px] font-bold text-amber-950 leading-tight">
          {isSpeakingRef.current
            ? '🔊 Sedang bersuara (Katakan sesuatu / ketuk untuk sela)'
            : isRecording
            ? '🎙️ Bicaralah sekarang... (Otomatis Speak)'
            : isHandsFreeActive
            ? '🟢 Obrolan Bebas Aktif (Ngobrol terus-menerus)'
            : 'Tekan mic untuk mulai bicara'}
        </span>
      </div>

      {/* Chat History / Memory Panel (full-screen overlay) */}
      {showChatHistory && (
        <ChatHistoryPanel
          messages={chatHistory}
          characterName={characterName}
          onClose={() => setShowChatHistory(false)}
          onClear={handleClearChat}
          onReplay={handleReplayMessage}
        />
      )}
    </div>
  );
};
