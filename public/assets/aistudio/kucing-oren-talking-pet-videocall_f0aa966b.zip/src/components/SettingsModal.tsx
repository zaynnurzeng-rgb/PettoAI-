import React from 'react';
import { X, Volume2, VolumeX, RotateCcw, Info, Heart } from 'lucide-react';
import { sound } from '../utils/audio';

interface SettingsModalProps {
  onClose: () => void;
  onResetProgress: () => void;
  onOpenLevelGuide: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  onClose,
  onResetProgress,
  onOpenLevelGuide,
}) => {
  const [isMuted, setIsMuted] = React.useState(sound.getMuted());

  const handleToggleMute = () => {
    const next = !isMuted;
    setIsMuted(next);
    sound.setMuted(next);
  };

  return (
    <div className="absolute inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 select-none animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl p-5 w-full max-w-sm shadow-2xl border-2 border-amber-300">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-base font-black text-neutral-900">Pengaturan Game ⚙️</h3>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-neutral-100 hover:bg-neutral-200 flex items-center justify-center text-neutral-600"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="space-y-3 mb-5">
          {/* Sound Toggle */}
          <div className="flex items-center justify-between p-3 rounded-2xl bg-neutral-50 border border-neutral-200">
            <div className="flex items-center gap-2.5">
              {isMuted ? (
                <VolumeX className="w-5 h-5 text-neutral-400" />
              ) : (
                <Volume2 className="w-5 h-5 text-amber-500" />
              )}
              <div>
                <div className="text-xs font-bold text-neutral-800">Efek Suara & Musik</div>
                <div className="text-[10px] text-neutral-500">Dengkuran, suara meong & tawa</div>
              </div>
            </div>
            <button
              type="button"
              onClick={handleToggleMute}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors ${
                isMuted
                  ? 'bg-neutral-200 text-neutral-700'
                  : 'bg-amber-500 text-white shadow-sm'
              }`}
            >
              {isMuted ? 'Mati' : 'Aktif'}
            </button>
          </div>

          {/* Level Guide Button */}
          <button
            type="button"
            onClick={() => {
              onClose();
              onOpenLevelGuide();
            }}
            className="w-full flex items-center justify-between p-3 rounded-2xl bg-rose-50/70 border border-rose-200 text-left hover:bg-rose-100/70 transition-colors"
          >
            <div className="flex items-center gap-2.5">
              <Heart className="w-5 h-5 text-rose-500 fill-rose-400" />
              <div>
                <div className="text-xs font-bold text-neutral-800">Panduan Level Kesukaan</div>
                <div className="text-[10px] text-neutral-500">Lihat cara naik level 1 sampai 5</div>
              </div>
            </div>
            <span className="text-xs font-bold text-rose-600">Lihat →</span>
          </button>

          {/* Reset Progress */}
          <div className="p-3 rounded-2xl bg-neutral-50 border border-neutral-200">
            <div className="text-xs font-bold text-neutral-800 mb-1">Ulangi Pertemanan</div>
            <p className="text-[10px] text-neutral-500 mb-2">
              Kembalikan tingkat kesukaan ke Level 1 untuk merasakan lagi awal perkenalan dengan ZAYN, HERU, atau RIZKY.
            </p>
            <button
              type="button"
              onClick={() => {
                if (confirm('Yakin ingin mereset level kesukaan ke Level 1?')) {
                  onResetProgress();
                  onClose();
                }
              }}
              className="px-3 py-1.5 rounded-xl bg-neutral-200 hover:bg-neutral-300 text-neutral-700 text-xs font-bold flex items-center gap-1.5"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Reset Level
            </button>
          </div>
        </div>

        <button
          type="button"
          onClick={onClose}
          className="w-full py-2.5 bg-neutral-900 text-white font-bold text-xs rounded-xl"
        >
          Tutup
        </button>
      </div>
    </div>
  );
};
