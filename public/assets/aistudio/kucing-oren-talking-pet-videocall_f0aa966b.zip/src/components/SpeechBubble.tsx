import React from 'react';
import { Volume2, Square } from 'lucide-react';
import { sound } from '../utils/audio';

interface SpeechBubbleProps {
  speakerName?: string;
  text: string;
  onReplayAudio?: () => void;
  onInterrupt?: () => void;
  isTalking?: boolean;
}

export const SpeechBubble: React.FC<SpeechBubbleProps> = ({
  speakerName,
  text,
  onReplayAudio,
  onInterrupt,
  isTalking = false,
}) => {
  const handleClick = () => {
    if (isTalking) {
      sound.interruptSpeech();
      if (onInterrupt) onInterrupt();
    } else if (onReplayAudio) {
      onReplayAudio();
    }
  };

  return (
    <div className="relative mx-auto max-w-[340px] w-[92%] z-30 select-none animate-in fade-in zoom-in-95 duration-200">
      {/* Comic Speech Container - Clickable to interrupt if talking */}
      <div
        onClick={handleClick}
        className={`relative bg-white text-neutral-900 border-[3px] border-neutral-900 rounded-[26px] p-4 shadow-[0_6px_0_rgba(0,0,0,0.15)] flex items-start gap-2.5 cursor-pointer transition-all ${
          isTalking ? 'ring-2 ring-rose-400 hover:brightness-95' : ''
        }`}
        title={isTalking ? 'Klik untuk menyela / hentikan bicara' : 'Klik untuk mendengarkan'}
      >
        <div className="flex-1">
          {speakerName && (
            <div className="flex items-center gap-1.5 mb-1.5">
              <span className="text-[10px] font-black uppercase tracking-wider text-amber-950 bg-amber-200/80 px-2 py-0.5 rounded-md border border-amber-300">
                {speakerName}
              </span>
            </div>
          )}
          <p className="text-[14px] leading-snug font-bold tracking-tight text-neutral-800 break-words">
            {text}
          </p>
          {isTalking && (
            <span className="inline-flex items-center gap-1 text-[10px] font-black text-rose-600 bg-rose-50 px-2 py-0.5 rounded-full border border-rose-200 mt-1 animate-pulse">
              <Square className="w-2.5 h-2.5 fill-rose-600" />
              <span>Bisa disela (Klik untuk potong bicara)</span>
            </span>
          )}
        </div>

        {/* Action button: Stop if talking, or Replay if idle */}
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            handleClick();
          }}
          className={`shrink-0 p-1.5 rounded-full transition-all ${
            isTalking
              ? 'bg-rose-500 hover:bg-rose-600 text-white scale-110 shadow animate-pulse'
              : 'bg-neutral-100 hover:bg-neutral-200 text-neutral-700'
          }`}
          title={isTalking ? 'Sela Bicara' : 'Dengarkan Suara'}
        >
          {isTalking ? <Square className="w-4 h-4 fill-white" /> : <Volume2 className="w-4 h-4" />}
        </button>

        {/* Downward Speech Tail (SVG triangle pointing to pet) */}
        <div className="absolute -bottom-[16px] left-1/2 -translate-x-1/2 w-8 h-4 overflow-visible pointer-events-none">
          <svg viewBox="0 0 32 16" className="w-full h-full">
            <path
              d="M 6 0 L 22 16 L 26 0 Z"
              fill="white"
              stroke="rgb(23 23 23)"
              strokeWidth="3"
              strokeLinejoin="round"
            />
            <path d="M 5 0 L 27 0" stroke="white" strokeWidth="4" />
          </svg>
        </div>
      </div>
    </div>
  );
};
