import React from 'react';
import { ChevronLeft, ChevronRight, Settings, Info } from 'lucide-react';
import { CharacterId } from '../types/game';

interface TopBarProps {
  activeCharacterId: CharacterId;
  onSelectCharacter: (id: CharacterId) => void;
  onOpenSettings: () => void;
  onOpenInfo: () => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  activeCharacterId,
  onSelectCharacter,
  onOpenSettings,
  onOpenInfo,
}) => {
  const characters: { id: CharacterId; name: string; avatar: string; bg: string }[] = [
    {
      id: 'burung-hantu',
      name: 'RIZKY\n(Burung Hantu)',
      avatar: '🦉',
      bg: '#DDD6FE',
    },
    {
      id: 'kucing-oren',
      name: 'ZAYN\n(Kucing Oren)',
      avatar: '🐱',
      bg: '#FED7AA',
    },
    {
      id: 'anjing-golden',
      name: 'HERU\n(Anjing Golden)',
      avatar: '🐶',
      bg: '#FEF08A',
    },
  ];

  const currentIndex = characters.findIndex((c) => c.id === activeCharacterId);

  const handlePrev = () => {
    const newIdx = (currentIndex - 1 + characters.length) % characters.length;
    onSelectCharacter(characters[newIdx].id);
  };

  const handleNext = () => {
    const newIdx = (currentIndex + 1) % characters.length;
    onSelectCharacter(characters[newIdx].id);
  };

  return (
    <div className="relative z-40 w-full pt-3 pb-2 px-3 select-none">
      {/* Top action row: Back button & Settings button */}
      <div className="flex items-center justify-between mb-1.5">
        <button
          type="button"
          onClick={onOpenInfo}
          className="w-9 h-9 rounded-full bg-white/90 hover:bg-white text-neutral-800 shadow-md flex items-center justify-center transition-transform active:scale-90"
          title="Petunjuk & Level Kesukaan"
        >
          <ChevronLeft className="w-5 h-5" />
        </button>

        <button
          type="button"
          onClick={onOpenSettings}
          className="w-9 h-9 rounded-full bg-white/90 hover:bg-white text-neutral-800 shadow-md flex items-center justify-center transition-transform active:scale-90"
          title="Pengaturan Suara"
        >
          <Settings className="w-5 h-5" />
        </button>
      </div>

      {/* Character Selector Carousel with Left & Right arrows matching the screenshot */}
      <div className="flex items-center justify-center gap-1.5">
        {/* Left Arrow */}
        <button
          type="button"
          onClick={handlePrev}
          className="w-6 h-6 rounded-full bg-white/70 hover:bg-white text-neutral-700 flex items-center justify-center shadow-sm transition-transform active:scale-90"
          title="Karakter Sebelumnya"
        >
          <ChevronLeft className="w-4 h-4" />
        </button>

        {/* 3 Character Avatars */}
        <div className="flex items-start justify-center gap-4">
          {characters.map((char) => {
            const isSelected = char.id === activeCharacterId;
            return (
              <button
                key={char.id}
                type="button"
                onClick={() => onSelectCharacter(char.id)}
                className="flex flex-col items-center group transition-all"
              >
                {/* Circular Avatar */}
                <div
                  className={`w-13 h-13 rounded-full flex items-center justify-center transition-all ${
                    isSelected
                      ? 'ring-4 ring-amber-400 bg-amber-100 scale-110 shadow-lg'
                      : 'bg-white/80 opacity-75 hover:opacity-100 hover:scale-105 border-2 border-white'
                  }`}
                  style={{ backgroundColor: isSelected ? '#FEF08A' : char.bg }}
                >
                  <span className="text-2xl drop-shadow-sm">{char.avatar}</span>
                </div>

                {/* Character Name text below matching the screenshot */}
                <span
                  className={`text-[10px] font-bold mt-1 text-center leading-tight whitespace-pre-line ${
                    isSelected ? 'text-amber-950 font-black' : 'text-neutral-700/80'
                  }`}
                >
                  {char.name}
                </span>
              </button>
            );
          })}
        </div>

        {/* Right Arrow */}
        <button
          type="button"
          onClick={handleNext}
          className="w-6 h-6 rounded-full bg-white/70 hover:bg-white text-neutral-700 flex items-center justify-center shadow-sm transition-transform active:scale-90"
          title="Karakter Selanjutnya"
        >
          <ChevronRight className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
