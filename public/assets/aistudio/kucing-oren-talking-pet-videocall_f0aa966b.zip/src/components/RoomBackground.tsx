import React from 'react';

export const RoomBackground: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  return (
    <div className="relative w-full h-full overflow-hidden select-none bg-[#F7D8B5]">
      {/* Wall Gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-[#FADDBE] via-[#F6CCA3] to-[#F1B983] pointer-events-none" />

      {/* Sunny Window (Left side) */}
      <div className="absolute top-12 left-4 w-28 h-44 rounded-t-full border-4 border-[#FEEAD4] bg-gradient-to-br from-[#FEFCE8] to-[#BAE6FD] shadow-inner opacity-80 pointer-events-none overflow-hidden">
        {/* Window grid panes */}
        <div className="absolute inset-x-0 top-1/2 h-1 bg-[#FEEAD4]" />
        <div className="absolute inset-y-0 left-1/2 w-1 bg-[#FEEAD4]" />
        {/* Soft sunlight rays */}
        <div className="absolute -top-10 -left-10 w-48 h-48 bg-gradient-to-br from-white/40 via-yellow-100/20 to-transparent rotate-45 transform" />
      </div>

      {/* Cozy Wooden Bed with Pillows (Midground left) */}
      <div className="absolute top-44 left-2 w-48 h-32 pointer-events-none">
        {/* Wooden headboard */}
        <div className="absolute bottom-0 left-0 w-8 h-28 bg-[#8C532C] rounded-t-md shadow-md border-r-2 border-[#6D3D1D]" />
        <div className="absolute bottom-0 left-36 w-8 h-20 bg-[#8C532C] rounded-t-md shadow-md border-r-2 border-[#6D3D1D]" />
        {/* Bed base */}
        <div className="absolute bottom-4 left-6 w-32 h-14 bg-[#A76D3E] rounded-md shadow-sm border border-[#7D4821]">
          {/* Mattress */}
          <div className="absolute -top-4 left-2 right-2 h-7 bg-[#FFFDF7] rounded-t-md shadow-inner" />
          {/* Cozy Green/Teal Duvet */}
          <div className="absolute -top-2 left-10 right-0 h-14 bg-[#76A88B] rounded-tl-xl rounded-tr-md border-t-2 border-[#5B8D70] shadow-sm" />
          {/* Fluffy Pillow */}
          <div className="absolute -top-6 left-3 w-12 h-6 bg-[#FEF9E7] rounded-full rotate-6 shadow-sm border border-[#E9DEBC]" />
        </div>
      </div>

      {/* Wooden Toy Shelf / Nightstand (Right side) */}
      <div className="absolute top-48 right-3 w-24 h-28 pointer-events-none">
        <div className="w-full h-full bg-[#9B6339] rounded-md shadow-md border-l-2 border-[#764620] relative">
          <div className="absolute top-3 left-2 right-2 h-0.5 bg-[#663A17]" />
          {/* Small Plant or Alarm clock */}
          <div className="absolute -top-5 right-4 w-6 h-6 bg-[#4ADE80] rounded-full border-2 border-white shadow-sm flex items-center justify-center text-[10px]">
            🌱
          </div>
        </div>
      </div>

      {/* Wooden Floor Board with subtle lines */}
      <div className="absolute bottom-0 inset-x-0 h-44 bg-gradient-to-b from-[#DDA770] via-[#CD935B] to-[#BC7F48] border-t-4 border-[#A36B36] shadow-inner pointer-events-none">
        <div className="w-full h-full opacity-15 flex flex-col justify-between py-2">
          <div className="border-b border-[#522F0E]" />
          <div className="border-b border-[#522F0E]" />
          <div className="border-b border-[#522F0E]" />
        </div>
      </div>

      {/* Round Layered Play Carpet (Center carpet where pet stands) */}
      <div className="absolute bottom-20 left-1/2 -translate-x-1/2 w-[340px] h-32 rounded-[50%] bg-[#FCE7D0] border-4 border-[#F7C6B3] shadow-md flex items-center justify-center pointer-events-none">
        <div className="w-[300px] h-26 rounded-[50%] bg-[#FFF2E5] border-2 border-[#F3B79F] flex items-center justify-center">
          <div className="w-[260px] h-20 rounded-[50%] bg-[#FFECE0] border border-dashed border-[#F39C7D] opacity-60" />
        </div>
      </div>

      {/* Floor Toys matching the screenshot: Blue Toy Car (left) */}
      <div className="absolute bottom-24 left-6 pointer-events-none">
        <div className="relative w-12 h-6 bg-[#3B82F6] rounded-t-xl rounded-b-md shadow-sm border border-[#2563EB]">
          {/* Yellow window */}
          <div className="absolute top-1 left-3 w-4 h-2 bg-[#FEF08A] rounded-sm" />
          {/* Black wheels */}
          <div className="absolute -bottom-1.5 left-1 w-3 h-3 bg-neutral-800 rounded-full border border-neutral-400" />
          <div className="absolute -bottom-1.5 right-1 w-3 h-3 bg-neutral-800 rounded-full border border-neutral-400" />
        </div>
      </div>

      {/* Alphabet Blocks "ABC" (Bottom-Left) */}
      <div className="absolute bottom-12 left-4 pointer-events-none flex flex-col items-center">
        {/* Block A */}
        <div className="w-7 h-7 bg-[#EF4444] rounded-md shadow border border-[#B91C1C] flex items-center justify-center text-white font-extrabold text-xs -mb-1 z-10">
          A
        </div>
        <div className="flex gap-0.5">
          {/* Block B */}
          <div className="w-7 h-7 bg-[#22C55E] rounded-md shadow border border-[#15803D] flex items-center justify-center text-white font-extrabold text-xs">
            B
          </div>
          {/* Block C */}
          <div className="w-7 h-7 bg-[#EAB308] rounded-md shadow border border-[#A16207] flex items-center justify-center text-white font-extrabold text-xs">
            C
          </div>
        </div>
      </div>

      {/* Play Blocks (Bottom-Right) */}
      <div className="absolute bottom-16 right-5 pointer-events-none flex flex-col items-end">
        <div className="w-8 h-8 bg-[#8B5CF6] rounded-md shadow border border-[#6D28D9] flex items-center justify-center text-white font-extrabold text-sm -mb-2 z-10 mr-2">
          C
        </div>
        <div className="flex gap-1">
          <div className="w-8 h-8 bg-[#EC4899] rounded-md shadow border border-[#BE185D] flex items-center justify-center text-white font-extrabold text-sm">
            A
          </div>
          <div className="w-6 h-6 bg-[#06B6D4] rounded-md shadow border border-[#0891B2] self-end" />
        </div>
      </div>


      {/* Main Content inside the room */}
      <div className="relative z-10 w-full h-full flex flex-col">{children}</div>
    </div>
  );
};
