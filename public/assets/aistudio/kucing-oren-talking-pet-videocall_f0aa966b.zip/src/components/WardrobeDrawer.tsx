import React, { useState } from 'react';
import { X, Lock, Check } from 'lucide-react';
import { OUTFIT_ITEMS } from '../data/characters';
import { OutfitItem } from '../types/game';

interface WardrobeDrawerProps {
  userLevel: number;
  currentOutfit: {
    hat?: string;
    glasses?: string;
    neck?: string;
  };
  onSelectOutfit: (category: 'hat' | 'glasses' | 'neck', id: string) => void;
  onClose: () => void;
}

export const WardrobeDrawer: React.FC<WardrobeDrawerProps> = ({
  userLevel,
  currentOutfit,
  onSelectOutfit,
  onClose,
}) => {
  const [activeTab, setActiveTab] = useState<'hat' | 'glasses' | 'neck'>('hat');

  const filteredItems = OUTFIT_ITEMS.filter((item) => item.category === activeTab);

  return (
    <div className="absolute inset-x-0 bottom-0 z-50 bg-white/95 backdrop-blur-md rounded-t-3xl p-4 shadow-2xl border-t-2 border-sky-300 max-h-[80%] overflow-y-auto animate-in slide-in-from-bottom duration-300 select-none">
      <div className="w-12 h-1 bg-neutral-300 rounded-full mx-auto mb-3" />

      <div className="flex items-center justify-between mb-3">
        <div>
          <h3 className="text-base font-extrabold text-neutral-900">Lemari Kostum 👒</h3>
          <p className="text-xs text-neutral-500">
            Dandani karaktermu! Level kesukaan membuka aksesori baru.
          </p>
        </div>
        <button
          type="button"
          onClick={onClose}
          className="w-8 h-8 rounded-full bg-neutral-100 hover:bg-neutral-200 flex items-center justify-center text-neutral-600"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Category Tabs */}
      <div className="flex gap-2 p-1 bg-neutral-100 rounded-xl mb-4">
        {[
          { key: 'hat', label: 'Topi & Mahkota' },
          { key: 'glasses', label: 'Kacamata' },
          { key: 'neck', label: 'Aksesoris Leher' },
        ].map((tab) => (
          <button
            key={tab.key}
            type="button"
            onClick={() => setActiveTab(tab.key as 'hat' | 'glasses' | 'neck')}
            className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition-all ${
              activeTab === tab.key
                ? 'bg-sky-500 text-white shadow-sm'
                : 'text-neutral-600 hover:text-neutral-900'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Outfit Items Grid */}
      <div className="grid grid-cols-2 gap-2.5">
        {filteredItems.map((item: OutfitItem) => {
          const isLocked = item.minLevel > userLevel;
          const isSelected = currentOutfit[activeTab] === item.id;

          return (
            <button
              key={item.id}
              type="button"
              disabled={isLocked}
              onClick={() => onSelectOutfit(activeTab, item.id)}
              className={`relative p-3 rounded-2xl text-left border flex items-center gap-3 transition-all ${
                isSelected
                  ? 'border-sky-500 bg-sky-50 ring-2 ring-sky-300 shadow-sm'
                  : isLocked
                  ? 'bg-neutral-100 border-neutral-200 opacity-60 cursor-not-allowed'
                  : 'bg-white hover:bg-neutral-50 border-neutral-200 shadow-sm active:scale-95'
              }`}
            >
              <span className="text-2xl drop-shadow-sm">{item.icon}</span>

              <div className="flex-1 min-w-0">
                <div className="text-xs font-bold text-neutral-800 truncate">{item.name}</div>
                {isLocked ? (
                  <div className="flex items-center gap-1 text-[10px] text-neutral-400 font-semibold mt-0.5">
                    <Lock className="w-2.5 h-2.5" />
                    <span>Lv. {item.minLevel}</span>
                  </div>
                ) : (
                  <span className="text-[10px] text-emerald-600 font-semibold">Tersedia</span>
                )}
              </div>

              {isSelected && (
                <div className="w-5 h-5 rounded-full bg-sky-500 text-white flex items-center justify-center shrink-0">
                  <Check className="w-3 h-3 stroke-[3]" />
                </div>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
};
