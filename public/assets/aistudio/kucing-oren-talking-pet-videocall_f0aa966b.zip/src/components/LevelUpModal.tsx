import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';
import { Sparkles, Trophy, Heart, Gift } from 'lucide-react';
import { sound } from '../utils/audio';

interface LevelUpModalProps {
  level: number;
  levelTitle: string;
  characterName: string;
  onClose: () => void;
}

export const LevelUpModal: React.FC<LevelUpModalProps> = ({
  level,
  levelTitle,
  characterName,
  onClose,
}) => {
  useEffect(() => {
    sound.playLevelUp();

    // Trigger colorful confetti shower
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
    });

    const timeout = setTimeout(() => {
      confetti({
        particleCount: 50,
        angle: 60,
        spread: 55,
        origin: { x: 0 },
      });
      confetti({
        particleCount: 50,
        angle: 120,
        spread: 55,
        origin: { x: 1 },
      });
    }, 250);

    return () => clearTimeout(timeout);
  }, []);

  const getLevelRewardDescription = (lvl: number) => {
    switch (lvl) {
      case 2:
        return 'Membuka Makanan Baru (Tulang & Kopi) + Kacamata Profesor & Topi Pesta!';
      case 3:
        return 'Membuka Kostum Topi Koki & Kacamata Pantai! Dialog karakter semakin ramah.';
      case 4:
        return 'Membuka Kalung Rantai Emas Rapper & Syal Hangat! Karakter menganggapmu Bestie.';
      case 5:
        return 'MAHKOTA EMAS SULTAN DIBUKA! Karakter mencintaimu sepenuh jiwa meong! 👑💖';
      default:
        return 'Meningkatkan kedekatan batin & membuka dialog rahasia baru!';
    }
  };

  return (
    <div className="absolute inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 select-none animate-in fade-in zoom-in-95 duration-200">
      <div className="bg-white rounded-3xl p-6 w-full max-w-sm shadow-2xl border-4 border-amber-400 text-center relative overflow-hidden">
        {/* Decorative background sunburst */}
        <div className="absolute -top-16 -left-16 w-48 h-48 bg-amber-100/60 rounded-full blur-2xl pointer-events-none" />
        <div className="absolute -bottom-16 -right-16 w-48 h-48 bg-rose-100/60 rounded-full blur-2xl pointer-events-none" />

        {/* Big Golden Trophy / Badge */}
        <div className="relative mx-auto w-20 h-20 rounded-full bg-gradient-to-tr from-amber-400 to-yellow-300 p-1 shadow-lg flex items-center justify-center mb-3">
          <div className="w-full h-full rounded-full bg-white flex items-center justify-center text-4xl">
            🎉
          </div>
          <span className="absolute -bottom-1 bg-rose-500 text-white text-[11px] font-black px-2.5 py-0.5 rounded-full shadow-sm">
            LEVEL UP!
          </span>
        </div>

        <h3 className="text-xl font-black text-neutral-900 mb-0.5">
          Tingkat Kesukaan Naik!
        </h3>
        <p className="text-xs text-neutral-500 mb-3">
          {characterName} semakin sayang dan percaya padamu!
        </p>

        {/* Level Title Badge */}
        <div className="bg-gradient-to-r from-amber-50 via-yellow-50 to-amber-50 border-2 border-amber-200 rounded-2xl p-3 mb-4 shadow-inner">
          <div className="flex items-center justify-center gap-1.5 text-rose-600 font-extrabold text-xs mb-1">
            <Heart className="w-3.5 h-3.5 fill-rose-500" />
            <span>LEVEL {level}</span>
          </div>
          <div className="text-base font-black text-amber-950">
            "{levelTitle}"
          </div>
        </div>

        {/* Reward Unlocked */}
        <div className="bg-neutral-50 rounded-2xl p-3 border border-neutral-200 text-left mb-5">
          <div className="flex items-center gap-1.5 text-xs font-black text-neutral-800 mb-1">
            <Gift className="w-3.5 h-3.5 text-amber-500" />
            <span>Hadiah Spesial Terbuka:</span>
          </div>
          <p className="text-xs text-neutral-600 font-medium leading-relaxed">
            {getLevelRewardDescription(level)}
          </p>
        </div>

        <button
          type="button"
          onClick={onClose}
          className="w-full py-3 bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-600 hover:to-yellow-600 text-neutral-950 font-black text-sm rounded-2xl shadow-lg transition-transform active:scale-95"
        >
          Keren! Lanjut Main 🐾
        </button>
      </div>
    </div>
  );
};
