import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Phone, Video, VideoOff, Mic, MicOff, Flame, X, AlertCircle, Sparkles } from 'lucide-react';
import { sound, speakInTomVoice } from '../utils/audio';
import { CHARACTERS } from '../data/characters';
import { CharacterId } from '../types/game';

interface VideoCallModalProps {
  characterId: CharacterId;
  level: number;
  levelTitle: string;
  onClose: () => void;
  onAddXp?: (amount: number) => void;
}

const CHARACTER_EMOJI: Record<CharacterId, string> = {
  'kucing-oren': '🐱',
  'anjing-golden': '🐶',
  'burung-hantu': '🦉',
};

const LOCAL_ROAST_FALLBACK: Record<CharacterId, string[]> = {
  'kucing-oren': [
    '*Mendengus* Kamera lagi error, tapi tetep aja wajah lo pasti layak dihina. Bawa tuna kaleng dulu baru gue mau ngomong. 😼',
    'Heh, tanpa kamera pun gue tau gaya lo acak-acakan. Nggak usah deket-deket, aura jeleknya kerasa. 😼',
  ],
  'anjing-golden': [
    'GUK GUK! Kamera mati tapi HERU yakin kamu paling tampan/cantik sedunia! Ayo main! 🐶💛',
  ],
  'burung-hantu': [
    '*Hoo-hoo* Tanpa gambar pun aku bisa merasakan ketenangan di wajahmu malam ini. 🦉',
  ],
};

export const VideoCallModal: React.FC<VideoCallModalProps> = ({
  characterId,
  level,
  levelTitle,
  onClose,
  onAddXp,
}) => {
  const charConfig = CHARACTERS[characterId];
  const characterName = charConfig?.name || 'Teman';
  const emoji = CHARACTER_EMOJI[characterId];

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const autoRoastTimerRef = useRef<any>(null);
  const firstRoastTimerRef = useRef<any>(null);

  const [cameraOn, setCameraOn] = useState(true);
  const [micOn, setMicOn] = useState(true);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [roastText, setRoastText] = useState<string>('*Menatap layar* Nyambungin video call... Sabar ya. 📹');
  const [callSeconds, setCallSeconds] = useState(0);
  const [userName, setUserName] = useState<string>('');

  // Load persisted user name (memory) from localStorage
  useEffect(() => {
    try {
      const saved = localStorage.getItem('talking_pet_user_memory_v1');
      if (saved) setUserName(JSON.parse(saved)?.name || '');
    } catch (_) {}
  }, []);

  // Call timer
  useEffect(() => {
    const t = setInterval(() => setCallSeconds((s) => s + 1), 1000);
    return () => clearInterval(t);
  }, []);

  // Start front camera on mount
  const startCamera = useCallback(async () => {
    try {
      if (!navigator.mediaDevices?.getUserMedia) {
        setCameraError('Browser tidak mendukung kamera.');
        return;
      }
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'user', width: { ideal: 640 }, height: { ideal: 480 } },
        audio: false,
      });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play().catch(() => {});
      }
      setCameraError(null);
      setCameraOn(true);
    } catch (err: any) {
      if (err?.name === 'NotAllowedError' || err?.name === 'PermissionDeniedError') {
        setCameraError('Izin kamera ditolak. Aktifkan lewat ikon gembok di bar alamat, atau pakai mode tanpa kamera.');
      } else {
        setCameraError('Kamera tidak bisa dibuka. Coba mode tanpa kamera.');
      }
      setCameraOn(false);
    }
  }, []);

  useEffect(() => {
    startCamera();
    return () => {
      // Stop all camera tracks on unmount
      streamRef.current?.getTracks().forEach((t) => t.stop());
      if (firstRoastTimerRef.current) clearTimeout(firstRoastTimerRef.current);
      if (autoRoastTimerRef.current) clearInterval(autoRoastTimerRef.current);
      sound.interruptSpeech();
    };
  }, [startCamera]);

  // First auto-roast shortly after connecting, then every 18s
  useEffect(() => {
    firstRoastTimerRef.current = setTimeout(() => {
      triggerRoast();
    }, 2500);
    autoRoastTimerRef.current = setInterval(() => {
      triggerRoast();
    }, 18000);
    return () => {
      if (firstRoastTimerRef.current) clearTimeout(firstRoastTimerRef.current);
      if (autoRoastTimerRef.current) clearInterval(autoRoastTimerRef.current);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const speakReply = (text: string) => {
    setIsSpeaking(true);
    speakInTomVoice(
      text,
      characterId,
      () => setIsSpeaking(true),
      () => setIsSpeaking(false),
      true
    );
  };

  const triggerRoast = async () => {
    if (isAnalyzing) return;
    setIsAnalyzing(true);
    sound.playPop();

    let imageBase64 = '';
    if (cameraOn && videoRef.current && canvasRef.current && streamRef.current) {
      try {
        const video = videoRef.current;
        const canvas = canvasRef.current;
        canvas.width = 320;
        canvas.height = 240;
        const ctx = canvas.getContext('2d');
        if (ctx && video.videoWidth > 0) {
          // Mirror to match the preview
          ctx.translate(canvas.width, 0);
          ctx.scale(-1, 1);
          ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
          imageBase64 = canvas.toDataURL('image/jpeg', 0.6);
        }
      } catch (_) {
        imageBase64 = '';
      }
    }

    try {
      let reply = '';
      if (imageBase64) {
        const res = await fetch('/api/pet/vision', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            characterId,
            level,
            levelTitle,
            userName,
            image: imageBase64,
          }),
        });
        const data = await res.json();
        reply = data.reply || '';
      }
      if (!reply) {
        // Text-only roast (no camera) via chat endpoint
        const res = await fetch('/api/pet/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            characterId,
            userMessage: 'Komentari penampilanku seolah-olah kamu lagi video call melihat wajahku. Gaya kamu tetap.',
            level,
            levelTitle,
            userName,
          }),
        });
        const data = await res.json();
        reply = data.reply || '';
      }
      if (!reply) {
        const list = LOCAL_ROAST_FALLBACK[characterId] || LOCAL_ROAST_FALLBACK['kucing-oren'];
        reply = list[Math.floor(Math.random() * list.length)];
      }
      setRoastText(reply);
      speakReply(reply);
      if (onAddXp) onAddXp(10);
    } catch (err) {
      const list = LOCAL_ROAST_FALLBACK[characterId] || LOCAL_ROAST_FALLBACK['kucing-oren'];
      const fallback = list[Math.floor(Math.random() * list.length)];
      setRoastText(fallback);
      speakReply(fallback);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const toggleCamera = async () => {
    if (cameraOn) {
      streamRef.current?.getTracks().forEach((t) => t.stop());
      streamRef.current = null;
      setCameraOn(false);
    } else {
      await startCamera();
    }
  };

  const handleEndCall = () => {
    sound.interruptSpeech();
    streamRef.current?.getTracks().forEach((t) => t.stop());
    onClose();
  };

  const formatTime = (s: number) => {
    const m = Math.floor(s / 60).toString().padStart(2, '0');
    const sec = (s % 60).toString().padStart(2, '0');
    return `${m}:${sec}`;
  };

  return (
    <div className="absolute inset-0 z-50 flex flex-col bg-gradient-to-b from-neutral-900 via-neutral-950 to-black overflow-hidden animate-in fade-in duration-200">
      {/* Hidden canvas for frame capture */}
      <canvas ref={canvasRef} className="hidden" />

      {/* Top call bar */}
      <div className="flex items-center justify-between px-4 py-3 bg-black/40 backdrop-blur-sm border-b border-white/10">
        <div className="flex items-center gap-2">
          <span className="relative flex h-2.5 w-2.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-rose-400 opacity-75" />
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-rose-500" />
          </span>
          <div className="flex flex-col leading-tight">
            <span className="text-xs font-black text-white">Video Call · {characterName}</span>
            <span className="text-[9px] font-semibold text-emerald-400">Terhubung · {formatTime(callSeconds)}</span>
          </div>
        </div>
        <button
          type="button"
          onClick={handleEndCall}
          className="p-1.5 rounded-full bg-white/10 hover:bg-white/20 text-white"
          title="Tutup"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Camera permission error banner */}
      {cameraError && (
        <div className="mx-3 mt-2 bg-amber-500 text-neutral-950 rounded-xl p-2 flex items-start gap-2">
          <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
          <div className="flex-1 text-[10px] font-bold leading-tight">
            {cameraError}
            <button
              type="button"
              onClick={startCamera}
              className="block mt-1 px-2 py-1 bg-neutral-950 text-white rounded-lg text-[9px] font-bold"
            >
              Coba Lagi Kamera
            </button>
          </div>
        </div>
      )}

      {/* Main: character "screen" */}
      <div className="flex-1 relative flex flex-col items-center justify-center px-4">
        {/* Character avatar */}
        <div
          className={`relative w-32 h-32 rounded-full flex items-center justify-center text-6xl shadow-2xl border-4 ${
            isSpeaking ? 'animate-pulse scale-110' : ''
          } transition-transform duration-200`}
          style={{
            background: `radial-gradient(circle at 30% 30%, ${charConfig?.accentColor || '#F59E0B'}, ${charConfig?.baseColor || '#D97706'})`,
            borderColor: charConfig?.accentColor || '#F59E0B',
          }}
        >
          <span className="drop-shadow-lg">{emoji}</span>
          {isAnalyzing && (
            <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 bg-emerald-500 text-white text-[8px] font-black px-2 py-0.5 rounded-full flex items-center gap-1 whitespace-nowrap">
              <Sparkles className="w-2.5 h-2.5 animate-spin" style={{ animationDuration: '2s' }} />
              SEDANG MELIHAT WAJAHMU...
            </div>
          )}
        </div>

        {/* Character name tag */}
        <div className="mt-4 px-3 py-1 bg-white/10 backdrop-blur rounded-full">
          <span className="text-[10px] font-black text-white">{characterName}</span>
          <span className="text-[9px] text-white/60 font-semibold"> · Level {level} {levelTitle}</span>
        </div>

        {/* Speech bubble (roast) */}
        <div className="mt-4 w-full max-w-[300px] relative">
          <div className="bg-white text-neutral-900 rounded-2xl rounded-tl-sm px-4 py-3 shadow-xl border-2 border-amber-300">
            <p className="text-xs font-bold leading-snug whitespace-pre-wrap break-words">
              {isAnalyzing ? '*Sedang memperhatikan wajahmu dengan saksama...* 👀' : roastText}
            </p>
          </div>
          <div className="absolute -top-2 left-6 w-4 h-4 bg-white border-l-2 border-t-2 border-amber-300 rotate-45" />
        </div>

        {/* User camera PiP (picture-in-picture) */}
        {cameraOn && !cameraError && (
          <div className="absolute bottom-4 right-4 w-24 h-32 rounded-xl overflow-hidden border-2 border-white/30 shadow-2xl bg-black">
            <video
              ref={videoRef}
              autoPlay
              playsInline
              muted
              className="w-full h-full object-cover"
              style={{ transform: 'scaleX(-1)' }}
            />
            <div className="absolute bottom-1 left-1 bg-black/60 text-white text-[7px] font-bold px-1.5 py-0.5 rounded">
              KAMU 📷
            </div>
          </div>
        )}
        {(!cameraOn || cameraError) && (
          <div className="absolute bottom-4 right-4 w-24 h-32 rounded-xl border-2 border-dashed border-white/20 bg-white/5 flex flex-col items-center justify-center text-white/40">
            <VideoOff className="w-6 h-6 mb-1" />
            <span className="text-[7px] font-bold text-center px-1">KAMERA OFF</span>
          </div>
        )}
      </div>

      {/* Bottom controls */}
      <div className="px-4 pb-5 pt-3 bg-black/50 backdrop-blur-sm border-t border-white/10">
        <div className="flex items-center justify-center gap-5">
          <button
            type="button"
            onClick={toggleCamera}
            className={`w-12 h-12 rounded-full flex items-center justify-center shadow-lg transition-transform active:scale-90 ${
              cameraOn ? 'bg-white/15 text-white hover:bg-white/25' : 'bg-rose-500 text-white'
            }`}
            title={cameraOn ? 'Matikan Kamera' : 'Nyalakan Kamera'}
          >
            {cameraOn ? <Video className="w-5 h-5" /> : <VideoOff className="w-5 h-5" />}
          </button>

          <button
            type="button"
            onClick={() => triggerRoast()}
            disabled={isAnalyzing}
            className="w-16 h-16 rounded-full flex flex-col items-center justify-center shadow-xl transition-transform active:scale-90 bg-gradient-to-b from-orange-400 to-rose-600 text-white ring-4 ring-orange-300/40 disabled:opacity-60"
            title="Minta komentarin wajahmu lagi"
          >
            <Flame className="w-6 h-6" />
            <span className="text-[7px] font-black mt-0.5">ROAST AKU!</span>
          </button>

          <button
            type="button"
            onClick={() => setMicOn(!micOn)}
            className={`w-12 h-12 rounded-full flex items-center justify-center shadow-lg transition-transform active:scale-90 ${
              micOn ? 'bg-white/15 text-white hover:bg-white/25' : 'bg-rose-500 text-white'
            }`}
            title={micOn ? 'Mikrofon On' : 'Mikrofon Off'}
          >
            {micOn ? <Mic className="w-5 h-5" /> : <MicOff className="w-5 h-5" />}
          </button>
        </div>
        <button
          type="button"
          onClick={handleEndCall}
          className="mt-4 mx-auto flex items-center gap-2 px-8 py-2.5 rounded-full bg-rose-600 hover:bg-rose-700 text-white font-black text-sm shadow-lg transition-transform active:scale-95"
        >
          <Phone className="w-4 h-4" style={{ transform: 'rotate(135deg)' }} />
          <span>Akhiri Panggilan</span>
        </button>
        <p className="text-center text-[8px] text-white/40 font-semibold mt-2">
          Karakter melihat wajahmu via AI & mengomentari sesuai sifatnya · auto setiap 18 detik
        </p>
      </div>
    </div>
  );
};
