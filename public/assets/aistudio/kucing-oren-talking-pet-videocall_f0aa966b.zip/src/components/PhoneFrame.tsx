import React, { useState } from 'react';
import { Maximize2, Minimize2 } from 'lucide-react';

interface PhoneFrameProps {
  children: React.ReactNode;
}

export const PhoneFrame: React.FC<PhoneFrameProps> = ({ children }) => {
  const [isFullScreen, setIsFullScreen] = useState(false);

  return (
    <div className="w-screen h-screen flex flex-col items-center justify-center bg-gradient-to-br from-neutral-900 via-neutral-950 to-neutral-900 overflow-hidden relative">
      {/* Viewport mode toggle on desktop */}
      <div className="hidden sm:flex absolute top-4 right-4 z-50 items-center gap-2">
        <button
          type="button"
          onClick={() => setIsFullScreen(!isFullScreen)}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/10 hover:bg-white/20 text-neutral-200 text-xs font-semibold backdrop-blur-md border border-white/15 transition-all shadow-sm"
          title="Ubah Mode Layar"
        >
          {isFullScreen ? (
            <>
              <Minimize2 className="w-3.5 h-3.5" />
              <span>Mode HP</span>
            </>
          ) : (
            <>
              <Maximize2 className="w-3.5 h-3.5" />
              <span>Layar Penuh</span>
            </>
          )}
        </button>
      </div>

      {/* Main Container */}
      <div
        className={`relative transition-all duration-300 flex flex-col overflow-hidden ${
          isFullScreen
            ? 'w-full h-full max-w-lg rounded-none'
            : 'w-full max-w-[390px] h-full sm:h-[94vh] sm:max-h-[820px] sm:rounded-[48px] sm:border-[8px] sm:border-neutral-800 sm:ring-1 sm:ring-neutral-700 sm:shadow-[0_25px_60px_-15px_rgba(0,0,0,0.8)]'
        }`}
      >
        {/* Smartphone Punch Hole Camera (on desktop frame) */}
        {!isFullScreen && (
          <div className="hidden sm:flex absolute top-2 inset-x-0 z-50 justify-center pointer-events-none">
            <div className="w-3.5 h-3.5 rounded-full bg-black ring-1 ring-neutral-800 shadow-inner" />
          </div>
        )}

        {/* Screen Content */}
        <div className="relative w-full h-full overflow-hidden flex flex-col">
          {children}
        </div>
      </div>
    </div>
  );
};
