import React, { useEffect, useRef } from 'react';
import { X, Trash2, Volume2, MessageCircle, Sparkles } from 'lucide-react';
import { ChatMessage } from '../types/game';

interface ChatHistoryPanelProps {
  messages: ChatMessage[];
  characterName: string;
  onClose: () => void;
  onClear: () => void;
  onReplay?: (text: string) => void;
}

export const ChatHistoryPanel: React.FC<ChatHistoryPanelProps> = ({
  messages,
  characterName,
  onClose,
  onClear,
  onReplay,
}) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to the latest message whenever history grows
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages.length]);

  const formatTime = (ts: number) => {
    try {
      return new Date(ts).toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit' });
    } catch {
      return '';
    }
  };

  return (
    <div className="absolute inset-0 z-40 flex flex-col bg-gradient-to-b from-amber-50/95 to-orange-100/95 backdrop-blur-sm animate-in fade-in slide-in-from-bottom duration-300">
      {/* Header */}
      <div className="flex items-center justify-between px-3 py-2.5 bg-gradient-to-r from-amber-500 to-orange-500 text-white shadow-md">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-full bg-white/25 flex items-center justify-center">
            <MessageCircle className="w-4 h-4" />
          </div>
          <div className="flex flex-col leading-tight">
            <span className="text-xs font-black">Riwayat Obrolan</span>
            <span className="text-[9px] font-semibold text-amber-100">
              bersama {characterName} · {messages.length} pesan
            </span>
          </div>
        </div>
        <div className="flex items-center gap-1">
          <button
            type="button"
            onClick={onClear}
            className="p-1.5 rounded-lg hover:bg-white/20 transition-colors"
            title="Hapus riwayat obrolan"
          >
            <Trash2 className="w-4 h-4" />
          </button>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-white/20 transition-colors"
            title="Tutup"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Memory hint banner */}
      <div className="px-3 py-1.5 bg-emerald-100/80 border-b border-emerald-200 flex items-center gap-1.5">
        <Sparkles className="w-3 h-3 text-emerald-700 shrink-0" />
        <span className="text-[9px] font-bold text-emerald-900 leading-tight">
          Mode Memori AKTIF — {characterName} ingat obrolan sebelumnya & nama kamu.
        </span>
      </div>

      {/* Messages */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto px-3 py-3 space-y-2.5">
        {messages.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center text-center px-6 py-10">
            <div className="w-14 h-14 rounded-full bg-amber-200 flex items-center justify-center mb-3">
              <MessageCircle className="w-7 h-7 text-amber-600" />
            </div>
            <p className="text-xs font-bold text-amber-900 mb-1">Belum ada obrolan</p>
            <p className="text-[10px] text-amber-700 leading-snug">
              Tekan tombol mic atau ketik pesan untuk mulai ngobrol dengan {characterName}.
              Riwayat & memori tersimpan otomatis di perangkat ini.
            </p>
          </div>
        ) : (
          messages.map((msg, idx) => (
            <div
              key={`${msg.ts}-${idx}`}
              className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-[82%] group relative ${
                  msg.role === 'user'
                    ? 'bg-gradient-to-br from-amber-400 to-orange-500 text-white rounded-2xl rounded-br-sm shadow-md'
                    : 'bg-white text-neutral-800 rounded-2xl rounded-bl-sm shadow border border-amber-100'
                }`}
              >
                <div className="px-3 py-2 text-[11px] leading-snug whitespace-pre-wrap break-words">
                  {msg.text}
                </div>
                <div
                  className={`flex items-center justify-between px-2 pb-1 ${
                    msg.role === 'user' ? 'text-amber-100' : 'text-neutral-400'
                  }`}
                >
                  <span className="text-[8px] font-semibold">
                    {msg.role === 'user' ? 'Kamu' : characterName} · {formatTime(msg.ts)}
                  </span>
                  {msg.role === 'pet' && onReplay && (
                    <button
                      type="button"
                      onClick={() => onReplay(msg.text)}
                      className="opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-0.5 text-[8px] font-bold hover:text-amber-600"
                      title="Putar ulang suara"
                    >
                      <Volume2 className="w-3 h-3" />
                      <span>Putar</span>
                    </button>
                  )}
                </div>
              </div>
            </div>
          ))
        )}
      </div>

      {/* Footer hint */}
      <div className="px-3 py-2 bg-white/70 border-t border-amber-200 text-center">
        <span className="text-[9px] font-semibold text-neutral-500">
          Ketuk balon {characterName} untuk memutar ulang suaranya
        </span>
      </div>
    </div>
  );
};
