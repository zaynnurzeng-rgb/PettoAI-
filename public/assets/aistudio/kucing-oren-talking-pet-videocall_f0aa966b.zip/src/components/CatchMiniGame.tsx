import React, { useState, useEffect, useRef } from 'react';
import { X, Trophy, Sparkles, RotateCcw } from 'lucide-react';
import { sound } from '../utils/audio';
import { CharacterId } from '../types/game';

interface CatchMiniGameProps {
  characterId: CharacterId;
  onFinish: (score: number, bonusXp: number) => void;
  onClose: () => void;
}

interface FallingItem {
  id: number;
  x: number;
  y: number;
  type: 'tuna' | 'bone' | 'milk' | 'chili';
  points: number;
  emoji: string;
}

export const CatchMiniGame: React.FC<CatchMiniGameProps> = ({
  characterId,
  onFinish,
  onClose,
}) => {
  const [basketX, setBasketX] = useState(50); // percentage 0-100
  const [score, setScore] = useState(0);
  const [timeLeft, setTimeLeft] = useState(25);
  const [gameOver, setGameOver] = useState(false);
  const [items, setItems] = useState<FallingItem[]>([]);
  const containerRef = useRef<HTMLDivElement>(null);

  // Character mascot emoji
  const mascotEmoji =
    characterId === 'kucing-oren' ? '🐱' : characterId === 'anjing-golden' ? '🐶' : '🦉';

  // Game timer loop
  useEffect(() => {
    if (gameOver) return;
    const timer = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          setGameOver(true);
          const bonusXp = Math.min(50, Math.floor(score / 3) + 15);
          onFinish(score, bonusXp);
          sound.playLevelUp();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [gameOver, score, onFinish]);

  // Spawn items loop
  useEffect(() => {
    if (gameOver) return;
    const spawner = setInterval(() => {
      const rand = Math.random();
      let type: FallingItem['type'] = 'tuna';
      let emoji = '🐟';
      let points = 10;

      if (rand < 0.35) {
        type = 'tuna';
        emoji = '🐟';
        points = 10;
      } else if (rand < 0.6) {
        type = 'milk';
        emoji = '🥛';
        points = 15;
      } else if (rand < 0.8) {
        type = 'bone';
        emoji = '🍖';
        points = 20;
      } else {
        type = 'chili';
        emoji = '🌶️';
        points = -15;
      }

      setItems((prev) => [
        ...prev,
        {
          id: Date.now() + Math.random(),
          x: 10 + Math.random() * 80,
          y: 0,
          type,
          points,
          emoji,
        },
      ]);
    }, 700);

    return () => clearInterval(spawner);
  }, [gameOver]);

  // Move items & check collision
  useEffect(() => {
    if (gameOver) return;
    const physics = setInterval(() => {
      setItems((prev) => {
        const next: FallingItem[] = [];
        for (const item of prev) {
          const newY = item.y + 4.5;

          // Check catch near bottom (y between 78 and 92)
          if (newY >= 78 && newY <= 92) {
            const distance = Math.abs(item.x - basketX);
            if (distance < 14) {
              // Caught!
              if (item.type === 'chili') {
                sound.playSpicy();
                setScore((s) => Math.max(0, s + item.points));
              } else {
                sound.playMunch();
                setScore((s) => s + item.points);
              }
              continue;
            }
          }

          if (newY < 100) {
            next.push({ ...item, y: newY });
          }
        }
        return next;
      });
    }, 50);

    return () => clearInterval(physics);
  }, [basketX, gameOver]);

  // Pointer drag to move basket
  const handlePointerMove = (e: React.PointerEvent) => {
    if (!containerRef.current) return;
    const rect = containerRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    setBasketX(Math.max(10, Math.min(90, x)));
  };

  const handleRestart = () => {
    setScore(0);
    setTimeLeft(25);
    setGameOver(false);
    setItems([]);
  };

  return (
    <div className="absolute inset-0 z-50 bg-black/70 backdrop-blur-md flex items-center justify-center p-3 select-none">
      <div className="bg-gradient-to-b from-[#FEF3C7] to-[#FED7AA] rounded-3xl p-4 w-full max-w-sm shadow-2xl border-4 border-amber-400 relative overflow-hidden flex flex-col h-[520px]">
        {/* Top Header */}
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <span className="text-2xl">{mascotEmoji}</span>
            <div>
              <h3 className="text-sm font-black text-amber-950 leading-none">
                Tangkap Camilan!
              </h3>
              <span className="text-[10px] text-amber-800 font-bold">
                Gerakkan {mascotEmoji} untuk menangkap makanan
              </span>
            </div>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-7 h-7 rounded-full bg-white/80 hover:bg-white flex items-center justify-center text-neutral-700 shadow-sm"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Score & Timer HUD */}
        <div className="flex items-center justify-between bg-white/90 rounded-2xl px-4 py-2 mb-2 shadow-sm border border-amber-200">
          <div className="flex items-center gap-1.5 font-black text-amber-950 text-sm">
            <Trophy className="w-4 h-4 text-amber-500" />
            <span>Skor: {score}</span>
          </div>
          <div className="flex items-center gap-1 font-black text-rose-600 text-sm tabular-nums">
            <span>⏱️ {timeLeft}s</span>
          </div>
        </div>

        {/* Playfield Canvas */}
        <div
          ref={containerRef}
          onPointerMove={handlePointerMove}
          className="relative flex-1 bg-gradient-to-b from-sky-100 to-amber-50 rounded-2xl overflow-hidden border-2 border-amber-300 shadow-inner cursor-pointer touch-none"
        >
          {/* Falling Items */}
          {items.map((item) => (
            <div
              key={item.id}
              style={{
                left: `${item.x}%`,
                top: `${item.y}%`,
                transform: 'translate(-50%, -50%)',
              }}
              className="absolute text-2xl transition-all duration-75 pointer-events-none drop-shadow"
            >
              {item.emoji}
            </div>
          ))}

          {/* Player Catcher Basket with Mascot Avatar */}
          <div
            style={{
              left: `${basketX}%`,
              transform: 'translateX(-50%)',
            }}
            className="absolute bottom-3 flex flex-col items-center pointer-events-none transition-all duration-75"
          >
            <div className="text-3xl drop-shadow-md animate-bounce">{mascotEmoji}</div>
            <div className="w-16 h-7 rounded-b-xl rounded-t-sm bg-gradient-to-b from-amber-600 to-amber-800 border-2 border-amber-950 shadow-md flex items-center justify-center text-[10px] text-white font-black">
              MANGKUK
            </div>
          </div>
        </div>

        {/* Game Over Screen */}
        {gameOver && (
          <div className="absolute inset-0 bg-black/75 backdrop-blur-sm flex flex-col items-center justify-center p-6 text-center z-50 animate-in zoom-in-95">
            <div className="text-5xl mb-2">🎉</div>
            <h4 className="text-xl font-black text-white mb-1">Permainan Selesai!</h4>
            <p className="text-xs text-amber-200 mb-4">
              Skor Kamu: <span className="font-bold text-white text-base">{score}</span>
            </p>

            <div className="bg-white/10 rounded-2xl p-3 mb-5 border border-white/20 text-white text-xs">
              <div className="flex items-center justify-center gap-1.5 font-bold text-amber-300">
                <Sparkles className="w-4 h-4" />
                <span>+{Math.min(50, Math.floor(score / 3) + 15)} Bonus XP Kesukaan didapat!</span>
              </div>
            </div>

            <div className="flex gap-2 w-full">
              <button
                type="button"
                onClick={handleRestart}
                className="flex-1 py-2.5 bg-neutral-700 hover:bg-neutral-600 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 shadow"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                Main Lagi
              </button>
              <button
                type="button"
                onClick={onClose}
                className="flex-1 py-2.5 bg-amber-500 hover:bg-amber-600 text-neutral-950 font-black text-xs rounded-xl shadow"
              >
                Selesai Main
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
