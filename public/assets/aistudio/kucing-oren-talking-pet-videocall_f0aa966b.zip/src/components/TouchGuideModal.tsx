import React from 'react';
import { X, Hand, Sparkles, Smile, Star, Zap } from 'lucide-react';

interface TouchGuideModalProps {
  onClose: () => void;
  onSimulateTouch: (zone: 'head' | 'belly' | 'tail' | 'feet', type: 'tap' | 'pet') => void;
}

export const TouchGuideModal: React.FC<TouchGuideModalProps> = ({
  onClose,
  onSimulateTouch,
}) => {
  const interactions = [
    {
      title: 'Kepala & Dagu (Head)',
      tapDesc: 'Getok/Sentuh sekali → Kaget & Pusing berputar 💫',
      petDesc: 'Elus bolak-balik (Gosok) → Purring dengkuran nikmat, Hati berterbangan (+5 XP) 💖',
      icon: '🐱',
      actionTap: () => onSimulateTouch('head', 'tap'),
      actionPet: () => onSimulateTouch('head', 'pet'),
    },
    {
      title: 'Perut Bucit (Belly)',
      tapDesc: 'Colek perut → Geli tertawa & bergoyang heboh 😆',
      petDesc: 'Usap perut santai → Diterima dengan santai jika sudah akrab ✨',
      icon: '🐾',
      actionTap: () => onSimulateTouch('belly', 'tap'),
      actionPet: () => onSimulateTouch('belly', 'pet'),
    },
    {
      title: 'Telinga / Kuping (Ears)',
      tapDesc: 'Pencet telinga → Gerak refleks radar pendengaran berdenging 👂',
      petDesc: 'Sentuh lembut telinga → Mengusap wajah malu-malu',
      icon: '✨',
      actionTap: () => onSimulateTouch('head', 'tap'),
      actionPet: () => onSimulateTouch('head', 'pet'),
    },
    {
      title: 'Ekor Berbulu (Tail)',
      tapDesc: 'Tarik ekor → Kucing melompat kaget dan memprotes! 🙀',
      petDesc: 'Ekor bergoyang pelan jika merasa disayangi',
      icon: '🧶',
      actionTap: () => onSimulateTouch('tail', 'tap'),
      actionPet: () => onSimulateTouch('tail', 'tap'),
    },
  ];

  return (
    <div className="absolute inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 select-none animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl p-5 w-full max-w-sm shadow-2xl border-2 border-rose-300 max-h-[88%] overflow-y-auto">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <span className="w-8 h-8 rounded-full bg-rose-500 text-white flex items-center justify-center">
              <Hand className="w-4 h-4" />
            </span>
            <h3 className="text-base font-black text-neutral-900">
              Panduan Sentuhan Tubuh
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-neutral-100 hover:bg-neutral-200 flex items-center justify-center text-neutral-600"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <p className="text-xs text-neutral-600 mb-4 leading-relaxed">
          Sama seperti game <strong>Talking Tom</strong>, kamu bisa menyentuh langsung bagian badan karakter di layar, atau mengelusnya dengan menggeser jari/kursor!
        </p>

        <div className="space-y-3">
          {interactions.map((item, idx) => (
            <div
              key={idx}
              className="p-3 rounded-2xl bg-rose-50/60 border border-rose-200/80 text-xs"
            >
              <div className="font-extrabold text-neutral-900 mb-1 flex items-center justify-between">
                <span>{item.icon} {item.title}</span>
                <div className="flex gap-1">
                  <button
                    type="button"
                    onClick={() => {
                      item.actionTap();
                      onClose();
                    }}
                    className="px-2 py-0.5 bg-white hover:bg-rose-100 text-rose-700 font-bold rounded-lg border border-rose-200 text-[10px]"
                  >
                    Coba Ketuk
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      item.actionPet();
                      onClose();
                    }}
                    className="px-2 py-0.5 bg-rose-500 hover:bg-rose-600 text-white font-bold rounded-lg text-[10px]"
                  >
                    Coba Elus
                  </button>
                </div>
              </div>
              <p className="text-neutral-700 font-medium mb-1">• {item.tapDesc}</p>
              <p className="text-rose-700 font-medium">• {item.petDesc}</p>
            </div>
          ))}
        </div>

        <button
          type="button"
          onClick={onClose}
          className="w-full mt-4 py-2.5 bg-rose-500 hover:bg-rose-600 text-white font-extrabold text-xs rounded-xl shadow-md transition-all active:scale-98"
        >
          Mengerti, Ayo Mainkan!
        </button>
      </div>
    </div>
  );
};
