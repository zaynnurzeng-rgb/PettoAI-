import React, { useState, useEffect, useRef } from 'react';
import { CharacterId, PetReaction, TouchZone } from '../types/game';
import { sound } from '../utils/audio';

interface PetCharacterProps {
  characterId: CharacterId;
  reaction: PetReaction;
  onZoneInteract: (zone: TouchZone, type: 'tap' | 'pet') => void;
  outfit: {
    hat?: string;
    glasses?: string;
    neck?: string;
  };
  isTalking?: boolean;
}

export const PetCharacter: React.FC<PetCharacterProps> = ({
  characterId,
  reaction,
  onZoneInteract,
  outfit,
  isTalking = false,
}) => {
  const [mouthOpen, setMouthOpen] = useState(false);
  const [blinking, setBlinking] = useState(false);
  const [swayAngle, setSwayAngle] = useState(0);
  const [pettingZone, setPettingZone] = useState<TouchZone | null>(null);
  const [hearts, setHearts] = useState<{ id: number; x: number; y: number }[]>([]);
  const strokeCountRef = useRef(0);
  const lastMoveTimeRef = useRef(0);

  // Blinking loop
  useEffect(() => {
    const blinkInterval = setInterval(() => {
      setBlinking(true);
      setTimeout(() => setBlinking(false), 180);
    }, 3800 + Math.random() * 2000);
    return () => clearInterval(blinkInterval);
  }, []);

  // Talking mouth animation loop
  useEffect(() => {
    if (!isTalking && reaction !== 'eating') {
      setMouthOpen(false);
      return;
    }
    const talkInterval = setInterval(() => {
      setMouthOpen((prev) => !prev);
    }, 120);
    return () => clearInterval(talkInterval);
  }, [isTalking, reaction]);

  // Gentle breathing / idle sway
  useEffect(() => {
    let frame = 0;
    const interval = setInterval(() => {
      frame++;
      setSwayAngle(Math.sin(frame * 0.08) * 1.5);
    }, 50);
    return () => clearInterval(interval);
  }, []);

  // Handle Drag/Stroke Petting
  const handlePointerMove = (e: React.PointerEvent, zone: TouchZone) => {
    if (e.buttons !== 1) return; // Only when primary mouse button/finger is down
    const now = Date.now();
    if (now - lastMoveTimeRef.current > 120) {
      lastMoveTimeRef.current = now;
      strokeCountRef.current++;

      if (strokeCountRef.current >= 3) {
        strokeCountRef.current = 0;
        setPettingZone(zone);
        sound.startPurr();

        // Spawn floating heart
        const rect = e.currentTarget.getBoundingClientRect();
        const clientX = e.clientX - rect.left;
        const clientY = e.clientY - rect.top;
        const newHeart = { id: Date.now() + Math.random(), x: clientX, y: clientY };
        setHearts((prev) => [...prev.slice(-6), newHeart]);

        onZoneInteract(zone, 'pet');

        setTimeout(() => {
          sound.stopPurr();
          setPettingZone(null);
        }, 1200);
      }
    }
  };

  const handlePointerUp = () => {
    strokeCountRef.current = 0;
    sound.stopPurr();
  };

  // Expression overrides
  const isHappy = reaction === 'happy' || pettingZone !== null;
  const isAngry = reaction === 'angry';
  const isDizzy = reaction === 'dizzy';
  const isTickled = reaction === 'tickled';
  const isSpicy = reaction === 'spicy';

  return (
    <div
      className="relative w-full h-[380px] flex items-center justify-center select-none"
      onPointerUp={handlePointerUp}
      onPointerLeave={handlePointerUp}
    >
      {/* Floating hearts during petting */}
      {hearts.map((h) => (
        <div
          key={h.id}
          style={{ left: `${h.x}px`, top: `${h.y}px` }}
          className="absolute z-40 pointer-events-none text-2xl animate-bounce transition-all duration-700 opacity-90"
        >
          💖
        </div>
      ))}

      {/* Dizzy cartoon stars */}
      {isDizzy && (
        <div className="absolute top-8 z-40 flex gap-4 text-xl animate-spin pointer-events-none">
          <span>💫</span>
          <span>⭐</span>
          <span>💫</span>
        </div>
      )}

      {/* Spicy fire smoke */}
      {isSpicy && (
        <div className="absolute top-2 z-40 flex gap-6 text-3xl animate-bounce pointer-events-none">
          <span>🔥</span>
          <span>💨</span>
          <span>🔥</span>
        </div>
      )}

      {/* Main Character Body Container with physics sway and reaction styles */}
      <div
        style={{
          transform: `rotate(${reaction === 'dizzy' ? Math.sin(Date.now()) * 8 : swayAngle}deg) scale(${
            isTickled ? 1.05 : 1
          })`,
          transition: 'transform 0.15s cubic-bezier(0.16, 1, 0.3, 1)',
        }}
        className={`relative w-[240px] h-[340px] flex items-center justify-center ${
          isSpicy ? 'brightness-110 filter hue-rotate-[-30deg]' : ''
        }`}
      >
        {/* CHARACTER 1: KUCING OREN (Matching User Attachment) */}
        {characterId === 'kucing-oren' && (
          <svg
            viewBox="0 0 240 340"
            className="w-full h-full drop-shadow-xl overflow-visible cursor-pointer"
          >
            <defs>
              {/* Fur Gradients */}
              <linearGradient id="catFur" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#FB923C" />
                <stop offset="100%" stopColor="#EA580C" />
              </linearGradient>
              <linearGradient id="catBelly" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#FEF3C7" />
                <stop offset="100%" stopColor="#FED7AA" />
              </linearGradient>
              <linearGradient id="catEarInner" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#FDA4AF" />
                <stop offset="100%" stopColor="#F43F5E" />
              </linearGradient>
            </defs>

            {/* Curled Tail (Back Right) - Tap Hotzone */}
            <g
              onClick={() => onZoneInteract('tail', 'tap')}
              className="cursor-pointer transition-transform origin-bottom-left hover:scale-105 active:rotate-12"
            >
              <path
                d="M 145 220 C 175 225, 205 240, 200 200 C 195 180, 185 170, 180 180 C 175 195, 160 215, 140 225"
                fill="none"
                stroke="url(#catFur)"
                strokeWidth="18"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <path
                d="M 145 220 C 175 225, 205 240, 200 200 C 195 180, 185 170, 180 180 C 175 195, 160 215, 140 225"
                fill="none"
                stroke="#C2410C"
                strokeWidth="2.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="opacity-40"
              />
            </g>

            {/* Standing Hind Paws / Feet - Tap Hotzone */}
            <g
              onClick={() => onZoneInteract('feet', 'tap')}
              className="cursor-pointer hover:translate-y-[-2px] active:translate-y-1 transition-transform"
            >
              {/* Left foot */}
              <ellipse cx="102" cy="246" rx="14" ry="8" fill="url(#catFur)" stroke="#9A3412" strokeWidth="2.5" />
              {/* Right foot */}
              <ellipse cx="138" cy="246" rx="14" ry="8" fill="url(#catFur)" stroke="#9A3412" strokeWidth="2.5" />
              {/* Foot claws marks */}
              <line x1="97" y1="244" x2="97" y2="250" stroke="#9A3412" strokeWidth="1.5" />
              <line x1="104" y1="244" x2="104" y2="250" stroke="#9A3412" strokeWidth="1.5" />
              <line x1="135" y1="244" x2="135" y2="250" stroke="#9A3412" strokeWidth="1.5" />
              <line x1="142" y1="244" x2="142" y2="250" stroke="#9A3412" strokeWidth="1.5" />
            </g>

            {/* Cat Body & Belly - Tickle / Belly Rub Hotzone */}
            <g
              onClick={() => onZoneInteract('belly', 'tap')}
              onPointerMove={(e) => handlePointerMove(e, 'belly')}
              className="cursor-pointer transition-transform hover:scale-[1.02]"
            >
              {/* Main Body */}
              <ellipse
                cx="120"
                cy="195"
                rx="42"
                ry="48"
                fill="url(#catFur)"
                stroke="#9A3412"
                strokeWidth="3"
              />

              {/* Light Belly Patch */}
              <ellipse
                cx="120"
                cy="198"
                rx="24"
                ry="34"
                fill="url(#catBelly)"
                stroke="#FDBA74"
                strokeWidth="2"
              />

              {/* Arms Akimbo (Hands on Hips - matching reference image) */}
              <path
                d="M 80 180 C 70 190, 72 208, 92 210"
                fill="none"
                stroke="url(#catFur)"
                strokeWidth="12"
                strokeLinecap="round"
              />
              <path
                d="M 80 180 C 70 190, 72 208, 92 210"
                fill="none"
                stroke="#9A3412"
                strokeWidth="2.5"
                strokeLinecap="round"
              />

              <path
                d="M 160 180 C 170 190, 168 208, 148 210"
                fill="none"
                stroke="url(#catFur)"
                strokeWidth="12"
                strokeLinecap="round"
              />
              <path
                d="M 160 180 C 170 190, 168 208, 148 210"
                fill="none"
                stroke="#9A3412"
                strokeWidth="2.5"
                strokeLinecap="round"
              />
            </g>

            {/* Cat Ears - Tap Hotzones */}
            {/* Left Ear */}
            <g
              onClick={() => onZoneInteract('left-ear', 'tap')}
              className="cursor-pointer transition-transform origin-bottom-left hover:rotate-6 active:-rotate-12"
            >
              <polygon
                points="72,112 55,60 102,86"
                fill="url(#catFur)"
                stroke="#9A3412"
                strokeWidth="3"
                strokeLinejoin="round"
              />
              <polygon points="74,106 63,68 96,88" fill="url(#catEarInner)" opacity="0.85" />
            </g>

            {/* Right Ear */}
            <g
              onClick={() => onZoneInteract('right-ear', 'tap')}
              className="cursor-pointer transition-transform origin-bottom-right hover:-rotate-6 active:rotate-12"
            >
              <polygon
                points="168,112 185,60 138,86"
                fill="url(#catFur)"
                stroke="#9A3412"
                strokeWidth="3"
                strokeLinejoin="round"
              />
              <polygon points="166,106 177,68 144,88" fill="url(#catEarInner)" opacity="0.85" />
            </g>

            {/* Cat Head - Tap Slap / Drag Petting Hotzone */}
            <g
              onClick={() => onZoneInteract('head', 'tap')}
              onPointerMove={(e) => handlePointerMove(e, 'head')}
              className="cursor-pointer"
            >
              {/* Rounded Head with Fluffy Cheek Tufts */}
              <path
                d="M 70 110 C 60 135, 62 145, 75 160 C 95 178, 145 178, 165 160 C 178 145, 180 135, 170 110 C 160 90, 80 90, 70 110 Z"
                fill="url(#catFur)"
                stroke="#9A3412"
                strokeWidth="3.5"
                strokeLinejoin="round"
              />

              {/* Forehead Tiger Stripes */}
              <path d="M 120 95 L 120 108" stroke="#9A3412" strokeWidth="3" strokeLinecap="round" />
              <path d="M 112 98 L 108 108" stroke="#9A3412" strokeWidth="2.5" strokeLinecap="round" />
              <path d="M 128 98 L 132 108" stroke="#9A3412" strokeWidth="2.5" strokeLinecap="round" />

              {/* Eyebrows (Dynamic: Grumpy vs Happy vs Dizzy) */}
              {!isDizzy && !isHappy && (
                <g stroke="#9A3412" strokeWidth="3" strokeLinecap="round">
                  {/* Grumpy inward furrowed eyebrows */}
                  <line x1="94" y1="118" x2="110" y2="124" />
                  <line x1="146" y1="118" x2="130" y2="124" />
                </g>
              )}

              {isHappy && (
                <g stroke="#9A3412" strokeWidth="3" strokeLinecap="round">
                  {/* Happy lifted eyebrows */}
                  <path d="M 92 118 Q 102 114 112 118" fill="none" />
                  <path d="M 128 118 Q 138 114 148 118" fill="none" />
                </g>
              )}

              {/* Eyes */}
              {blinking ? (
                // Closed blinking slits
                <g stroke="#9A3412" strokeWidth="3" strokeLinecap="round">
                  <path d="M 94 134 Q 104 138 112 134" fill="none" />
                  <path d="M 128 134 Q 136 138 146 134" fill="none" />
                </g>
              ) : isDizzy ? (
                // Spiral dizzy eyes (@ @)
                <g stroke="#9A3412" strokeWidth="2.5" fill="none">
                  <path d="M 103 134 m -8 0 a 8 8 0 1 0 16 0 a 6 6 0 1 0 -12 0 a 3 3 0 1 0 6 0" />
                  <path d="M 137 134 m -8 0 a 8 8 0 1 0 16 0 a 6 6 0 1 0 -12 0 a 3 3 0 1 0 6 0" />
                </g>
              ) : isHappy ? (
                // Happy curved eyes (^ ^)
                <g stroke="#9A3412" strokeWidth="3.5" fill="none" strokeLinecap="round">
                  <path d="M 94 135 Q 104 125 114 135" />
                  <path d="M 126 135 Q 136 125 146 135" />
                </g>
              ) : (
                // Normal Big Grumpy/Mischievous Amber Eyes
                <g>
                  {/* Eye whites */}
                  <ellipse cx="104" cy="132" rx="10" ry="12" fill="#FEF08A" stroke="#9A3412" strokeWidth="2" />
                  <ellipse cx="136" cy="132" rx="10" ry="12" fill="#FEF08A" stroke="#9A3412" strokeWidth="2" />
                  {/* Pupils */}
                  <ellipse
                    cx={104 + (reaction === 'tickled' ? 2 : 0)}
                    cy={132}
                    rx="5"
                    ry="9"
                    fill="#1C1917"
                  />
                  <ellipse
                    cx={136 + (reaction === 'tickled' ? 2 : 0)}
                    cy={132}
                    rx="5"
                    ry="9"
                    fill="#1C1917"
                  />
                  {/* Eye sparkles */}
                  <circle cx="102" cy="128" r="2" fill="white" />
                  <circle cx="134" cy="128" r="2" fill="white" />
                </g>
              )}

              {/* Cheeks Blush (Visible when happy or being pet) */}
              {isHappy && (
                <g fill="#F43F5E" opacity="0.6">
                  <ellipse cx="88" cy="144" rx="7" ry="4" />
                  <ellipse cx="152" cy="144" rx="7" ry="4" />
                </g>
              )}

              {/* Cute Cat Nose */}
              <polygon points="120,143 115,138 125,138" fill="#F43F5E" stroke="#9A3412" strokeWidth="1" />

              {/* Mouth (Open when talking/eating/tickled, closed grumpy "w" otherwise) */}
              {mouthOpen || isTickled ? (
                <path
                  d="M 112 146 Q 120 162 128 146 Z"
                  fill="#991B1B"
                  stroke="#9A3412"
                  strokeWidth="2"
                >
                  {/* Small pink tongue */}
                  <path d="M 116 153 Q 120 159 124 153 Z" fill="#F43F5E" />
                </path>
              ) : (
                <path
                  d="M 114 145 Q 120 148 120 144 Q 120 148 126 145"
                  fill="none"
                  stroke="#9A3412"
                  strokeWidth="2.5"
                  strokeLinecap="round"
                />
              )}

              {/* Cat Whiskers */}
              <g stroke="#9A3412" strokeWidth="1.5" strokeLinecap="round" opacity="0.7">
                <line x1="78" y1="140" x2="60" y2="136" />
                <line x1="78" y1="144" x2="58" y2="146" />
                <line x1="162" y1="140" x2="180" y2="136" />
                <line x1="162" y1="144" x2="182" y2="146" />
              </g>
            </g>

            {/* OUTFITS OVERLAY ON KUCING OREN */}
            {/* Glasses */}
            {outfit.glasses === 'thug_life' && (
              <g className="cursor-pointer">
                {/* 8-bit black pixel sunglasses */}
                <rect x="90" y="124" width="26" height="12" fill="#0F172A" stroke="#000" strokeWidth="1.5" />
                <rect x="124" y="124" width="26" height="12" fill="#0F172A" stroke="#000" strokeWidth="1.5" />
                <rect x="116" y="126" width="8" height="4" fill="#0F172A" />
                {/* White pixel glints */}
                <rect x="94" y="126" width="4" height="4" fill="white" />
                <rect x="128" y="126" width="4" height="4" fill="white" />
              </g>
            )}

            {outfit.glasses === 'professor_specs' && (
              <g stroke="#D97706" strokeWidth="2.5" fill="none">
                <circle cx="104" cy="132" r="14" />
                <circle cx="136" cy="132" r="14" />
                <line x1="118" y1="132" x2="122" y2="132" />
              </g>
            )}

            {outfit.glasses === 'cool_shades' && (
              <g>
                <path d="M 88 124 L 118 124 L 114 140 L 92 140 Z" fill="#06B6D4" stroke="#0891B2" strokeWidth="1.5" />
                <path d="M 122 124 L 152 124 L 148 140 L 126 140 Z" fill="#06B6D4" stroke="#0891B2" strokeWidth="1.5" />
                <line x1="118" y1="126" x2="122" y2="126" stroke="#0891B2" strokeWidth="2" />
              </g>
            )}

            {/* Hats */}
            {outfit.hat === 'cowboy_hat' && (
              <g className="cursor-pointer">
                <ellipse cx="120" cy="85" rx="55" ry="14" fill="#B45309" stroke="#78350F" strokeWidth="2" />
                <path d="M 95 84 C 95 55, 145 55, 145 84 Z" fill="#D97706" stroke="#78350F" strokeWidth="2" />
                <rect x="95" y="78" width="50" height="5" fill="#78350F" />
              </g>
            )}

            {outfit.hat === 'crown_sultan' && (
              <g className="cursor-pointer">
                <polygon
                  points="90,85 92,60 106,72 120,52 134,72 148,60 150,85"
                  fill="#FACC15"
                  stroke="#CA8A04"
                  strokeWidth="2.5"
                  strokeLinejoin="round"
                />
                <circle cx="120" cy="74" r="3" fill="#DC2626" />
                <circle cx="104" cy="77" r="2.5" fill="#2563EB" />
                <circle cx="136" cy="77" r="2.5" fill="#16A34A" />
              </g>
            )}

            {outfit.hat === 'chef_hat' && (
              <g className="cursor-pointer">
                <path
                  d="M 96 85 C 80 75, 80 50, 105 48 C 115 40, 130 40, 138 48 C 155 50, 160 70, 144 85 Z"
                  fill="#FFFFFF"
                  stroke="#E2E8F0"
                  strokeWidth="2"
                />
                <rect x="96" y="80" width="48" height="10" fill="#F8FAFC" stroke="#CBD5E1" strokeWidth="1.5" />
              </g>
            )}

            {outfit.hat === 'party_hat' && (
              <g className="cursor-pointer">
                <polygon points="120,40 100,85 140,85" fill="#EC4899" stroke="#BE185D" strokeWidth="2" />
                <circle cx="120" cy="38" r="5" fill="#FACC15" />
                <line x1="105" y1="75" x2="135" y2="75" stroke="#FACC15" strokeWidth="3" />
              </g>
            )}

            {/* Neck accessories */}
            {outfit.neck === 'red_bowtie' && (
              <g className="cursor-pointer">
                <polygon points="108,168 120,174 108,180" fill="#EF4444" stroke="#B91C1C" strokeWidth="1.5" />
                <polygon points="132,168 120,174 132,180" fill="#EF4444" stroke="#B91C1C" strokeWidth="1.5" />
                <circle cx="120" cy="174" r="4" fill="#DC2626" />
              </g>
            )}

            {outfit.neck === 'gold_chain' && (
              <g stroke="#EAB308" strokeWidth="3" fill="none">
                <path d="M 98 168 Q 120 186 142 168" />
                <circle cx="120" cy="186" r="5" fill="#FACC15" stroke="#CA8A04" strokeWidth="1" />
              </g>
            )}

            {outfit.neck === 'warm_scarf' && (
              <g fill="#0284C7" stroke="#0369A1" strokeWidth="2">
                <rect x="94" y="165" width="52" height="12" rx="6" />
                <rect x="130" y="172" width="12" height="24" rx="3" />
              </g>
            )}
          </svg>
        )}

        {/* CHARACTER 2: BURUNG HANTU BIJAK */}
        {characterId === 'burung-hantu' && (
          <svg
            viewBox="0 0 240 340"
            className="w-full h-full drop-shadow-xl overflow-visible cursor-pointer"
          >
            <defs>
              <linearGradient id="owlFur" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#9333EA" />
                <stop offset="100%" stopColor="#6B21A8" />
              </linearGradient>
              <linearGradient id="owlChest" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#EDE9FE" />
                <stop offset="100%" stopColor="#DDD6FE" />
              </linearGradient>
            </defs>

            {/* Owl Body & Wings */}
            <g
              onClick={() => onZoneInteract('belly', 'tap')}
              onPointerMove={(e) => handlePointerMove(e, 'belly')}
              className="cursor-pointer"
            >
              <ellipse cx="120" cy="190" rx="55" ry="65" fill="url(#owlFur)" stroke="#581C87" strokeWidth="3.5" />
              {/* Chest feathers pattern */}
              <ellipse cx="120" cy="195" rx="34" ry="45" fill="url(#owlChest)" stroke="#C4B5FD" strokeWidth="2" />
              <path d="M 110 185 Q 120 190 130 185" fill="none" stroke="#7C3AED" strokeWidth="2" />
              <path d="M 106 200 Q 120 206 134 200" fill="none" stroke="#7C3AED" strokeWidth="2" />
              <path d="M 112 215 Q 120 220 128 215" fill="none" stroke="#7C3AED" strokeWidth="2" />

              {/* Wings */}
              <ellipse cx="68" cy="195" rx="14" ry="40" fill="#7E22CE" stroke="#581C87" strokeWidth="2.5" />
              <ellipse cx="172" cy="195" rx="14" ry="40" fill="#7E22CE" stroke="#581C87" strokeWidth="2.5" />
            </g>

            {/* Owl Claws / Feet */}
            <g onClick={() => onZoneInteract('feet', 'tap')} className="cursor-pointer">
              <ellipse cx="102" cy="254" rx="12" ry="6" fill="#F59E0B" stroke="#B45309" strokeWidth="2" />
              <ellipse cx="138" cy="254" rx="12" ry="6" fill="#F59E0B" stroke="#B45309" strokeWidth="2" />
            </g>

            {/* Owl Head & Big Spectacles */}
            <g
              onClick={() => onZoneInteract('head', 'tap')}
              onPointerMove={(e) => handlePointerMove(e, 'head')}
              className="cursor-pointer"
            >
              {/* Ear tufts */}
              <polygon points="80,100 68,60 100,85" fill="#7E22CE" stroke="#581C87" strokeWidth="3" />
              <polygon points="160,100 172,60 140,85" fill="#7E22CE" stroke="#581C87" strokeWidth="3" />

              {/* Head round */}
              <circle cx="120" cy="120" r="50" fill="url(#owlFur)" stroke="#581C87" strokeWidth="3.5" />

              {/* Huge Golden Eyes */}
              <circle cx="98" cy="120" r="18" fill="#FBBF24" stroke="#581C87" strokeWidth="2.5" />
              <circle cx="142" cy="120" r="18" fill="#FBBF24" stroke="#581C87" strokeWidth="2.5" />

              {/* Pupils */}
              {!blinking ? (
                <>
                  <circle cx="98" cy="120" r="9" fill="#18181B" />
                  <circle cx="142" cy="120" r="9" fill="#18181B" />
                  <circle cx="95" cy="116" r="3" fill="white" />
                  <circle cx="139" cy="116" r="3" fill="white" />
                </>
              ) : (
                <line x1="84" y1="120" x2="112" y2="120" stroke="#18181B" strokeWidth="4" />
              )}

              {/* Round Intellectual Glasses */}
              <circle cx="98" cy="120" r="22" fill="none" stroke="#D97706" strokeWidth="3" />
              <circle cx="142" cy="120" r="22" fill="none" stroke="#D97706" strokeWidth="3" />
              <line x1="120" y1="120" x2="120" y2="120" stroke="#D97706" strokeWidth="3" />

              {/* Beak */}
              <polygon points="120,132 114,144 126,144" fill="#F59E0B" stroke="#B45309" strokeWidth="1.5" />
            </g>
          </svg>
        )}

        {/* CHARACTER 3: ANJING GOLDEN */}
        {characterId === 'anjing-golden' && (
          <svg
            viewBox="0 0 240 340"
            className="w-full h-full drop-shadow-xl overflow-visible cursor-pointer"
          >
            <defs>
              <linearGradient id="dogFur" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#FCD34D" />
                <stop offset="100%" stopColor="#F59E0B" />
              </linearGradient>
            </defs>

            {/* Wagging Golden Tail */}
            <g
              onClick={() => onZoneInteract('tail', 'tap')}
              className="cursor-pointer transition-transform origin-bottom-left hover:rotate-12 animate-wiggle"
            >
              <path
                d="M 150 210 Q 195 210 205 170"
                fill="none"
                stroke="url(#dogFur)"
                strokeWidth="18"
                strokeLinecap="round"
              />
            </g>

            {/* Dog Paws */}
            <g onClick={() => onZoneInteract('feet', 'tap')} className="cursor-pointer">
              <ellipse cx="100" cy="248" rx="14" ry="8" fill="url(#dogFur)" stroke="#B45309" strokeWidth="2.5" />
              <ellipse cx="140" cy="248" rx="14" ry="8" fill="url(#dogFur)" stroke="#B45309" strokeWidth="2.5" />
            </g>

            {/* Dog Body */}
            <g
              onClick={() => onZoneInteract('belly', 'tap')}
              onPointerMove={(e) => handlePointerMove(e, 'belly')}
              className="cursor-pointer"
            >
              <ellipse cx="120" cy="190" rx="46" ry="52" fill="url(#dogFur)" stroke="#B45309" strokeWidth="3" />
              <ellipse cx="120" cy="195" rx="26" ry="34" fill="#FEF3C7" />
            </g>

            {/* Floppy Dog Ears */}
            <g onClick={() => onZoneInteract('left-ear', 'tap')} className="cursor-pointer">
              <path
                d="M 72 105 C 50 120, 50 160, 68 170 C 78 165, 78 120, 72 105 Z"
                fill="#D97706"
                stroke="#92400E"
                strokeWidth="2.5"
              />
            </g>
            <g onClick={() => onZoneInteract('right-ear', 'tap')} className="cursor-pointer">
              <path
                d="M 168 105 C 190 120, 190 160, 172 170 C 162 165, 162 120, 168 105 Z"
                fill="#D97706"
                stroke="#92400E"
                strokeWidth="2.5"
              />
            </g>

            {/* Dog Head */}
            <g
              onClick={() => onZoneInteract('head', 'tap')}
              onPointerMove={(e) => handlePointerMove(e, 'head')}
              className="cursor-pointer"
            >
              <circle cx="120" cy="120" r="48" fill="url(#dogFur)" stroke="#B45309" strokeWidth="3" />

              {/* Eyes */}
              <circle cx="102" cy="116" r="8" fill="#1C1917" />
              <circle cx="138" cy="116" r="8" fill="#1C1917" />
              <circle cx="100" cy="114" r="2.5" fill="white" />
              <circle cx="136" cy="114" r="2.5" fill="white" />

              {/* Muzzle */}
              <ellipse cx="120" cy="136" rx="20" ry="16" fill="#FEF3C7" stroke="#B45309" strokeWidth="1.5" />
              {/* Big Black Nose */}
              <ellipse cx="120" cy="130" rx="8" ry="6" fill="#1C1917" />

              {/* Happy Open Mouth with Slurpy Pink Tongue */}
              <path d="M 112 140 Q 120 152 128 140" fill="#991B1B" stroke="#B45309" strokeWidth="2" />
              <path d="M 116 146 Q 120 160 124 146" fill="#F43F5E" />
            </g>
          </svg>
        )}
      </div>
    </div>
  );
};
