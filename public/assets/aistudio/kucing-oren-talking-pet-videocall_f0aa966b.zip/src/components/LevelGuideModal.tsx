import React from 'react';
import { X, Heart, Sparkles, Trophy, Gift } from 'lucide-react';
import { CHARACTERS } from '../data/characters';
import { CharacterId } from '../types/game';

interface LevelGuideModalProps {
  characterId: CharacterId;
  currentLevel: number;
  currentXp: number;
  onClose: () => void;
}

export const LevelGuideModal: React.FC<LevelGuideModalProps> = ({
  characterId,
  currentLevel,
  currentXp,
  onClose,
}) => {
  const char = CHARACTERS[characterId];

  const levels = [
    {
      level: 1,
      title: char.levelTitles[1],
      attitude: 'Jutek, sinis, defensif & curiga.',
      unlocks: 'Baju dasar, Topi Koboi & Kacamata Thug Life.',
    },
    {
      level: 2,
      title: char.levelTitles[2],
      attitude: 'Mulai penasaran, mau makan jika ditawari.',
      unlocks: 'Buka Makanan Tulang & Kopi, Topi Pesta, Kacamata Profesor.',
    },
    {
      level: 3,
      title: char.levelTitles[3],
      attitude: 'Senang dielus, mau diajak ngobrol santai.',
      unlocks: 'Topi Koki Bintang 5, Kacamata Pantai, Kalung Emas.',
    },
    {
      level: 4,
      title: char.levelTitles[4],
      attitude: 'Bestie sejati! Menganggap kamu kawan terbaik.',
      unlocks: 'Syal Hangat & Mahkota Emas Sultan!',
    },
    {
      level: 5,
      title: char.levelTitles[5],
      attitude: 'Cinta mati! Selalu manja, purring & menempel.',
      unlocks: 'Gelar Babu Emas Tertinggi & Pose Sayang Eksklusif 👑💖',
    },
  ];

  return (
    <div className="absolute inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 select-none animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl p-5 w-full max-w-sm shadow-2xl border-2 border-rose-300 max-h-[88%] overflow-y-auto">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <span className="w-8 h-8 rounded-full bg-rose-500 text-white flex items-center justify-center">
              <Heart className="w-4 h-4 fill-white" />
            </span>
            <h3 className="text-base font-black text-neutral-900">
              Sistem Level Kesukaan
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-neutral-100 hover:bg-neutral-200 flex items-center justify-center text-neutral-600"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Current status card */}
        <div className="bg-gradient-to-r from-rose-50 to-pink-50 rounded-2xl p-3 border border-rose-200 mb-4 flex items-center justify-between">
          <div>
            <div className="text-[10px] font-bold text-rose-500 uppercase tracking-wider">
              Status Kesukaan Saat Ini
            </div>
            <div className="text-sm font-black text-neutral-900">
              Level {currentLevel}: {char.levelTitles[currentLevel]}
            </div>
          </div>
          <div className="text-right">
            <span className="text-xs font-black text-rose-600 tabular-nums">
              {currentXp} / 100 XP
            </span>
          </div>
        </div>

        {/* Ways to gain XP */}
        <div className="mb-4">
          <h4 className="text-xs font-black text-neutral-800 mb-2 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-amber-500" />
            Cara Menambah Rasa Sayang (+XP):
          </h4>
          <div className="grid grid-cols-2 gap-2 text-[11px]">
            <div className="bg-neutral-50 p-2 rounded-xl border border-neutral-200">
              <span className="font-extrabold text-neutral-800">🖐️ Elus Kepala/Perut</span>
              <div className="font-bold text-rose-600 mt-0.5">+5 XP per elusan</div>
            </div>
            <div className="bg-neutral-50 p-2 rounded-xl border border-neutral-200">
              <span className="font-extrabold text-neutral-800">
                {char.name === 'ZAYN' ? '🐟' : char.name === 'HERU' ? '🍖' : '☕'} Makanan Favorit
              </span>
              <div className="font-bold text-rose-600 mt-0.5">
                +35 XP ({char.name === 'ZAYN' ? 'Tuna' : char.name === 'HERU' ? 'Tulang' : 'Kopi'})
              </div>
            </div>
            <div className="bg-neutral-50 p-2 rounded-xl border border-neutral-200">
              <span className="font-extrabold text-neutral-800">🎙️ Ajak Bicara Mic</span>
              <div className="font-bold text-rose-600 mt-0.5">+15 XP per suara</div>
            </div>
            <div className="bg-neutral-50 p-2 rounded-xl border border-neutral-200">
              <span className="font-extrabold text-neutral-800">🎮 Main Mini Game</span>
              <div className="font-bold text-rose-600 mt-0.5">Hingga +50 XP</div>
            </div>
          </div>
        </div>

        {/* Levels Timeline */}
        <div className="space-y-2 mb-4">
          <h4 className="text-xs font-black text-neutral-800 mb-2 flex items-center gap-1.5">
            <Trophy className="w-3.5 h-3.5 text-amber-500" />
            Jenjang Tingkat Kedekatan:
          </h4>
          {levels.map((lvl) => {
            const isCurrent = lvl.level === currentLevel;
            const isPassed = lvl.level < currentLevel;

            return (
              <div
                key={lvl.level}
                className={`p-2.5 rounded-2xl border text-xs transition-all ${
                  isCurrent
                    ? 'bg-rose-50 border-rose-400 ring-2 ring-rose-200 shadow-sm'
                    : isPassed
                    ? 'bg-neutral-50 border-neutral-200 opacity-80'
                    : 'bg-white border-neutral-200 opacity-60'
                }`}
              >
                <div className="flex items-center justify-between mb-0.5">
                  <span className="font-black text-neutral-900">
                    Lv. {lvl.level}: {lvl.title}
                  </span>
                  {isCurrent && (
                    <span className="text-[9px] font-black bg-rose-500 text-white px-2 py-0.5 rounded-full">
                      SEKARANG
                    </span>
                  )}
                </div>
                <p className="text-[11px] text-neutral-600 mb-1">
                  Sikap: {lvl.attitude}
                </p>
                <div className="text-[10px] font-semibold text-amber-800 flex items-center gap-1">
                  <Gift className="w-3 h-3 text-amber-600 shrink-0" />
                  <span>{lvl.unlocks}</span>
                </div>
              </div>
            );
          })}
        </div>

        <button
          type="button"
          onClick={onClose}
          className="w-full py-2.5 bg-rose-500 hover:bg-rose-600 text-white font-extrabold text-xs rounded-xl shadow-md transition-all active:scale-98"
        >
          Tutup Panduan
        </button>
      </div>
    </div>
  );
};
