/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useRef } from 'react';
import { PhoneFrame } from './components/PhoneFrame';
import { RoomBackground } from './components/RoomBackground';
import { TopBar } from './components/TopBar';
import { SpeechBubble } from './components/SpeechBubble';
import { PetCharacter } from './components/PetCharacter';
import { AffectionBar } from './components/AffectionBar';
import { ActionBar } from './components/ActionBar';
import { MicrophoneButton } from './components/MicrophoneButton';
import { FoodDrawer } from './components/FoodDrawer';
import { WardrobeDrawer } from './components/WardrobeDrawer';
import { TouchGuideModal } from './components/TouchGuideModal';
import { LevelUpModal } from './components/LevelUpModal';
import { CatchMiniGame } from './components/CatchMiniGame';
import { SettingsModal } from './components/SettingsModal';
import { LevelGuideModal } from './components/LevelGuideModal';
import { VideoCallModal } from './components/VideoCallModal';
import { CHARACTERS } from './data/characters';
import { CharacterId, PetReaction, TouchZone, FoodItem, CharacterProgress } from './types/game';
import { sound, speakInTomVoice } from './utils/audio';

const STORAGE_KEY = 'talking_pet_game_state_v1';

export default function App() {
  const [activeCharacterId, setActiveCharacterId] = useState<CharacterId>('kucing-oren');
  const [reaction, setReaction] = useState<PetReaction>('idle');
  const [isTalking, setIsTalking] = useState(false);
  const [activeDrawer, setActiveDrawer] = useState<'food' | 'wardrobe' | 'touch' | 'minigame' | null>(null);
  const [showSettings, setShowSettings] = useState(false);
  const [showLevelGuide, setShowLevelGuide] = useState(false);
  const [showVideoCall, setShowVideoCall] = useState(false);
  const [levelUpData, setLevelUpData] = useState<{ level: number; title: string } | null>(null);

  // Character progress state (Level, XP, Outfits)
  const [progress, setProgress] = useState<Record<CharacterId, CharacterProgress>>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) return JSON.parse(saved);
    } catch (_) {}
    return {
      'kucing-oren': { level: 1, xp: 20, currentOutfit: {}, unlockedOutfits: [] },
      'burung-hantu': { level: 1, xp: 10, currentOutfit: {}, unlockedOutfits: [] },
      'anjing-golden': { level: 1, xp: 35, currentOutfit: {}, unlockedOutfits: [] },
    };
  });

  // Current dialogue displayed in speech bubble
  // Default matches the user screenshot verbatim for ZAYN (Kucing Oren)
  const [dialogue, setDialogue] = useState<string>(
    '*Mendengus* Serious apaan? Kalau mau ngajak gue, ZAYN si kucing oren main, mending bawa tuna kaleng biar gue nggak makin emosi.'
  );

  const currentCharConfig = CHARACTERS[activeCharacterId];
  const currentCharProgress = progress[activeCharacterId] || {
    level: 1,
    xp: 0,
    currentOutfit: {},
    unlockedOutfits: [],
  };

  // Save progress
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
    } catch (_) {}
  }, [progress]);

  // Synchronized Voice & Speech Bubble Player:
  // Updates the comic speech bubble AND immediately speaks out the exact words in the character's voice
  const speakCurrentDialogue = (
    textToSpeak: string,
    visualReaction: PetReaction = 'talking',
    postReaction: PetReaction = 'idle',
    soundIntro: boolean = false
  ) => {
    setDialogue(textToSpeak);
    setReaction(visualReaction);
    setIsTalking(true);

    speakInTomVoice(
      textToSpeak,
      activeCharacterId,
      () => {
        setIsTalking(true);
        setReaction(visualReaction);
      },
      () => {
        setIsTalking(false);
        setReaction(postReaction);
      },
      soundIntro
    );
  };

  // Update dialogue and speak when character changes
  const handleSelectCharacter = (id: CharacterId) => {
    setActiveCharacterId(id);
    const char = CHARACTERS[id];
    const lvl = progress[id]?.level || 1;
    const lines = char.dialogues[lvl] || char.dialogues[1];
    const randomLine = lines[Math.floor(Math.random() * lines.length)];
    setDialogue(randomLine);

    setReaction('talking');
    setIsTalking(true);
    speakInTomVoice(
      randomLine,
      id,
      () => {
        setIsTalking(true);
        setReaction('talking');
      },
      () => {
        setIsTalking(false);
        setReaction('idle');
      },
      true
    );
  };

  // Add XP and handle Level Up
  const addXp = (amount: number) => {
    setProgress((prev) => {
      const current = prev[activeCharacterId];
      let newXp = current.xp + amount;
      let newLevel = current.level;

      if (newXp >= 100 && newLevel < 5) {
        newLevel += 1;
        newXp = newXp - 100;
        // Trigger Level Up Modal and Voice
        setTimeout(() => {
          const title = currentCharConfig.levelTitles[newLevel];
          setLevelUpData({
            level: newLevel,
            title,
          });
          sound.playLevelUp();
          const levelUpLine = `Hore! Level kesukaan kita naik ke Level ${newLevel}: "${title}"! Makasih udah sayang sama gue! 🎉💖`;
          speakCurrentDialogue(levelUpLine, 'happy', 'idle', true);
        }, 300);
      } else if (newLevel >= 5) {
        newXp = Math.min(100, newXp);
      }

      return {
        ...prev,
        [activeCharacterId]: {
          ...current,
          level: newLevel,
          xp: newXp,
        },
      };
    });
  };

  // Handle Touch Hotzones (Talking Tom Style Body Interactions) - EVERY TOUCH SPEAKS!
  const handleZoneInteract = (zone: TouchZone, type: 'tap' | 'pet') => {
    const reactions = currentCharConfig.touchReactions;

    if (zone === 'head') {
      if (type === 'tap') {
        // Bonk / Dizzy
        sound.playBonk();
        const lines = reactions.head.tap;
        const line = lines[Math.floor(Math.random() * lines.length)];
        speakCurrentDialogue(line, 'dizzy', 'idle', false);
      } else {
        // Petting / Purring
        addXp(5);
        const lines = reactions.head.pet;
        const line = lines[Math.floor(Math.random() * lines.length)];
        speakCurrentDialogue(line, 'happy', 'idle', true);
      }
    } else if (zone === 'belly') {
      if (type === 'tap') {
        // Tickle / Poke
        sound.playGiggle();
        const lines = reactions.belly.tap;
        const line = lines[Math.floor(Math.random() * lines.length)];
        speakCurrentDialogue(line, 'tickled', 'idle', false);
      } else {
        // Belly Rub
        sound.startPurr();
        addXp(5);
        const lines = reactions.belly.pet;
        const line = lines[Math.floor(Math.random() * lines.length)];
        speakCurrentDialogue(line, 'happy', 'idle', true);
        setTimeout(() => {
          sound.stopPurr();
        }, 1500);
      }
    } else if (zone === 'left-ear' || zone === 'right-ear') {
      sound.playGiggle();
      const lines = reactions.ears;
      const line = lines[Math.floor(Math.random() * lines.length)];
      speakCurrentDialogue(line, 'surprised', 'idle', false);
    } else if (zone === 'tail') {
      sound.playBonk();
      const lines = reactions.tail;
      const line = lines[Math.floor(Math.random() * lines.length)];
      speakCurrentDialogue(line, 'angry', 'idle', false);
    } else if (zone === 'feet') {
      sound.playBonk();
      const lines = reactions.feet;
      const line = lines[Math.floor(Math.random() * lines.length)];
      speakCurrentDialogue(line, 'surprised', 'idle', false);
    }
  };

  // Feeding Handler with Spoken Reaction
  const handleFeed = (food: FoodItem) => {
    setActiveDrawer(null);

    if (food.id === 'cabe-rawit') {
      // Spicy reaction!
      sound.playSpicy();
      const spicyLine = 'HAHHH PEDES BANGET! 🔥 KUPING GUE BERASAP! SIAPA YANG NGASIH CABE?!';
      addXp(10);
      speakCurrentDialogue(spicyLine, 'spicy', 'idle', false);
      return;
    }

    sound.playMunch();
    addXp(food.xpGain);

    const foodLine =
      food.id === currentCharConfig.favFoodId
        ? `*Makan lahap* NYAMM! ${food.name} ini surga banget! Makasih babu tersayang! 😋🐟`
        : `*Kenyang* Mmm lumayan enak ${food.name}-nya. Perut gue jadi anget.`;

    speakCurrentDialogue(foodLine, 'eating', 'happy', false);
  };

  // Wardrobe Outfit Selection with Spoken Reaction
  const handleSelectOutfit = (category: 'hat' | 'glasses' | 'neck', id: string) => {
    setProgress((prev) => {
      const current = prev[activeCharacterId];
      const isNone = id.startsWith('none_');
      return {
        ...prev,
        [activeCharacterId]: {
          ...current,
          currentOutfit: {
            ...current.currentOutfit,
            [category]: isNone ? undefined : id,
          },
        },
      };
    });

    sound.playPop();
    const outfitLine = 'Wihh, gimana penampilan baru gue? Keren & fashionable kan? 😎✨';
    speakCurrentDialogue(outfitLine, 'happy', 'idle', false);
  };

  // Speech Replay with high pitch Tom voice
  const handleReplayDialogue = () => {
    speakCurrentDialogue(dialogue, 'talking', 'idle', true);
  };

  // Reset progress for testing
  const handleResetProgress = () => {
    const fresh: Record<CharacterId, CharacterProgress> = {
      'kucing-oren': { level: 1, xp: 0, currentOutfit: {}, unlockedOutfits: [] },
      'burung-hantu': { level: 1, xp: 0, currentOutfit: {}, unlockedOutfits: [] },
      'anjing-golden': { level: 1, xp: 0, currentOutfit: {}, unlockedOutfits: [] },
    };
    setProgress(fresh);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(fresh));
    } catch (_) {}
    setDialogue(CHARACTERS[activeCharacterId].dialogues[1][0]);
  };

  return (
    <PhoneFrame>
      <RoomBackground>
        {/* Top Navigation & Character Carousel */}
        <TopBar
          activeCharacterId={activeCharacterId}
          onSelectCharacter={handleSelectCharacter}
          onOpenSettings={() => setShowSettings(true)}
          onOpenInfo={() => setShowLevelGuide(true)}
        />

        {/* Comic Speech Bubble */}
        {/* Comic Speech Bubble - Clickable to interrupt / sela bicara */}
        <div className="mt-1">
          <SpeechBubble
            speakerName={currentCharConfig.name}
            text={dialogue}
            onReplayAudio={handleReplayDialogue}
            onInterrupt={() => {
              sound.interruptSpeech();
              setIsTalking(false);
              setReaction('idle');
            }}
            isTalking={isTalking}
          />
        </div>

        {/* Central Character Zone with Touch Hotspots */}
        <div className="flex-1 flex items-center justify-center relative min-h-[300px]">
          <PetCharacter
            characterId={activeCharacterId}
            reaction={reaction}
            onZoneInteract={(zone, type) => {
              if (isTalking) {
                sound.interruptSpeech();
                setIsTalking(false);
              }
              handleZoneInteract(zone, type);
            }}
            outfit={currentCharProgress.currentOutfit}
            isTalking={isTalking}
          />
        </div>

        {/* Friendship / Affection Level Progress Bar */}
        <AffectionBar
          level={currentCharProgress.level}
          xp={currentCharProgress.xp}
          levelTitle={currentCharConfig.levelTitles[currentCharProgress.level]}
          characterName={currentCharConfig.name}
          onOpenLevelGuide={() => setShowLevelGuide(true)}
        />

        {/* Action Bar (Hand / Food / Wardrobe / Mini-game) */}
        <ActionBar
          onOpenTouchGuide={() => setActiveDrawer(activeDrawer === 'touch' ? null : 'touch')}
          onOpenFood={() => setActiveDrawer(activeDrawer === 'food' ? null : 'food')}
          onOpenWardrobe={() => setActiveDrawer(activeDrawer === 'wardrobe' ? null : 'wardrobe')}
          onOpenMiniGame={() => setActiveDrawer('minigame')}
          onOpenVideoCall={() => {
            setActiveDrawer(null);
            setShowVideoCall(true);
          }}
          activeDrawer={activeDrawer}
        />

        {/* Large Glowing Golden Microphone Button with Continuous Hands-Free Chat & Animal Voices */}
        <MicrophoneButton
          characterId={activeCharacterId}
          userLevel={currentCharProgress.level}
          levelTitle={currentCharConfig.levelTitles[currentCharProgress.level]}
          isTalking={isTalking}
          onTalkingStart={() => {
            setIsTalking(true);
            setReaction('talking');
          }}
          onTalkingEnd={() => {
            setIsTalking(false);
            setReaction('idle');
          }}
          onNewDialogue={(line) => setDialogue(line)}
          onAddXp={addXp}
          onWakeWordTriggered={() => {
            setReaction('listening');
          }}
        />

        {/* Drawers & Modals */}
        {activeDrawer === 'food' && (
          <FoodDrawer
            characterId={activeCharacterId}
            userLevel={currentCharProgress.level}
            onFeed={handleFeed}
            onClose={() => setActiveDrawer(null)}
          />
        )}

        {activeDrawer === 'wardrobe' && (
          <WardrobeDrawer
            userLevel={currentCharProgress.level}
            currentOutfit={currentCharProgress.currentOutfit}
            onSelectOutfit={handleSelectOutfit}
            onClose={() => setActiveDrawer(null)}
          />
        )}

        {activeDrawer === 'touch' && (
          <TouchGuideModal
            onClose={() => setActiveDrawer(null)}
            onSimulateTouch={(zone, type) => handleZoneInteract(zone, type)}
          />
        )}

        {activeDrawer === 'minigame' && (
          <CatchMiniGame
            characterId={activeCharacterId}
            onFinish={(_score, bonusXp) => {
              addXp(bonusXp);
              const miniGameLine = `Wah jago banget lo! Skornya mantap! Gue jadi makin respect sama lo. (+${bonusXp} XP)`;
              speakCurrentDialogue(miniGameLine, 'happy', 'idle', true);
            }}
            onClose={() => setActiveDrawer(null)}
          />
        )}

        {showVideoCall && (
          <VideoCallModal
            characterId={activeCharacterId}
            level={currentCharProgress.level}
            levelTitle={currentCharConfig.levelTitles[currentCharProgress.level]}
            onClose={() => setShowVideoCall(false)}
            onAddXp={addXp}
          />
        )}
        {levelUpData && (
          <LevelUpModal
            level={levelUpData.level}
            levelTitle={levelUpData.title}
            characterName={currentCharConfig.name}
            onClose={() => setLevelUpData(null)}
          />
        )}

        {showSettings && (
          <SettingsModal
            onClose={() => setShowSettings(false)}
            onResetProgress={handleResetProgress}
            onOpenLevelGuide={() => setShowLevelGuide(true)}
          />
        )}

        {showLevelGuide && (
          <LevelGuideModal
            characterId={activeCharacterId}
            currentLevel={currentCharProgress.level}
            currentXp={currentCharProgress.xp}
            onClose={() => setShowLevelGuide(false)}
          />
        )}
      </RoomBackground>
    </PhoneFrame>
  );
}
