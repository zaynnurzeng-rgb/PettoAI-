/**
 * Web Audio procedural sound synthesizer for game feedback, animal vocalizations, and speech management.
 */

class SoundEngine {
  private ctx: AudioContext | null = null;
  private isMuted: boolean = false;
  private purrOsc: OscillatorNode | null = null;
  private purrGain: GainNode | null = null;
  private activeAnimalOscs: OscillatorNode[] = [];

  private getContext(): AudioContext | null {
    if (this.isMuted) return null;
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  public setMuted(muted: boolean) {
    this.isMuted = muted;
    if (muted) {
      this.stopPurr();
      this.interruptSpeech();
    }
  }

  public getMuted(): boolean {
    return this.isMuted;
  }

  // Interrupt any ongoing speech synthesis and animal sounds immediately
  public interruptSpeech() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
      } catch (_) {}
    }
    // Stop any playing procedural oscillators
    this.activeAnimalOscs.forEach((osc) => {
      try {
        osc.stop();
        osc.disconnect();
      } catch (_) {}
    });
    this.activeAnimalOscs = [];
  }

  // Slap / Bonk sound
  public playBonk() {
    const ctx = this.getContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(320, now);
    osc.frequency.exponentialRampToValueAtTime(80, now + 0.12);

    gain.gain.setValueAtTime(0.5, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.12);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.13);
  }

  // Tickle / Giggle
  public playGiggle() {
    const ctx = this.getContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    for (let i = 0; i < 3; i++) {
      const t = now + i * 0.07;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      const baseFreq = 500 + i * 120;
      osc.frequency.setValueAtTime(baseFreq, t);
      osc.frequency.linearRampToValueAtTime(baseFreq + 180, t + 0.05);

      gain.gain.setValueAtTime(0.2, t);
      gain.gain.exponentialRampToValueAtTime(0.01, t + 0.06);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(t);
      osc.stop(t + 0.07);
    }
  }

  // Purring sound loop
  public startPurr() {
    if (this.purrOsc) return;
    const ctx = this.getContext();
    if (!ctx) return;

    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const mod = ctx.createOscillator();
    const modGain = ctx.createGain();
    const mainGain = ctx.createGain();

    osc.type = 'triangle';
    osc.frequency.setValueAtTime(55, now); // Low feline rumble

    mod.type = 'sine';
    mod.frequency.setValueAtTime(18, now); // 18Hz diaphragm pulsation
    modGain.gain.setValueAtTime(15, now);

    mod.connect(osc.frequency);

    mainGain.gain.setValueAtTime(0.01, now);
    mainGain.gain.linearRampToValueAtTime(0.25, now + 0.2);

    osc.connect(mainGain);
    mainGain.connect(ctx.destination);

    mod.start(now);
    osc.start(now);

    this.purrOsc = osc;
    this.purrGain = mainGain;
  }

  public stopPurr() {
    if (this.purrOsc && this.purrGain && this.ctx) {
      const now = this.ctx.currentTime;
      this.purrGain.gain.linearRampToValueAtTime(0.001, now + 0.15);
      setTimeout(() => {
        try {
          this.purrOsc?.stop();
          this.purrOsc?.disconnect();
        } catch (_) {}
        this.purrOsc = null;
        this.purrGain = null;
      }, 160);
    }
  }

  // --- ANIMAL VOCALIZATION SYNTHESIZERS ---

  // Authentic Feline Cat Vocalization (Mrow / Meow / Chirp)
  public playCatMeow(variant: 'happy' | 'chirp' | 'grumpy' = 'happy') {
    const ctx = this.getContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    const filter = ctx.createBiquadFilter();

    osc.type = 'sawtooth';
    filter.type = 'bandpass';
    filter.Q.setValueAtTime(3.8, now);

    if (variant === 'chirp') {
      // Short friendly chirp ("Mew!")
      osc.frequency.setValueAtTime(650, now);
      osc.frequency.linearRampToValueAtTime(980, now + 0.08);
      osc.frequency.exponentialRampToValueAtTime(580, now + 0.22);

      filter.frequency.setValueAtTime(1400, now);
      filter.frequency.linearRampToValueAtTime(2200, now + 0.08);

      gain.gain.setValueAtTime(0.01, now);
      gain.gain.linearRampToValueAtTime(0.35, now + 0.04);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.22);

      osc.start(now);
      osc.stop(now + 0.23);
    } else if (variant === 'grumpy') {
      // Sassy grumpy orange cat ("Mrr-oooww!")
      osc.frequency.setValueAtTime(340, now);
      osc.frequency.linearRampToValueAtTime(520, now + 0.15);
      osc.frequency.exponentialRampToValueAtTime(290, now + 0.48);

      filter.frequency.setValueAtTime(800, now);
      filter.frequency.linearRampToValueAtTime(1250, now + 0.15);

      gain.gain.setValueAtTime(0.01, now);
      gain.gain.linearRampToValueAtTime(0.38, now + 0.08);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.48);

      osc.start(now);
      osc.stop(now + 0.49);
    } else {
      // Standard expressive vocal meow ("Mee-oooww")
      osc.frequency.setValueAtTime(460, now);
      osc.frequency.linearRampToValueAtTime(820, now + 0.18);
      osc.frequency.exponentialRampToValueAtTime(380, now + 0.45);

      filter.frequency.setValueAtTime(1100, now);
      filter.frequency.linearRampToValueAtTime(1750, now + 0.18);
      filter.frequency.exponentialRampToValueAtTime(950, now + 0.45);

      gain.gain.setValueAtTime(0.01, now);
      gain.gain.linearRampToValueAtTime(0.4, now + 0.08);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.45);

      osc.start(now);
      osc.stop(now + 0.46);
    }

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(ctx.destination);
    this.activeAnimalOscs.push(osc);
  }

  // Authentic Canine Dog Bark & Yip
  public playDogBark(variant: 'double' | 'yip' = 'double') {
    const ctx = this.getContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    const playSingleWoof = (time: number, pitch: number, dur: number) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      const filter = ctx.createBiquadFilter();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(pitch, time);
      osc.frequency.exponentialRampToValueAtTime(pitch * 0.45, time + dur);

      filter.type = 'lowpass';
      filter.frequency.setValueAtTime(950, time);

      gain.gain.setValueAtTime(0.42, time);
      gain.gain.exponentialRampToValueAtTime(0.001, time + dur);

      osc.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);

      osc.start(time);
      osc.stop(time + dur + 0.01);
      this.activeAnimalOscs.push(osc);
    };

    if (variant === 'yip') {
      playSingleWoof(now, 480, 0.14);
    } else {
      // Playful double bark ("Woof woof!")
      playSingleWoof(now, 360, 0.15);
      playSingleWoof(now + 0.18, 420, 0.18);
    }
  }

  // Authentic Owl Hoot (Hollow resonant whistle "Hoo-hoo... hooo~")
  public playOwlHoot(variant: 'dual' | 'long' = 'dual') {
    const ctx = this.getContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    const playHootTone = (time: number, freq: number, dur: number) => {
      const osc = ctx.createOscillator();
      const tremolo = ctx.createOscillator();
      const tremoloGain = ctx.createGain();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, time);
      osc.frequency.linearRampToValueAtTime(freq - 25, time + dur);

      // Soft bird vibrato/flutter
      tremolo.type = 'sine';
      tremolo.frequency.setValueAtTime(5.5, time);
      tremoloGain.gain.setValueAtTime(6, time);
      tremolo.connect(osc.frequency);

      gain.gain.setValueAtTime(0.001, time);
      gain.gain.linearRampToValueAtTime(0.32, time + 0.06);
      gain.gain.exponentialRampToValueAtTime(0.001, time + dur);

      osc.connect(gain);
      gain.connect(ctx.destination);

      tremolo.start(time);
      osc.start(time);
      tremolo.stop(time + dur + 0.01);
      osc.stop(time + dur + 0.01);
      this.activeAnimalOscs.push(osc);
    };

    if (variant === 'long') {
      playHootTone(now, 430, 0.55);
    } else {
      // Dual intellectual owl hoots ("Hoo... hoo-hooo!")
      playHootTone(now, 470, 0.22);
      playHootTone(now + 0.26, 420, 0.42);
    }
  }

  // Aliases for compatibility
  public playMeow() {
    this.playCatMeow('happy');
  }

  public playBark() {
    this.playDogBark('double');
  }

  public playHoot() {
    this.playOwlHoot('dual');
  }

  // Munch / Crunch sound
  public playMunch() {
    const ctx = this.getContext();
    if (!ctx) return;
    const now = ctx.currentTime;

    for (let i = 0; i < 3; i++) {
      const t = now + i * 0.08;
      const bufferSize = ctx.sampleRate * 0.04;
      const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
      const data = buffer.getChannelData(0);
      for (let j = 0; j < bufferSize; j++) {
        data[j] = (Math.random() * 2 - 1) * Math.exp(-j / (bufferSize * 0.3));
      }
      const noise = ctx.createBufferSource();
      noise.buffer = buffer;

      const filter = ctx.createBiquadFilter();
      filter.type = 'bandpass';
      filter.frequency.setValueAtTime(1200 - i * 150, t);
      filter.Q.setValueAtTime(2, t);

      const gain = ctx.createGain();
      gain.gain.setValueAtTime(0.3, t);

      noise.connect(filter);
      filter.connect(gain);
      gain.connect(ctx.destination);
      noise.start(t);
    }
  }

  // Bubble pop
  public playPop() {
    const ctx = this.getContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(700, now);
    osc.frequency.exponentialRampToValueAtTime(1400, now + 0.06);

    gain.gain.setValueAtTime(0.35, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.06);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.07);
  }

  // Level Up fanfare
  public playLevelUp() {
    const ctx = this.getContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const notes = [261.63, 329.63, 392.0, 523.25, 659.25, 783.99];

    notes.forEach((freq, idx) => {
      const t = now + idx * 0.08;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, t);

      gain.gain.setValueAtTime(0.3, t);
      gain.gain.exponentialRampToValueAtTime(0.01, t + 0.25);

      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start(t);
      osc.stop(t + 0.26);
    });
  }

  // Spicy burn sound
  public playSpicy() {
    const ctx = this.getContext();
    if (!ctx) return;
    const now = ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(600, now);
    osc.frequency.linearRampToValueAtTime(1100, now + 0.2);
    osc.frequency.linearRampToValueAtTime(600, now + 0.4);
    osc.frequency.linearRampToValueAtTime(1100, now + 0.6);

    gain.gain.setValueAtTime(0.3, now);
    gain.gain.exponentialRampToValueAtTime(0.01, now + 0.7);

    osc.connect(gain);
    gain.connect(ctx.destination);
    osc.start(now);
    osc.stop(now + 0.71);
  }

  // Play pitch-shifted audio buffer
  public async playPitchShifted(audioBuffer: AudioBuffer, rate: number = 1.45): Promise<void> {
    const ctx = this.getContext();
    if (!ctx) return;

    return new Promise((resolve) => {
      const source = ctx.createBufferSource();
      source.buffer = audioBuffer;
      source.playbackRate.setValueAtTime(rate, ctx.currentTime);

      const filter = ctx.createBiquadFilter();
      filter.type = 'highshelf';
      filter.frequency.setValueAtTime(2500, ctx.currentTime);
      filter.gain.setValueAtTime(6, ctx.currentTime);

      source.connect(filter);
      filter.connect(ctx.destination);

      source.onended = () => {
        resolve();
      };

      source.start(0);
    });
  }
}

export const sound = new SoundEngine();

/**
 * Text-To-Speech with Authentic Animal Sound Models and Interruption Support
 */
export function speakInTomVoice(
  text: string,
  character: 'kucing-oren' | 'burung-hantu' | 'anjing-golden',
  onStart?: () => void,
  onEnd?: () => void,
  soundIntro: boolean = true
) {
  // First interrupt any previously running speech
  sound.interruptSpeech();

  if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
    if (onStart) onStart();
    setTimeout(() => {
      if (onEnd) onEnd();
    }, 1800);
    return;
  }

  // 1. Play signature animal sound before speaking if soundIntro is enabled
  if (soundIntro) {
    if (character === 'kucing-oren') {
      sound.playCatMeow('happy');
    } else if (character === 'anjing-golden') {
      sound.playDogBark('yip');
    } else {
      sound.playOwlHoot('dual');
    }
  }

  // Strip asterisks (action descriptions like *Mendengus*, *Makan lahap*) and emojis for speech synthesis
  let cleanText = text
    .replace(/\*.*?\*/g, '')
    .replace(/[\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}\u{1F700}-\u{1F77F}\u{1F780}-\u{1F7FF}\u{1F800}-\u{1F8FF}\u{1F900}-\u{1F9FF}\u{1FA00}-\u{1FA6F}\u{2600}-\u{26FF}\u{2700}-\u{27BF}]/gu, '')
    .trim();

  if (!cleanText) {
    cleanText = text.replace(/[*_#]/g, '').trim();
  }

  // 2. Add natural in-character animal flavor if not already present
  const lower = cleanText.toLowerCase();
  const startsWithExclamation =
    lower.startsWith('aduh') ||
    lower.startsWith('heh') ||
    lower.startsWith('woy') ||
    lower.startsWith('eits') ||
    lower.startsWith('hah') ||
    lower.startsWith('whoa') ||
    lower.startsWith('purr') ||
    lower.startsWith('nyam');

  if (character === 'kucing-oren') {
    if (!startsWithExclamation && !lower.startsWith('meong')) {
      cleanText = `Meong! ${cleanText}`;
    }
  } else if (character === 'anjing-golden') {
    if (!startsWithExclamation && !lower.startsWith('guk') && !lower.startsWith('woof')) {
      cleanText = `Guk guk! ${cleanText}`;
    }
  } else {
    if (!startsWithExclamation && !lower.startsWith('hoo')) {
      cleanText = `Hoo-hoo... ${cleanText}`;
    }
  }

  const utterance = new SpeechSynthesisUtterance(cleanText);
  utterance.lang = 'id-ID';

  // Distinctive Animal Acoustic Modeling
  if (character === 'kucing-oren') {
    // Kucing Oren (ZAYN): Squeaky, nimble feline pitch with energetic cadence
    utterance.pitch = 1.85;
    utterance.rate = 1.26;
  } else if (character === 'anjing-golden') {
    // Anjing Golden (HERU): Resonant bouncy canine pitch with panting excitement
    utterance.pitch = 1.45;
    utterance.rate = 1.28;
  } else {
    // Burung Hantu Bijak (RIZKY): Deep hollow resonant owl cadence, calm and intellectual
    utterance.pitch = 0.84;
    utterance.rate = 0.90;
  }

  const voices = window.speechSynthesis.getVoices();
  const idVoice = voices.find((v) => v.lang.startsWith('id') || v.lang.includes('ID') || v.lang.includes('id_ID'));
  if (idVoice) {
    utterance.voice = idVoice;
  }

  let hasEnded = false;
  const finish = () => {
    if (hasEnded) return;
    hasEnded = true;
    if (onEnd) onEnd();
  };

  utterance.onstart = () => {
    if (onStart) onStart();
  };
  utterance.onend = finish;
  utterance.onerror = finish;

  // Safety fallback timeout in case browser synthesis stalls
  const estimatedDuration = Math.max(1600, cleanText.length * 85);
  const safetyTimeout = setTimeout(() => {
    finish();
  }, estimatedDuration + 2000);

  // Small delay to ensure clean dispatch after cancel in Chromium
  setTimeout(() => {
    try {
      if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
        window.speechSynthesis.resume();
        const currentVoices = window.speechSynthesis.getVoices();
        const bestVoice = currentVoices.find((v) => v.lang.startsWith('id') || v.lang.includes('ID') || v.lang.includes('id_ID'));
        if (bestVoice) {
          utterance.voice = bestVoice;
        }
        window.speechSynthesis.speak(utterance);
      }
    } catch (err) {
      console.warn('Speech synthesis dispatch error:', err);
      clearTimeout(safetyTimeout);
      finish();
    }
  }, 25);
}
