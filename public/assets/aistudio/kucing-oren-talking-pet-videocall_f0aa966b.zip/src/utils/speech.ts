/**
 * Web Speech Recognition helper for Speak-to-Text and Wake Word ("Hey Petto") detection.
 */

// Declare SpeechRecognition interface for TypeScript
interface IWindow extends Window {
  SpeechRecognition?: any;
  webkitSpeechRecognition?: any;
}

export class SpeechManager {
  private recognition: any = null;
  private wakeWordRecognition: any = null;
  private isListeningWakeWord: boolean = false;
  private isRestartingWakeWord: boolean = false;
  private onWakeWordDetected: (() => void) | null = null;
  private onWakeWordHeard: ((text: string) => void) | null = null;
  private onWakeWordStatusChange: ((active: boolean, err?: string) => void) | null = null;

  private onTranscript: ((text: string, isFinal: boolean) => void) | null = null;
  private onError: ((error: string) => void) | null = null;
  private onEnd: (() => void) | null = null;

  public isSupported(): boolean {
    if (typeof window === 'undefined') return false;
    const win = window as any;
    return Boolean(win.SpeechRecognition || win.webkitSpeechRecognition);
  }

  private createRecognizer() {
    if (typeof window === 'undefined') return null;
    const win = window as any;
    const RecognizerClass = win.SpeechRecognition || win.webkitSpeechRecognition;
    if (!RecognizerClass) return null;
    const recognizer = new RecognizerClass();
    recognizer.lang = 'id-ID'; // Indonesian
    recognizer.interimResults = true;
    recognizer.continuous = false;
    return recognizer;
  }

  // Active Speech-To-Text conversation session with interruption support
  public startSpeechToText(
    onTranscript: (text: string, isFinal: boolean) => void,
    onEnd: () => void,
    onError: (err: string) => void,
    onBargeIn?: () => void
  ) {
    if (!this.isSupported()) {
      onError('Browser tidak mendukung Speech Recognition.');
      return;
    }

    // Stop wake word listening temporarily while active recording
    this.stopWakeWordListener();

    this.onTranscript = onTranscript;
    this.onEnd = onEnd;
    this.onError = onError;

    try {
      this.recognition = this.createRecognizer();
      if (!this.recognition) return;

      this.recognition.onstart = () => {
        // Recognition started
      };

      this.recognition.onspeechstart = () => {
        // As soon as user speaks a sound, trigger barge-in to stop character speech
        if (onBargeIn) {
          onBargeIn();
        }
      };

      this.recognition.onresult = (event: any) => {
        // User produced words -> trigger barge-in
        if (onBargeIn) {
          onBargeIn();
        }

        let interimTranscript = '';
        let finalTranscript = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            finalTranscript += event.results[i][0].transcript;
          } else {
            interimTranscript += event.results[i][0].transcript;
          }
        }

        const text = finalTranscript || interimTranscript;
        const isFinal = Boolean(finalTranscript);
        if (this.onTranscript && text.trim()) {
          this.onTranscript(text.trim(), isFinal);
        }
      };

      this.recognition.onerror = (event: any) => {
        if (event.error !== 'no-speech' && this.onError) {
          this.onError(event.error);
        }
      };

      this.recognition.onend = () => {
        if (this.onEnd) {
          this.onEnd();
        }
        // Resume wake word listening if it was enabled
        if (this.isListeningWakeWord && this.onWakeWordDetected) {
          this.startWakeWordListener(
            this.onWakeWordDetected,
            this.onWakeWordHeard || undefined,
            this.onWakeWordStatusChange || undefined
          );
        }
      };

      this.recognition.start();
    } catch (err: any) {
      if (this.onError) this.onError(err?.message || 'Gagal memulai mikrofon');
    }
  }

  public stopSpeechToText() {
    if (this.recognition) {
      try {
        this.recognition.stop();
      } catch (_) {}
      this.recognition = null;
    }
  }

  // Check if speech matches any wake word variations
  public isWakeWordMatch(rawText: string): boolean {
    const t = rawText.toLowerCase().replace(/[^a-z0-9\s]/g, ' ');
    // Direct matches
    if (
      t.includes('hey petto') ||
      t.includes('hei petto') ||
      t.includes('hai petto') ||
      t.includes('halo petto') ||
      t.includes('he petto') ||
      t.includes('hey peto') ||
      t.includes('hei peto') ||
      t.includes('hai peto') ||
      t.includes('halo peto') ||
      t.includes('he peto') ||
      t.includes('petto') ||
      t.includes('peto') ||
      t.includes('petot') ||
      t.includes('hey pet') ||
      t.includes('hai pet') ||
      t.includes('hei pet') ||
      t.includes('halo pet') ||
      t.includes('kucing oren') ||
      t.includes('meong')
    ) {
      return true;
    }

    // Regex combinations
    if (/(hey|hei|hai|halo|he|eh|oi|oy)\s*(petto|peto|pet|beto|pedro|pato|pesto|kucing)/i.test(t)) {
      return true;
    }

    return false;
  }

  // Continuous Wake Word ("Hey Petto") listener
  public startWakeWordListener(
    onDetected: () => void,
    onHeard?: (text: string) => void,
    onStatusChange?: (active: boolean, err?: string) => void
  ) {
    if (!this.isSupported()) {
      if (onStatusChange) onStatusChange(false, 'Speech Recognition tidak didukung di browser ini.');
      return;
    }

    this.isListeningWakeWord = true;
    this.onWakeWordDetected = onDetected;
    this.onWakeWordHeard = onHeard || null;
    this.onWakeWordStatusChange = onStatusChange || null;

    try {
      if (this.wakeWordRecognition) {
        try {
          this.wakeWordRecognition.abort();
        } catch (_) {}
        this.wakeWordRecognition = null;
      }

      this.wakeWordRecognition = this.createRecognizer();
      if (!this.wakeWordRecognition) return;

      this.wakeWordRecognition.continuous = true;
      this.wakeWordRecognition.interimResults = true;

      this.wakeWordRecognition.onstart = () => {
        if (this.onWakeWordStatusChange) {
          this.onWakeWordStatusChange(true);
        }
      };

      this.wakeWordRecognition.onresult = (event: any) => {
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          const text = event.results[i][0].transcript;
          if (this.onWakeWordHeard) {
            this.onWakeWordHeard(text);
          }

          if (this.isWakeWordMatch(text)) {
            this.stopWakeWordListener();
            if (this.onWakeWordDetected) {
              this.onWakeWordDetected();
            }
            return;
          }
        }
      };

      this.wakeWordRecognition.onerror = (e: any) => {
        if (e.error === 'not-allowed') {
          this.isListeningWakeWord = false;
          if (this.onWakeWordStatusChange) {
            this.onWakeWordStatusChange(false, 'Izin mikrofon belum diberikan oleh browser.');
          }
          return;
        }

        // Restart listener gracefully after noise/silence errors
        if (this.isListeningWakeWord && !this.isRestartingWakeWord) {
          this.isRestartingWakeWord = true;
          setTimeout(() => {
            this.isRestartingWakeWord = false;
            if (this.isListeningWakeWord) {
              try {
                this.wakeWordRecognition?.start();
              } catch (_) {}
            }
          }, 800);
        }
      };

      this.wakeWordRecognition.onend = () => {
        // Continuous restart loop when browser naturally ends speech session
        if (this.isListeningWakeWord && !this.isRestartingWakeWord) {
          this.isRestartingWakeWord = true;
          setTimeout(() => {
            this.isRestartingWakeWord = false;
            if (this.isListeningWakeWord) {
              try {
                this.wakeWordRecognition?.start();
              } catch (_) {}
            }
          }, 400);
        }
      };

      this.wakeWordRecognition.start();
    } catch (err: any) {
      if (this.onWakeWordStatusChange) {
        this.onWakeWordStatusChange(false, err?.message);
      }
    }
  }

  public stopWakeWordListener() {
    this.isListeningWakeWord = false;
    if (this.wakeWordRecognition) {
      try {
        this.wakeWordRecognition.abort();
      } catch (_) {}
      this.wakeWordRecognition = null;
    }
    if (this.onWakeWordStatusChange) {
      this.onWakeWordStatusChange(false);
    }
  }

  public getIsWakeWordActive(): boolean {
    return this.isListeningWakeWord;
  }
}

export const speech = new SpeechManager();
