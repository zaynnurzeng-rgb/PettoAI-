import { CharacterConfig, FoodItem, OutfitItem } from '../types/game';

export const CHARACTERS: Record<string, CharacterConfig> = {
  'kucing-oren': {
    id: 'kucing-oren',
    name: 'ZAYN',
    subtitle: 'Kucing Jutek & Tsundere',
    avatarBg: '#F59E0B',
    baseColor: '#EA580C',
    accentColor: '#FDE047',
    favFoodId: 'tuna-kaleng',
    hatedFoodId: 'cabe-rawit',
    levelTitles: {
      1: 'Orang Asing Mencurigakan',
      2: 'Kenalan Sok Akrab',
      3: 'Teman Nongkrong Nyantai',
      4: 'Bestie Bar-bar',
      5: 'Babu Emas Tersayang 👑',
    },
    dialogues: {
      1: [
        '*Mendengus* Serious apaan? Kalau mau ngajak gue, ZAYN si kucing oren main, mending bawa tuna kaleng biar gue nggak makin emosi.',
        'Ngapain liat-liat ZAYN? Mau minta tanda tangan cakar gue?!',
        'Tangan lo bau sabun, jangan sembarangan pegang bulu premium gue ya!',
        'Gue lagi mager stadium akhir. Jangan ganggu dulu dehh.',
      ],
      2: [
        'Hmm... lo lumayan sering ke sini ya. Ada bawa tuna kaleng lagi nggak?',
        'Jangan geer dulu, gue noleh cuma karena denger kresek makanan.',
        'Kalo mau elus pelan-pelan, jangan bikin gaya rambut gue berantakan!',
        'Yaudah deh, lo boleh berdiri deket gue maksimal 5 menit.',
      ],
      3: [
        'Duh, elusan lo pas banget di bawah dagu... lumayan jago juga lo jadi manusia.',
        'Kalo gue lagi tidur di kasur lo, inget: kasur itu sekarang resmi milik gue.',
        'Gue nggak bakal ngaku kalo lo temen gue, tapi gue seneng sih lo dateng.',
        'Mandiin gue? Jangan harap! Tapi kalau cemilan ikan gue siap santap!',
      ],
      4: [
        'Woy bestie! Akhirnya dateng juga! Mana jatah tuna kaleng harian gue?',
        'Gue udah simpenin posisi paling empuk di sebelah gue khusus buat lo!',
        'Lo tau nggak? Dari semua manusia yang pernah gue cakar, lo yang paling oke.',
        'Ayo ngobrol lagi, tiruin suara aneh gue tadi buruan!',
      ],
      5: [
        'Purrrr... *menempelkan kepala ke tanganmu* Jangan ke mana-mana ya babu tersayang gue.',
        'Gue sayang banget sama lo... tapi ssst, jangan bilang-bilang ke kucing sebelah!',
        'Semua tuna di dunia ini nggak ada apa-apanya dibanding waktu gue main bareng lo!',
        'Lo adalah manusia terfavorit di seluruh jagat galaksi meong! 💖',
      ],
    },
    touchReactions: {
      head: {
        tap: [
          'Aduh! Kepala gue bukan tombol dispenser tau! Pusing nih!',
          'Heh! Siapa yang ajarin getok kepala raja kucing?!',
          'Aww! Bintang-bintang muter di kepala gue! 💫',
        ],
        pet: [
          'Purrr... nah di situ... jangan berhenti dulu ya...',
          'Hhhmm enak banget elusannya, mata gue ampe merem melek...',
          'Gini nih servis bintang lima yang gue suka! 💆‍♂️',
        ],
      },
      belly: {
        tap: [
          'Heh geli woy! Hahaha jangan sok colek-colek perut bucit gue!',
          'Perut gue sensitif! Geli banget astaga wkwk!',
          'Awas ya, cakar gue keluar kalo terus dicolek!',
        ],
        pet: [
          'Hmm... perut suci gue cuma boleh dielus sama orang terpercaya. Enak sih...',
          'Geli-geli nikmat... awas jangan keterusan!',
        ],
      },
      ears: [
        'Aduh kuping gue jangan ditarik! Radar sinyal makanan gue rusak nih!',
        'Sakit tau! Kuping gue sensitif buat denger kaleng tuna dibuka!',
      ],
      tail: [
        'Eits! Ekor kebanggaan gue jangan ditarik sembarangan!',
        'Whoaaa! Keseimbangan ekor gue terganggu! Mau bikin gue salto apa gimana?!',
      ],
      feet: [
        'Aduh! Kaki gue jangan diinjek/dicubit! Gue kan mau jalan anggun!',
        'Kaki lentik gue mahal perawatannya!',
      ],
    },
  },

  'burung-hantu': {
    id: 'burung-hantu',
    name: 'RIZKY',
    subtitle: 'Burung Hantu Tenang & Bijak',
    avatarBg: '#8B5CF6',
    baseColor: '#7C3AED',
    accentColor: '#DDD6FE',
    favFoodId: 'kopi-hitam',
    hatedFoodId: 'cabe-rawit',
    levelTitles: {
      1: 'Murid Baru yang Bising',
      2: 'Pendengar yang Penasaran',
      3: 'Rekan Diskusi Filosofis',
      4: 'Sahabat Pencerahan',
      5: 'Penjaga Kebijaksanaan Abadi 🦉',
    },
    dialogues: {
      1: [
        '*Hoo-hoo* Namaku RIZKY. Mengapa kamu mengusik renungan malamku, wahai fana?',
        'Tidur siang adalah seni, dan kamu baru saja merusak mahakarya RIZKY ini.',
        'Membaca 50 bab buku jauh lebih tenang dibanding mendengar ocehanmu.',
      ],
      2: [
        'Hmm, ada secercah keingintahuan di matamu. Bawa secangkir kopi hitam kalau ingin berdiskusi dengan RIZKY.',
        'Ketahuilah, kacamata ini bukan sekadar gaya, melainkan lensa penembus realita.',
      ],
      3: [
        'Sentuhanmu cukup menenangkan saraf otakku. Zayn si kucing oren itu terlalu gaduh, kamu lebih tertib.',
        'Hari ini buku apa yang sudah kamu baca? Kebodohan itu mahal harganya!',
      ],
      4: [
        'Wahai sahabat, malam ini bintang-bintang bersinar indah seperti jalinan perkawanan kita.',
        'Terima kasih telah menemani sesi begadhangku. Kamu adalah teman yang bijaksana bagi RIZKY.',
      ],
      5: [
        'Dalam seluruh catatan sejarah perpustakaan purba, belum pernah kutemui sahabat sebaik dirimu! 🦉✨',
        'Kebijaksanaan tertinggi adalah kasih sayang tulus tanpa pamrih, seperti persahabatan kita.',
      ],
    },
    touchReactions: {
      head: {
        tap: [
          'Hoo! Kepalaku ini penuh rumus fisika dan filsafat, jangan diketuk!',
          'Kacamataku hampir miring! Hati-hati!',
        ],
        pet: [
          'Hooo... bulu mahkotaku terasa hangat... sungguh menenangkan.',
          'Elusan yang presisi dan menyejukkan saraf kepala.',
        ],
      },
      belly: {
        tap: [
          'Hoo-hoo-hoo! Jangan menggelitik sayap dan perutku!',
          'Hentikan, tawa ini merusak wibawa intelektualku!',
        ],
        pet: [
          'Bulu halus perutku terlindungi oleh hikmah berabad-abad...',
        ],
      },
      ears: [
        'Kuping pendengaran sonarku berdenging! Pelan-pelan!',
      ],
      tail: [
        'Bulu ekor kemudiku jangan ditarik! Nanti aku terbang oleng!',
      ],
      feet: [
        'Cakar dahan ini kuat, jangan ditarik!',
      ],
    },
  },

  'anjing-golden': {
    id: 'anjing-golden',
    name: 'HERU',
    subtitle: 'Anjing Paling Ceria & Ramah',
    avatarBg: '#EAB308',
    baseColor: '#CA8A04',
    accentColor: '#FEF08A',
    favFoodId: 'tulang-lezat',
    hatedFoodId: 'cabe-rawit',
    levelTitles: {
      1: 'Teman Main Baru!',
      2: 'Kawan Lempar Bola',
      3: 'Teman Peluk Terbaik',
      4: 'Bestie Sehidup Semati',
      5: 'Sahabat Paling Setia di Dunia 🐶',
    },
    dialogues: {
      1: [
        'Guk guk!! Halo halo! Aku HERU! Kamu mau main sama aku kan?! Ayo main bola tenis!',
        'HERU senang banget ada orang baru! Ekor aku goyang terus nih liat kamu!',
        'Ada biskuit anjing nggak di saku kamu? Baunya kayak tulang panggang!',
      ],
      2: [
        'Yayyy kamu balik lagi! Ayo kejar-kejaran keliling kamar bareng HERU!',
        'Zayn jutek banget ya? Tapi HERU sayang semua orang termasuk kamu!',
      ],
      3: [
        'Guk! Elus perut HERU dong, ayo elus! Aku bakal guling-guling bahagia!',
        'Kamu tau nggak? Kamu itu manusia paling asik sedunia!',
      ],
      4: [
        'Woof woof! HERU kangen banget sama kamu! Peluk aku donggg!',
        'Apapun yang kamu lempar, bakal aku bawain balik dengan penuh cinta!',
      ],
      5: [
        '*Slurp slurp* Jilatan cinta seumur hidup buat kamu sahabat terbaikku! Guk guk guk! 💖',
        'HERU bakal selalu jaga kamu dan bikin kamu tersenyum setiap hari!',
      ],
    },
    touchReactions: {
      head: {
        tap: [
          'Aduh hidung dan dahiku kesentuh! Guk! Kaget dikit!',
          'Main tebak-tebakan ya? Ayo lagi!',
        ],
        pet: [
          'Woof! Di balik kuping dong! Enak bangeeett!!',
          'Ekor aku goyang 100 putaran per detik saking bahagianya!',
        ],
      },
      belly: {
        tap: [
          'Hahaha geli guk guk! Kaki aku ikut nendang-nendang saking gelinya!',
          'Geli banget perutku wkwkwk!',
        ],
        pet: [
          'Yaaasss belly rubs! Surganya para golden retriever!',
          'Jangan stop please! Aku mau dielus 24 jam non-stop!',
        ],
      },
      ears: [
        'Kuping flapppy aku empuk kan? Jangan dijewer tapi ya!',
      ],
      tail: [
        'Ekor aku yang muter-muter jangan ditahan dong! Itu mesin kebahagiaanku!',
      ],
      feet: [
        'Guk! Kaki aku siap lari sprint keliling ruangan!',
      ],
    },
  },
};

export const FOOD_ITEMS: FoodItem[] = [
  {
    id: 'tuna-kaleng',
    name: 'Tuna Kaleng Segar',
    emoji: '🐟',
    category: 'fish',
    xpGain: 35,
    description: 'Makanan legendaris favorit ZAYN. Dijamin langsung luluh!',
    reactionType: 'tasty',
    minLevel: 1,
  },
  {
    id: 'ikan-mas',
    name: 'Ikan Mas Goreng',
    emoji: '🐠',
    category: 'fish',
    xpGain: 25,
    description: 'Renyah di luar, empuk di dalam.',
    reactionType: 'tasty',
    minLevel: 1,
  },
  {
    id: 'susu-hangat',
    name: 'Susu Hangat Murni',
    emoji: '🥛',
    category: 'drink',
    xpGain: 20,
    description: 'Bikin ngantuk dan purring berkepanjangan.',
    reactionType: 'tasty',
    minLevel: 1,
  },
  {
    id: 'tulang-lezat',
    name: 'Tulang Sumsum Lezat',
    emoji: '🍖',
    category: 'meat',
    xpGain: 35,
    description: 'Favorit mutlak HERU si anjing! Kriuk kriuk gurih.',
    reactionType: 'tasty',
    minLevel: 2,
  },
  {
    id: 'kopi-hitam',
    name: 'Kopi Hitam Espresso',
    emoji: '☕',
    category: 'drink',
    xpGain: 35,
    description: 'Bahan bakar filsafat bagi RIZKY sang burung hantu bijak.',
    reactionType: 'tasty',
    minLevel: 2,
  },
  {
    id: 'cabe-rawit',
    name: 'Cabe Rawit Setan 🌶️',
    emoji: '🌶️',
    category: 'special',
    xpGain: 10,
    description: 'MAKANAN JAHIL! Pedasnya bikin keluar api dari telinga!',
    reactionType: 'spicy',
    minLevel: 1,
  },
];

export const OUTFIT_ITEMS: OutfitItem[] = [
  // Hats
  { id: 'none_hat', name: 'Tanpa Topi', category: 'hat', icon: '❌', minLevel: 1 },
  { id: 'cowboy_hat', name: 'Topi Koboi Oren', category: 'hat', icon: '🤠', minLevel: 1 },
  { id: 'party_hat', name: 'Topi Pesta Meriah', category: 'hat', icon: '🎉', minLevel: 2 },
  { id: 'chef_hat', name: 'Topi Koki Bintang 5', category: 'hat', icon: '👨‍🍳', minLevel: 3 },
  { id: 'crown_sultan', name: 'Mahkota Emas Sultan', category: 'hat', icon: '👑', minLevel: 4 },

  // Glasses
  { id: 'none_glasses', name: 'Tanpa Kacamata', category: 'glasses', icon: '❌', minLevel: 1 },
  { id: 'thug_life', name: 'Kacamata Thug Life', category: 'glasses', icon: '🕶️', minLevel: 1 },
  { id: 'professor_specs', name: 'Kacamata Bulat Profesor', category: 'glasses', icon: '👓', minLevel: 2 },
  { id: 'cool_shades', name: 'Kacamata Pantai Neon', category: 'glasses', icon: '😎', minLevel: 3 },

  // Neck
  { id: 'none_neck', name: 'Tanpa Aksesoris', category: 'neck', icon: '❌', minLevel: 1 },
  { id: 'red_bowtie', name: 'Dasi Kupu-Kupu Merah', category: 'neck', icon: '🎀', minLevel: 1 },
  { id: 'gold_chain', name: 'Kalung Rantai Emas Rapper', category: 'neck', icon: '⛓️', minLevel: 3 },
  { id: 'warm_scarf', name: 'Syal Rajut Hangat', category: 'neck', icon: '🧣', minLevel: 4 },
];
