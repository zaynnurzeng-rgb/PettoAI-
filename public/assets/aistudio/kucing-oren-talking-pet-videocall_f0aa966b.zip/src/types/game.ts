export type CharacterId = 'kucing-oren' | 'burung-hantu' | 'anjing-golden';

export type TouchZone = 'head' | 'belly' | 'left-ear' | 'right-ear' | 'tail' | 'feet' | 'chin';

export type PetReaction = 'idle' | 'happy' | 'angry' | 'dizzy' | 'tickled' | 'eating' | 'talking' | 'listening' | 'surprised' | 'sleeping' | 'spicy';

export interface CharacterDialogue {
  level: number;
  lines: string[];
}

export interface FoodItem {
  id: string;
  name: string;
  emoji: string;
  category: 'fish' | 'meat' | 'drink' | 'special';
  xpGain: number;
  description: string;
  reactionType: 'tasty' | 'normal' | 'disliked' | 'spicy';
  isLocked?: boolean;
  minLevel?: number;
}

export interface OutfitItem {
  id: string;
  name: string;
  category: 'hat' | 'glasses' | 'neck';
  icon: string;
  minLevel: number;
  previewColor?: string;
}

export interface CharacterConfig {
  id: CharacterId;
  name: string;
  subtitle: string;
  avatarBg: string;
  baseColor: string;
  accentColor: string;
  favFoodId: string;
  hatedFoodId?: string;
  levelTitles: Record<number, string>;
  dialogues: Record<number, string[]>;
  touchReactions: {
    head: { tap: string[]; pet: string[] };
    belly: { tap: string[]; pet: string[] };
    ears: string[];
    tail: string[];
    feet: string[];
  };
}

export interface CharacterProgress {
  level: number;
  xp: number;
  currentOutfit: {
    hat?: string;
    glasses?: string;
    neck?: string;
  };
  unlockedOutfits: string[];
}

export interface ChatMessage {
  role: 'user' | 'pet';
  text: string;
  ts: number;
}
