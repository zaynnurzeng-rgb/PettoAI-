package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CharacterCatalog
import com.example.model.PetCharacter
import com.example.model.PetSpecies
import com.example.ui.AvatarUiState
import com.example.ui.FaceToFaceCallState

@Composable
fun FaceToFaceCallView(
    uiState: AvatarUiState,
    onEndCall: () -> Unit,
    onToggleMute: () -> Unit,
    onInterruptOrSpeak: () -> Unit,
    onQuickPrompt: (String) -> Unit,
    onSwitchCharacter: (PetCharacter) -> Unit,
    onPetAvatar: () -> Unit,
    modifier: Modifier = Modifier
) {
    val char = uiState.activeCharacter
    val callState = uiState.faceToFaceCallState

    var showCharacterPickerModal by remember { mutableStateOf(false) }

    // Pulse animation for audio/thinking wave
    val infiniteTransition = rememberInfiniteTransition(label = "call_audio_wave")
    val waveScale1 by infiniteTransition.animateFloat(
        initialValue = 0.95f,
        targetValue = 1.25f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "waveScale1"
    )
    val waveAlpha1 by infiniteTransition.animateFloat(
        initialValue = 0.6f,
        targetValue = 0.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "waveAlpha1"
    )

    val blinkAlpha by infiniteTransition.animateFloat(
        initialValue = 0.2f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(800, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "blinkAlpha"
    )

    // Call duration formatted mm:ss
    val minutes = uiState.callDurationSeconds / 60
    val seconds = uiState.callDurationSeconds % 60
    val durationText = "%02d:%02d".format(minutes, seconds)

    val personalityBadge = when (char.id) {
        "zayn" -> "😼 Tsundere & Ketus"
        "siti" -> "🐰 Penyayang & Lembut"
        "rizky" -> "🐶 Tegas & Disiplin"
        "jamal" -> "🦫 Pemalas & Nakal"
        else -> "🐻 Pemarah & Sangar"
    }

    val quickQuestions = listOf(
        "5 x 9 apa?",
        "Lagi ngapain kamu?",
        "Ceritakan lelucon dong!",
        "Kamu suka aku gak?",
        "Bagi rahasia kamu!"
    )

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF0F0E1E),
                        Color(0xFF1B1838),
                        Color(0xFF0D1127)
                    )
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
        ) {
            // Top Call Header
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                // Character Pill & Switcher
                Surface(
                    shape = RoundedCornerShape(24.dp),
                    color = Color.White.copy(alpha = 0.12f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.2f)),
                    modifier = Modifier
                        .clickable { showCharacterPickerModal = true }
                        .testTag("call_switch_character_button")
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = char.species.emoji,
                            fontSize = 20.sp
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Column {
                            Text(
                                text = char.name,
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White
                                )
                            )
                            Text(
                                text = personalityBadge,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = Color(0xFFB0B7D6),
                                    fontSize = 10.sp
                                )
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Icon(
                            imageVector = Icons.Default.SwapHoriz,
                            contentDescription = "Ganti Karakter",
                            tint = Color.White.copy(alpha = 0.7f),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                // Call Duration & Live Status
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color.Black.copy(alpha = 0.35f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.15f))
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(
                                    when (callState) {
                                        FaceToFaceCallState.LISTENING -> Color(0xFF4CAF50).copy(alpha = blinkAlpha)
                                        FaceToFaceCallState.THINKING -> Color(0xFFAB47BC).copy(alpha = blinkAlpha)
                                        FaceToFaceCallState.SPEAKING -> Color(0xFF29B6F6)
                                        FaceToFaceCallState.MUTED -> Color(0xFFFFB300)
                                        else -> Color.Gray
                                    }
                                )
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = durationText,
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.SemiBold,
                                color = Color.White,
                                letterSpacing = 0.5.sp
                            )
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "✨ Gemini AI",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = Color(0xFFE1BEE7),
                                fontSize = 10.sp
                            )
                        )
                    }
                }
            }

            // Center Stage: Giant Interactive Avatar with Audio Reactive Waves
            Box(
                contentAlignment = Alignment.Center,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp)
            ) {
                // Background Audio Rings
                Canvas(
                    modifier = Modifier
                        .size(320.dp)
                        .scale(
                            when (callState) {
                                FaceToFaceCallState.LISTENING -> 1f + (uiState.speechRms.coerceIn(0f, 10f) * 0.03f)
                                FaceToFaceCallState.SPEAKING -> waveScale1
                                FaceToFaceCallState.THINKING -> waveScale1
                                else -> 1f
                            }
                        )
                ) {
                    val radius = size.minDimension / 2f
                    val ringColor = when (callState) {
                        FaceToFaceCallState.LISTENING -> Color(0xFF4CAF50).copy(alpha = waveAlpha1)
                        FaceToFaceCallState.THINKING -> Color(0xFFAB47BC).copy(alpha = waveAlpha1)
                        FaceToFaceCallState.SPEAKING -> Color(0xFF00E5FF).copy(alpha = waveAlpha1 * 0.8f)
                        FaceToFaceCallState.MUTED -> Color(0xFFFFB300).copy(alpha = 0.15f)
                        else -> Color.White.copy(alpha = 0.1f)
                    }

                    drawCircle(
                        color = ringColor,
                        radius = radius * 0.95f,
                        center = center
                    )
                    drawCircle(
                        color = ringColor.copy(alpha = ringColor.alpha * 0.5f),
                        radius = radius * 1.08f,
                        center = center
                    )
                }

                // Giant Animated 3D Avatar
                Avatar3DCanvas(
                    species = char.species,
                    customization = uiState.customization,
                    emotion = uiState.currentEmotion,
                    isTalking = uiState.isTalking,
                    onZoneTouched = { onPetAvatar() },
                    modifier = Modifier
                        .fillMaxSize(0.92f)
                        .testTag("facetoface_avatar_canvas")
                )

                // Status Indicator Pill (overlayed on top of avatar)
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = Color.Black.copy(alpha = 0.65f),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        when (callState) {
                            FaceToFaceCallState.LISTENING -> Color(0xFF4CAF50)
                            FaceToFaceCallState.THINKING -> Color(0xFFAB47BC)
                            FaceToFaceCallState.SPEAKING -> Color(0xFF29B6F6)
                            FaceToFaceCallState.MUTED -> Color(0xFFFFB300)
                            else -> Color.White.copy(alpha = 0.3f)
                        }
                    ),
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        val statusEmoji = when (callState) {
                            FaceToFaceCallState.LISTENING -> "🟢"
                            FaceToFaceCallState.THINKING -> "🧠"
                            FaceToFaceCallState.SPEAKING -> "🗣️"
                            FaceToFaceCallState.MUTED -> "🔇"
                            else -> "⚡"
                        }
                        val statusText = when (callState) {
                            FaceToFaceCallState.LISTENING -> "Mendengarkan kamu..."
                            FaceToFaceCallState.THINKING -> "${char.name} sedang berpikir..."
                            FaceToFaceCallState.SPEAKING -> "${char.name} sedang berbicara..."
                            FaceToFaceCallState.MUTED -> "Mikrofon Dimatikan"
                            else -> "Menghubungkan..."
                        }

                        Text(text = statusEmoji, fontSize = 12.sp)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = statusText,
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Medium,
                                color = Color.White
                            )
                        )
                    }
                }
            }

            // Real-time Live Subtitles Card (Floating speech display - not an input text)
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color(0xFF13152C).copy(alpha = 0.88f),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.15f)),
                shadowElevation = 8.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 6.dp)
            ) {
                Column(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp)
                ) {
                    // User's speech subtitle
                    if (uiState.liveUserSpeech.isNotBlank()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "👤 Kamu: ",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF80D8FF)
                                )
                            )
                            Text(
                                text = "\"${uiState.liveUserSpeech}\"",
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = Color.White.copy(alpha = 0.9f)
                                ),
                                maxLines = 2
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                    }

                    // Avatar spoken line subtitle
                    Row(verticalAlignment = Alignment.Top) {
                        Text(
                            text = "🐾 ${char.name}: ",
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFFFD54F)
                            )
                        )
                        Text(
                            text = if (callState == FaceToFaceCallState.THINKING) {
                                "Sedang merangkai kata-kata..."
                            } else {
                                uiState.liveAvatarSpeech.ifBlank { "Halo! Aku siap mendengarkanmu langsung." }
                            },
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = Color.White,
                                fontWeight = FontWeight.Normal,
                                lineHeight = 20.sp
                            ),
                            maxLines = 3
                        )
                    }
                }
            }

            // Quick Prompt Suggestions (Hands-free test pills)
            LazyRow(
                contentPadding = PaddingValues(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            ) {
                items(quickQuestions) { q ->
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = Color.White.copy(alpha = 0.1f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.18f)),
                        modifier = Modifier
                            .clickable { onQuickPrompt(q) }
                            .testTag("call_quick_prompt_${q.hashCode()}")
                    ) {
                        Text(
                            text = q,
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = Color(0xFFE0E0FF),
                                fontWeight = FontWeight.Medium
                            ),
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Bottom Call Action Controls Bar
            Row(
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 12.dp)
            ) {
                // Mute / Unmute Button
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Surface(
                        shape = CircleShape,
                        color = if (uiState.isFaceToFaceMuted) Color(0xFFFFB300) else Color.White.copy(alpha = 0.18f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.25f)),
                        modifier = Modifier
                            .size(56.dp)
                            .clickable { onToggleMute() }
                            .testTag("call_mute_toggle_button")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = if (uiState.isFaceToFaceMuted) Icons.Default.MicOff else Icons.Default.Mic,
                                contentDescription = if (uiState.isFaceToFaceMuted) "Nyalakan Mic" else "Matikan Mic",
                                tint = if (uiState.isFaceToFaceMuted) Color.Black else Color.White,
                                modifier = Modifier.size(26.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (uiState.isFaceToFaceMuted) "Unmute" else "Mute",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Color.White.copy(alpha = 0.75f),
                            fontSize = 11.sp
                        )
                    )
                }

                // Red End Call Button
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Surface(
                        shape = CircleShape,
                        color = Color(0xFFE53935),
                        shadowElevation = 8.dp,
                        modifier = Modifier
                            .size(68.dp)
                            .clickable { onEndCall() }
                            .testTag("call_end_button")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.CallEnd,
                                contentDescription = "Akhiri Panggilan",
                                tint = Color.White,
                                modifier = Modifier.size(32.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Tutup",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Color(0xFFFF8A80),
                            fontWeight = FontWeight.Bold,
                            fontSize = 11.sp
                        )
                    )
                }

                // Interrupt / Speak Now Button
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Surface(
                        shape = CircleShape,
                        color = if (callState == FaceToFaceCallState.SPEAKING) Color(0xFF00E5FF) else Color.White.copy(alpha = 0.18f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color.White.copy(alpha = 0.25f)),
                        modifier = Modifier
                            .size(56.dp)
                            .clickable { onInterruptOrSpeak() }
                            .testTag("call_interrupt_button")
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                imageVector = Icons.Default.RecordVoiceOver,
                                contentDescription = "Bicara Langsung / Interupsi",
                                tint = if (callState == FaceToFaceCallState.SPEAKING) Color.Black else Color.White,
                                modifier = Modifier.size(26.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (callState == FaceToFaceCallState.SPEAKING) "Interupsi" else "Bicara",
                        style = MaterialTheme.typography.labelSmall.copy(
                            color = Color.White.copy(alpha = 0.75f),
                            fontSize = 11.sp
                        )
                    )
                }
            }
        }

        // Quick Character Picker Modal within Face-to-Face call
        if (showCharacterPickerModal) {
            CharacterPickerDialog(
                currentCharacter = char,
                onSelectCharacter = { newChar ->
                    onSwitchCharacter(newChar)
                    showCharacterPickerModal = false
                },
                onPreviewVoice = { /* preview */ },
                onDismiss = { showCharacterPickerModal = false }
            )
        }
    }
}
