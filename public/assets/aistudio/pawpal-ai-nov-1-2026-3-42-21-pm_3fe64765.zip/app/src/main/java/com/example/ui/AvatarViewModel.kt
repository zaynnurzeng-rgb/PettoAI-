package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.GeminiChatService
import com.example.audio.SpeechRecognitionHelper
import com.example.audio.SpeechTtsEngine
import com.example.model.AppLanguage
import com.example.model.AvatarCustomization
import com.example.model.AvatarEmotion
import com.example.model.CharacterCatalog
import com.example.model.ChatMessage
import com.example.model.PetCharacter
import com.example.model.PetSpecies
import com.example.model.ReactionCatalog
import android.util.Log
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.TimeoutCancellationException

import com.example.model.BackgroundTheme
import com.example.model.TimeOfDay
import com.example.model.TouchZone
import com.example.model.EarStyle
import com.example.audio.VoiceEngineMode

enum class FaceToFaceCallState {
    CONNECTING,
    LISTENING,
    THINKING,
    SPEAKING,
    MUTED
}

data class AvatarUiState(
    val activeCharacter: PetCharacter = CharacterCatalog.characters.first(),
    val customization: AvatarCustomization = AvatarCustomization(),
    val messages: List<ChatMessage> = emptyList(),
    val lastAvatarSpeech: String = "",
    val isTalking: Boolean = false,
    val isListeningMic: Boolean = false,
    val showVoiceDialog: Boolean = false,
    val speechTranscript: String = "",
    val speechRms: Float = 0f,
    val speechServiceUnavailable: Boolean = false,
    val triggerSystemSpeechFallback: Boolean = false,
    val currentEmotion: AvatarEmotion = AvatarEmotion.IDLE,
    val affectionScore: Int = 20,
    val selectedLanguage: AppLanguage = AppLanguage.INDONESIAN,
    val voicePitch: Float = 1.25f,
    val speechRate: Float = 1.15f,
    val voiceEngineMode: VoiceEngineMode = VoiceEngineMode.CARTOON_MIMIC,
    val isLoadingAi: Boolean = false,
    val backgroundTheme: BackgroundTheme = BackgroundTheme.AUTO_REALTIME,
    val currentTimeOfDay: TimeOfDay = TimeOfDay.fromCurrentHour(),
    // Face-to-Face live hands-free conversation state
    val isFaceToFaceActive: Boolean = false,
    val faceToFaceCallState: FaceToFaceCallState = FaceToFaceCallState.CONNECTING,
    val isFaceToFaceMuted: Boolean = false,
    val liveUserSpeech: String = "",
    val liveAvatarSpeech: String = "",
    val callDurationSeconds: Int = 0
)

class AvatarViewModel(application: Application) : AndroidViewModel(application) {

    private val _uiState = MutableStateFlow(AvatarUiState())
    val uiState: StateFlow<AvatarUiState> = _uiState.asStateFlow()

    private val aiService = GeminiChatService(application)
    private var emotionResetJob: Job? = null
    private var callTimerJob: Job? = null
    private var autoListenJob: Job? = null

    private val ttsEngine = SpeechTtsEngine(application) { isSpeaking ->
        _uiState.value = _uiState.value.copy(
            isTalking = isSpeaking,
            currentEmotion = if (isSpeaking) AvatarEmotion.TALKING else AvatarEmotion.IDLE
        )
        if (!isSpeaking && _uiState.value.isFaceToFaceActive && !_uiState.value.isFaceToFaceMuted) {
            onAvatarFinishedSpeakingInCall()
        }
    }

    private val speechRecognitionHelper: SpeechRecognitionHelper = SpeechRecognitionHelper(
        context = application,
        onResult = { recognizedText ->
            if (recognizedText.isNotBlank()) {
                if (_uiState.value.isFaceToFaceActive) {
                    handleFaceToFaceUserUtterance(recognizedText)
                } else {
                    _uiState.value = _uiState.value.copy(
                        speechTranscript = recognizedText,
                        isListeningMic = false
                    )
                }
            }
        },
        onPartialResult = { partial ->
            if (partial.isNotBlank()) {
                if (_uiState.value.isFaceToFaceActive) {
                    _uiState.value = _uiState.value.copy(liveUserSpeech = partial)
                } else {
                    _uiState.value = _uiState.value.copy(speechTranscript = partial)
                }
            }
        },
        onRmsChanged = { rms ->
            _uiState.value = _uiState.value.copy(speechRms = rms)
        },
        onListeningStateChanged = { isListening ->
            _uiState.value = _uiState.value.copy(isListeningMic = isListening)
            if (_uiState.value.isFaceToFaceActive && !_uiState.value.isFaceToFaceMuted && isListening) {
                if (_uiState.value.faceToFaceCallState != FaceToFaceCallState.THINKING &&
                    _uiState.value.faceToFaceCallState != FaceToFaceCallState.SPEAKING) {
                    _uiState.value = _uiState.value.copy(faceToFaceCallState = FaceToFaceCallState.LISTENING)
                }
            }
        },
        onServiceUnavailable = {
            if (!_uiState.value.isFaceToFaceActive) {
                _uiState.value = _uiState.value.copy(
                    speechServiceUnavailable = true,
                    triggerSystemSpeechFallback = true,
                    isListeningMic = false
                )
            }
        },
        onErrorCallback = { errorCode ->
            onSpeechErrorInCall(errorCode)
        }
    )

    private fun onSpeechErrorInCall(errorCode: Int) {
        if (_uiState.value.isFaceToFaceActive && !_uiState.value.isFaceToFaceMuted) {
            if (errorCode == android.speech.SpeechRecognizer.ERROR_SPEECH_TIMEOUT ||
                errorCode == android.speech.SpeechRecognizer.ERROR_NO_MATCH) {
                autoListenJob?.cancel()
                autoListenJob = viewModelScope.launch {
                    delay(600)
                    if (_uiState.value.isFaceToFaceActive &&
                        !_uiState.value.isFaceToFaceMuted &&
                        !_uiState.value.isTalking &&
                        _uiState.value.faceToFaceCallState != FaceToFaceCallState.THINKING) {
                        _uiState.value = _uiState.value.copy(faceToFaceCallState = FaceToFaceCallState.LISTENING)
                        speechRecognitionHelper.startListening(_uiState.value.selectedLanguage)
                    }
                }
            }
        }
    }

    private val prefs by lazy {
        application.getSharedPreferences("pawpal_ai_prefs", android.content.Context.MODE_PRIVATE)
    }

    init {
        val initialChar = _uiState.value.activeCharacter
        val initialMode = getVoiceEngineMode()

        _uiState.value = _uiState.value.copy(
            voicePitch = initialChar.defaultVoicePitch,
            speechRate = initialChar.defaultSpeechRate,
            voiceEngineMode = initialMode,
            customization = _uiState.value.customization.copy(furColor = initialChar.defaultFurColor)
        )

        ttsEngine.engineMode = initialMode
        ttsEngine.elevenLabsApiKey = getElevenLabsApiKey()
        ttsEngine.googleApiKey = getGoogleCloudTtsApiKey()
        ttsEngine.setVoiceProfile(initialChar.defaultVoicePitch, initialChar.defaultSpeechRate)
        ttsEngine.setLanguage(_uiState.value.selectedLanguage)

        viewModelScope.launch {
            delay(500)
            deliverGreeting(initialChar, _uiState.value.selectedLanguage)
        }
    }

    private fun deliverGreeting(character: PetCharacter, language: AppLanguage) {
        val greetingText = when (character.id) {
            "zayn" -> "Cih! Aku Zayn. Ngapain kamu ke sini? B-bukan berarti aku seneng ditemenin ya! Cepetan mau apa?!"
            "siti" -> "Halo sayangku manis, nama Siti. Siti sangat bersyukur bisa mendampingimu hari ini. Ceritakan harimu ya sayang."
            "rizky" -> "Siap! Rizky siap bertugas! Pertahankan disiplin dan fokus pada target kita hari ini!"
            "jamal" -> "Hoaaammm... Jamal lagi mager banget nih. Kalau gak ada urusan penting mending kita tidur siang bareng."
            else -> "HEH! Lu ngeliatin apa?! Gua Heru, jangan cari gara-gara sama gua kalau gak mau kena semprot!"
        }

        updateSpeechAndAutoSpeak(greetingText, AvatarEmotion.HAPPY)
    }

    /**
     * Wake Word calling ("Hey Petto" / "Halo Petto"):
     * Avatar immediately wakes up with surprised/attentive reaction, speaks back in character,
     * and automatically opens voice input so the user can speak immediately!
     */
    fun callHeyPetto() {
        val char = _uiState.value.activeCharacter
        val lang = _uiState.value.selectedLanguage
        val response = ReactionCatalog.getWakeWordResponse(char, lang)

        // Wake up avatar
        _uiState.value = _uiState.value.copy(currentEmotion = AvatarEmotion.SURPRISED)
        ttsEngine.playHappyChime()
        updateSpeechAndAutoSpeak(response, AvatarEmotion.SURPRISED)

        // Automatically open voice listening dialog after small delay so user can immediately speak!
        viewModelScope.launch {
            delay(1400)
            openVoiceInput()
        }
    }

    fun updateSpeechAndAutoSpeak(text: String, emotion: AvatarEmotion = AvatarEmotion.TALKING) {
        if (text.isBlank()) return

        _uiState.value = _uiState.value.copy(
            lastAvatarSpeech = text,
            currentEmotion = emotion
        )

        ttsEngine.speak(
            text = text,
            pitch = _uiState.value.voicePitch,
            rate = _uiState.value.speechRate,
            character = _uiState.value.activeCharacter
        )

        emotionResetJob?.cancel()
        emotionResetJob = viewModelScope.launch {
            delay(3500)
            if (_uiState.value.currentEmotion != AvatarEmotion.IDLE && !_uiState.value.isTalking) {
                _uiState.value = _uiState.value.copy(currentEmotion = AvatarEmotion.IDLE)
            }
        }
    }

    fun sendMessage(text: String) {
        if (text.isBlank()) return

        val state = _uiState.value

        // Check wake word in text
        val lower = text.lowercase()
        if (lower.contains("hey petto") || lower.contains("halo petto") || lower.contains("hai petto")) {
            val userMsg = ChatMessage(senderName = "Kamu", text = text, isUser = true)
            val wakeReply = ReactionCatalog.getWakeWordResponse(state.activeCharacter, state.selectedLanguage)
            val avatarReplyMsg = ChatMessage(senderName = state.activeCharacter.name, text = wakeReply, isUser = false, emotion = AvatarEmotion.SURPRISED)
            _uiState.value = state.copy(
                messages = state.messages + userMsg + avatarReplyMsg,
                affectionScore = (state.affectionScore + 3).coerceAtMost(100)
            )
            updateSpeechAndAutoSpeak(wakeReply, AvatarEmotion.SURPRISED)
            return
        }

        val userMsg = ChatMessage(
            senderName = "Kamu",
            text = text,
            isUser = true
        )

        val updatedMessages = state.messages + userMsg
        _uiState.value = state.copy(
            messages = updatedMessages,
            isLoadingAi = true,
            currentEmotion = AvatarEmotion.TALKING
        )

        viewModelScope.launch {
            try {
                // Generates AI reply or falls back quickly within 5.0 seconds max
                val reply = withTimeoutOrNull(5000L) {
                    aiService.generateReply(
                        userMessage = text,
                        character = state.activeCharacter,
                        language = state.selectedLanguage,
                        history = updatedMessages
                    )
                } ?: aiService.getFastFallbackReply(
                    userMessage = text,
                    character = state.activeCharacter,
                    language = state.selectedLanguage
                )

                val avatarReplyMsg = ChatMessage(
                    senderName = state.activeCharacter.name,
                    text = reply.text,
                    isUser = false,
                    emotion = reply.emotion
                )

                val newAffection = (state.affectionScore + 3).coerceAtMost(100)

                _uiState.value = _uiState.value.copy(
                    messages = _uiState.value.messages + avatarReplyMsg,
                    isLoadingAi = false,
                    affectionScore = newAffection
                )

                updateSpeechAndAutoSpeak(reply.text, reply.emotion)
            } catch (e: TimeoutCancellationException) {
                Log.d("AvatarViewModel", "AI response timeout: ${e.message}, using fallback")
                val fallbackReply = aiService.getFastFallbackReply(
                    userMessage = text,
                    character = state.activeCharacter,
                    language = state.selectedLanguage
                )
                val avatarReplyMsg = ChatMessage(
                    senderName = state.activeCharacter.name,
                    text = fallbackReply.text,
                    isUser = false,
                    emotion = fallbackReply.emotion
                )
                _uiState.value = _uiState.value.copy(
                    messages = _uiState.value.messages + avatarReplyMsg,
                    isLoadingAi = false
                )
                updateSpeechAndAutoSpeak(fallbackReply.text, fallbackReply.emotion)
            } catch (e: Exception) {
                Log.e("AvatarViewModel", "Error in sendMessage: ${e.message}", e)
                val fallbackReply = aiService.getFastFallbackReply(
                    userMessage = text,
                    character = state.activeCharacter,
                    language = state.selectedLanguage
                )
                val avatarReplyMsg = ChatMessage(
                    senderName = state.activeCharacter.name,
                    text = fallbackReply.text,
                    isUser = false,
                    emotion = fallbackReply.emotion
                )
                _uiState.value = _uiState.value.copy(
                    messages = _uiState.value.messages + avatarReplyMsg,
                    isLoadingAi = false
                )
                updateSpeechAndAutoSpeak(fallbackReply.text, fallbackReply.emotion)
            } finally {
                _uiState.value = _uiState.value.copy(isLoadingAi = false)
            }
        }
    }

    fun onCharacterTouched(zone: TouchZone) {
        val state = _uiState.value
        val newAffection = (state.affectionScore + 3).coerceAtMost(100)

        // Trigger expressive procedural cartoon touch reaction sound effect (giggle, boing, pop, purr, grunt)
        ttsEngine.playTouchSound(state.activeCharacter.species, zone)

        val reactionText = ReactionCatalog.getTouchZoneReaction(state.activeCharacter, zone, state.selectedLanguage)
        val emotion = when (zone) {
            TouchZone.HEAD -> AvatarEmotion.HAPPY
            TouchZone.BELLY -> AvatarEmotion.LOVING
            TouchZone.HANDS -> AvatarEmotion.TALKING
            TouchZone.FEET -> AvatarEmotion.SURPRISED
        }
        _uiState.value = state.copy(affectionScore = newAffection)
        updateSpeechAndAutoSpeak(reactionText, emotion)
    }

    fun petAvatar() {
        onCharacterTouched(TouchZone.HEAD)
    }

    fun setBackgroundTheme(theme: BackgroundTheme) {
        _uiState.value = _uiState.value.copy(backgroundTheme = theme)
    }

    fun cycleBackgroundTheme() {
        val themes = BackgroundTheme.values()
        val currentIndex = themes.indexOf(_uiState.value.backgroundTheme)
        val nextTheme = themes[(currentIndex + 1) % themes.size]
        setBackgroundTheme(nextTheme)
    }

    fun openVoiceInput() {
        _uiState.value = _uiState.value.copy(
            showVoiceDialog = true,
            speechTranscript = "",
            speechServiceUnavailable = false,
            triggerSystemSpeechFallback = false
        )
        speechRecognitionHelper.startListening(_uiState.value.selectedLanguage)
    }

    fun onSystemSpeechFallbackConsumed() {
        _uiState.value = _uiState.value.copy(triggerSystemSpeechFallback = false)
    }

    fun closeVoiceInput() {
        speechRecognitionHelper.stopListening()
        _uiState.value = _uiState.value.copy(
            showVoiceDialog = false,
            speechTranscript = "",
            isListeningMic = false,
            triggerSystemSpeechFallback = false
        )
    }

    fun onFallbackSpeechResult(text: String) {
        if (text.isNotBlank()) {
            _uiState.value = _uiState.value.copy(
                speechTranscript = text,
                showVoiceDialog = true
            )
        }
    }

    fun sendVoiceTranscript(text: String) {
        closeVoiceInput()
        sendMessage(text)
    }

    fun replayCurrentSpeech() {
        val speech = _uiState.value.lastAvatarSpeech
        if (speech.isNotBlank()) {
            ttsEngine.speak(speech, _uiState.value.voicePitch, _uiState.value.speechRate)
        }
    }

    fun speakText(text: String) {
        updateSpeechAndAutoSpeak(text, AvatarEmotion.TALKING)
    }

    fun updateCustomization(newCustomization: AvatarCustomization) {
        val old = _uiState.value.customization
        val char = _uiState.value.activeCharacter
        val lang = _uiState.value.selectedLanguage
        _uiState.value = _uiState.value.copy(customization = newCustomization)

        val reactionText = when {
            newCustomization.costume != old.costume ->
                ReactionCatalog.getCostumeReaction(newCustomization.costume, char, lang)
            newCustomization.accessory != old.accessory ->
                ReactionCatalog.getAccessoryReaction(newCustomization.accessory, char, lang)
            newCustomization.furColorId != old.furColorId ->
                ReactionCatalog.getFurColorReaction(newCustomization.furColorId, char, lang)
            newCustomization.roomTheme != old.roomTheme ->
                when (char.id) {
                    "zayn" -> "Hmph! Ruangan ${newCustomization.roomTheme.displayName}? Baguslah, lumayan nyaman."
                    "siti" -> "Ruangan ${newCustomization.roomTheme.displayName} ini sangat indah dan damai sayang."
                    "rizky" -> "Lokasi pangkalan ${newCustomization.roomTheme.displayName} telah siap beroperasi!"
                    "jamal" -> "Ruangan baru? Yang penting kasurnya empuk buat rebahan."
                    else -> "Ruangan ${newCustomization.roomTheme.displayName}? Jangan sampai berantakan, awas lu!"
                }
            else -> ""
        }

        if (reactionText.isNotBlank()) {
            updateSpeechAndAutoSpeak(reactionText, AvatarEmotion.HAPPY)
        }
    }

    fun selectCharacter(character: PetCharacter) {
        ttsEngine.stop()
        ttsEngine.setVoiceProfile(character.defaultVoicePitch, character.defaultSpeechRate)

        _uiState.value = _uiState.value.copy(
            activeCharacter = character,
            voicePitch = character.defaultVoicePitch,
            speechRate = character.defaultSpeechRate,
            customization = _uiState.value.customization.copy(
                furColor = character.defaultFurColor,
                earStyle = if (character.species == PetSpecies.DOG) com.example.model.EarStyle.DOG_FLOPPY else com.example.model.EarStyle.CAT_POINTY
            )
        )

        deliverGreeting(character, _uiState.value.selectedLanguage)
    }

    fun setLanguage(language: AppLanguage) {
        _uiState.value = _uiState.value.copy(selectedLanguage = language)
        ttsEngine.setLanguage(language)
        deliverGreeting(_uiState.value.activeCharacter, language)
    }

    fun setVoicePitch(pitch: Float) {
        _uiState.value = _uiState.value.copy(voicePitch = pitch)
        ttsEngine.setVoiceProfile(pitch, _uiState.value.speechRate)
    }

    fun setSpeechRate(rate: Float) {
        _uiState.value = _uiState.value.copy(speechRate = rate)
        ttsEngine.setVoiceProfile(_uiState.value.voicePitch, rate)
    }

    fun testVoice() {
        val testPhrase = when (_uiState.value.selectedLanguage) {
            AppLanguage.INDONESIAN -> "Halo! Suaraku terdengar bagus dan jernih, kan?"
            AppLanguage.ENGLISH -> "Hello! My voice sounds crisp and friendly, right?"
            AppLanguage.JAPANESE -> "こんにちは！私の声は聞こえますか？"
            AppLanguage.SPANISH -> "¡Hola! Mi voz se escucha muy bien, ¿verdad?"
        }
        updateSpeechAndAutoSpeak(testPhrase, AvatarEmotion.HAPPY)
    }

    fun clearHistory() {
        _uiState.value = _uiState.value.copy(messages = emptyList())
    }

    fun getCustomApiKey(): String = aiService.getCustomApiKey()
    fun setCustomApiKey(key: String) = aiService.setCustomApiKey(key)
    fun isGeminiConnected(): Boolean = aiService.getEffectiveApiKey().isNotBlank()

    fun getVoiceEngineMode(): VoiceEngineMode {
        val name = prefs.getString("voice_engine_mode", VoiceEngineMode.CARTOON_MIMIC.name)
        return try {
            VoiceEngineMode.valueOf(name ?: VoiceEngineMode.CARTOON_MIMIC.name)
        } catch (e: Exception) {
            VoiceEngineMode.CARTOON_MIMIC
        }
    }

    fun setVoiceEngineMode(mode: VoiceEngineMode) {
        prefs.edit().putString("voice_engine_mode", mode.name).apply()
        _uiState.value = _uiState.value.copy(voiceEngineMode = mode)
        ttsEngine.engineMode = mode
    }

    fun getElevenLabsApiKey(): String = prefs.getString("elevenlabs_api_key", "") ?: ""
    fun setElevenLabsApiKey(key: String) {
        val trimmed = key.trim()
        prefs.edit().putString("elevenlabs_api_key", trimmed).apply()
        ttsEngine.elevenLabsApiKey = trimmed
    }

    fun getGoogleCloudTtsApiKey(): String {
        val custom = prefs.getString("google_cloud_tts_api_key", "") ?: ""
        if (custom.isNotBlank()) return custom
        return aiService.getEffectiveApiKey()
    }

    fun setGoogleCloudTtsApiKey(key: String) {
        val trimmed = key.trim()
        prefs.edit().putString("google_cloud_tts_api_key", trimmed).apply()
        ttsEngine.googleApiKey = if (trimmed.isNotBlank()) trimmed else aiService.getEffectiveApiKey()
    }

    fun startFaceToFaceCall() {
        ttsEngine.stop()
        speechRecognitionHelper.stopListening()
        autoListenJob?.cancel()
        callTimerJob?.cancel()

        val char = _uiState.value.activeCharacter
        val openingLine = when (char.id) {
            "zayn" -> "Hah?! Ngapain kamu video call ke aku?! B-bukan berarti aku seneng ya! Mau ngomong apa, cepetan?!"
            "siti" -> "Halo sayangku manis, Siti senang sekali bisa tatap muka langsung sama kamu. Ada cerita apa hari ini sayang?"
            "rizky" -> "Panggilan tatap muka terhubung! Sersan Rizky siap bertugas dan mendengarkan laporanmu. Silakan bicara!"
            "jamal" -> "Hoaaam... Video call segala bro, Jamal lagi pw rebahan nih. Yaudah mau ngobrolin apa santai aja..."
            else -> "HEH! Nelpon-nelpon gua lu! Awas aja kalau gak penting gua cakar! Ngomong sekarang lu mau apa?!"
        }

        _uiState.value = _uiState.value.copy(
            isFaceToFaceActive = true,
            faceToFaceCallState = FaceToFaceCallState.SPEAKING,
            isFaceToFaceMuted = false,
            liveUserSpeech = "",
            liveAvatarSpeech = openingLine,
            callDurationSeconds = 0,
            showVoiceDialog = false,
            lastAvatarSpeech = openingLine,
            currentEmotion = AvatarEmotion.HAPPY
        )

        // Start call duration timer
        callTimerJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                if (_uiState.value.isFaceToFaceActive) {
                    _uiState.value = _uiState.value.copy(callDurationSeconds = _uiState.value.callDurationSeconds + 1)
                } else {
                    break
                }
            }
        }

        // Deliver spoken opening line
        ttsEngine.playHappyChime()
        ttsEngine.speak(openingLine, _uiState.value.voicePitch, _uiState.value.speechRate)
    }

    fun endFaceToFaceCall() {
        callTimerJob?.cancel()
        autoListenJob?.cancel()
        ttsEngine.stop()
        speechRecognitionHelper.stopListening()

        _uiState.value = _uiState.value.copy(
            isFaceToFaceActive = false,
            faceToFaceCallState = FaceToFaceCallState.CONNECTING,
            liveUserSpeech = "",
            liveAvatarSpeech = "",
            isListeningMic = false
        )
    }

    fun toggleFaceToFaceMute() {
        val newMuted = !_uiState.value.isFaceToFaceMuted
        _uiState.value = _uiState.value.copy(
            isFaceToFaceMuted = newMuted,
            faceToFaceCallState = if (newMuted) FaceToFaceCallState.MUTED else FaceToFaceCallState.LISTENING
        )
        if (newMuted) {
            speechRecognitionHelper.stopListening()
            autoListenJob?.cancel()
        } else {
            if (!_uiState.value.isTalking) {
                speechRecognitionHelper.startListening(_uiState.value.selectedLanguage)
            }
        }
    }

    fun interruptOrSpeak() {
        autoListenJob?.cancel()
        if (_uiState.value.isTalking) {
            ttsEngine.stop()
        }
        _uiState.value = _uiState.value.copy(
            isFaceToFaceMuted = false,
            faceToFaceCallState = FaceToFaceCallState.LISTENING
        )
        speechRecognitionHelper.startListening(_uiState.value.selectedLanguage)
    }

    fun handleFaceToFaceUserUtterance(text: String) {
        val cleanText = text.trim()
        if (cleanText.isBlank()) return

        autoListenJob?.cancel()
        val state = _uiState.value

        val userMsg = ChatMessage(senderName = "Kamu", text = cleanText, isUser = true)
        val updatedMessages = state.messages + userMsg

        _uiState.value = state.copy(
            liveUserSpeech = cleanText,
            messages = updatedMessages,
            faceToFaceCallState = FaceToFaceCallState.THINKING,
            currentEmotion = AvatarEmotion.TALKING,
            isListeningMic = false
        )

        viewModelScope.launch {
            try {
                val reply = withTimeoutOrNull(5000L) {
                    aiService.generateReply(
                        userMessage = cleanText,
                        character = state.activeCharacter,
                        language = state.selectedLanguage,
                        history = updatedMessages
                    )
                } ?: aiService.getFastFallbackReply(
                    userMessage = cleanText,
                    character = state.activeCharacter,
                    language = state.selectedLanguage
                )

                val avatarReplyMsg = ChatMessage(
                    senderName = state.activeCharacter.name,
                    text = reply.text,
                    isUser = false,
                    emotion = reply.emotion
                )

                val newAffection = (state.affectionScore + 3).coerceAtMost(100)

                _uiState.value = _uiState.value.copy(
                    messages = _uiState.value.messages + avatarReplyMsg,
                    liveAvatarSpeech = reply.text,
                    lastAvatarSpeech = reply.text,
                    currentEmotion = reply.emotion,
                    faceToFaceCallState = FaceToFaceCallState.SPEAKING,
                    affectionScore = newAffection
                )

                ttsEngine.speak(reply.text, _uiState.value.voicePitch, _uiState.value.speechRate)
            } catch (e: TimeoutCancellationException) {
                Log.d("AvatarViewModel", "Face-to-face AI timeout: ${e.message}, using fallback")
                val fallbackReply = aiService.getFastFallbackReply(
                    userMessage = cleanText,
                    character = state.activeCharacter,
                    language = state.selectedLanguage
                )
                _uiState.value = _uiState.value.copy(
                    liveAvatarSpeech = fallbackReply.text,
                    lastAvatarSpeech = fallbackReply.text,
                    currentEmotion = fallbackReply.emotion,
                    faceToFaceCallState = FaceToFaceCallState.SPEAKING
                )
                ttsEngine.speak(fallbackReply.text, _uiState.value.voicePitch, _uiState.value.speechRate)
            } catch (e: Exception) {
                Log.e("AvatarViewModel", "Error in handleFaceToFaceUserUtterance: ${e.message}", e)
                val fallbackReply = aiService.getFastFallbackReply(
                    userMessage = cleanText,
                    character = state.activeCharacter,
                    language = state.selectedLanguage
                )
                _uiState.value = _uiState.value.copy(
                    liveAvatarSpeech = fallbackReply.text,
                    lastAvatarSpeech = fallbackReply.text,
                    currentEmotion = fallbackReply.emotion,
                    faceToFaceCallState = FaceToFaceCallState.SPEAKING
                )
                ttsEngine.speak(fallbackReply.text, _uiState.value.voicePitch, _uiState.value.speechRate)
            }
        }
    }

    fun quickPromptFaceToFace(promptText: String) {
        handleFaceToFaceUserUtterance(promptText)
    }

    fun switchCharacterInFaceToFace(character: PetCharacter) {
        ttsEngine.stop()
        speechRecognitionHelper.stopListening()
        autoListenJob?.cancel()

        ttsEngine.setVoiceProfile(character.defaultVoicePitch, character.defaultSpeechRate)

        val greeting = when (character.id) {
            "zayn" -> "Hmph! Sekarang kamu ngobrol sama Zayn! Jangan mikir aneh-aneh ya!"
            "siti" -> "Halo sayang, Siti hadir di sini untukmu. Siti siap mendengarkan."
            "rizky" -> "Pergantian personel! Sersan Rizky mengambil alih komunikasi!"
            "jamal" -> "Yoo, sekarang giliran Jamal. Santai aja ya ngobrolnya..."
            else -> "SEKARANG GUA HERU YANG HADEPIN LU! Mau ngomong apa lu?!"
        }

        _uiState.value = _uiState.value.copy(
            activeCharacter = character,
            voicePitch = character.defaultVoicePitch,
            speechRate = character.defaultSpeechRate,
            liveAvatarSpeech = greeting,
            lastAvatarSpeech = greeting,
            faceToFaceCallState = FaceToFaceCallState.SPEAKING,
            customization = _uiState.value.customization.copy(
                furColor = character.defaultFurColor,
                earStyle = if (character.species == PetSpecies.DOG) com.example.model.EarStyle.DOG_FLOPPY else com.example.model.EarStyle.CAT_POINTY
            )
        )

        ttsEngine.speak(greeting, character.defaultVoicePitch, character.defaultSpeechRate)
    }

    private fun onAvatarFinishedSpeakingInCall() {
        autoListenJob?.cancel()
        autoListenJob = viewModelScope.launch {
            delay(350)
            if (_uiState.value.isFaceToFaceActive &&
                !_uiState.value.isFaceToFaceMuted &&
                !_uiState.value.isTalking &&
                _uiState.value.faceToFaceCallState != FaceToFaceCallState.THINKING) {
                _uiState.value = _uiState.value.copy(faceToFaceCallState = FaceToFaceCallState.LISTENING)
                speechRecognitionHelper.startListening(_uiState.value.selectedLanguage)
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        ttsEngine.release()
        speechRecognitionHelper.destroy()
    }
}
