package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import com.example.model.BackgroundTheme
import com.example.model.TimeOfDay
import kotlin.math.sin
import kotlin.random.Random

private data class AmbientParticle(
    val initialXRatio: Float,
    val initialYRatio: Float,
    val radius: Float,
    val speed: Float,
    val phase: Float,
    val color: Color
)

@Composable
fun DynamicBackgroundCanvas(
    theme: BackgroundTheme,
    currentTimeOfDay: TimeOfDay,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "ambient")
    val animProgress by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 8000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "ambientProgress"
    )

    // Generate random stable particles for atmosphere
    val particles = remember(theme, currentTimeOfDay) {
        val rand = Random(42)
        List(24) {
            val color = when (theme) {
                BackgroundTheme.AUTO_REALTIME -> when (currentTimeOfDay) {
                    TimeOfDay.DAWN -> Color(0xFFFFD1DC)
                    TimeOfDay.DAY -> Color(0xFFFFFFFF)
                    TimeOfDay.SUNSET -> Color(0xFFFFB74D)
                    TimeOfDay.NIGHT -> Color(0xFFE0E7FF)
                }
                BackgroundTheme.COZY_ROOM -> Color(0xFFFFE082)
                BackgroundTheme.SUNSET_GLOW -> Color(0xFFFF7043)
                BackgroundTheme.CYBERPUNK_NEON -> if (it % 2 == 0) Color(0xFF00F5D4) else Color(0xFFFF007F)
                BackgroundTheme.SAKURA_GARDEN -> Color(0xFFFF8DA1)
                BackgroundTheme.DEEP_SPACE -> if (it % 3 == 0) Color(0xFFC084FC) else Color(0xFFE0E7FF)
            }
            AmbientParticle(
                initialXRatio = rand.nextFloat(),
                initialYRatio = rand.nextFloat(),
                radius = rand.nextFloat() * 3.5f + 1.5f,
                speed = rand.nextFloat() * 0.8f + 0.4f,
                phase = rand.nextFloat() * 6.28f,
                color = color
            )
        }
    }

    Canvas(modifier = modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height

        // Determine effective gradient colors
        val (topColor, midColor, botColor, floorColor) = when (theme) {
            BackgroundTheme.AUTO_REALTIME -> when (currentTimeOfDay) {
                TimeOfDay.DAWN -> listOf(
                    Color(0xFF2C1943),
                    Color(0xFF8E4A68),
                    Color(0xFFFFB380),
                    Color(0xFF4A343D)
                )
                TimeOfDay.DAY -> listOf(
                    Color(0xFF3877D9),
                    Color(0xFF64B5F6),
                    Color(0xFFE1F5FE),
                    Color(0xFF78909C)
                )
                TimeOfDay.SUNSET -> listOf(
                    Color(0xFF261132),
                    Color(0xFF722B6A),
                    Color(0xFFFF7043),
                    Color(0xFF3E1E28)
                )
                TimeOfDay.NIGHT -> listOf(
                    Color(0xFF090D1A),
                    Color(0xFF131B2E),
                    Color(0xFF1F2942),
                    Color(0xFF0F1522)
                )
            }
            BackgroundTheme.COZY_ROOM -> listOf(
                Color(0xFFFFF3E0),
                Color(0xFFFFE0B2),
                Color(0xFFFFCC80),
                Color(0xFF8D6E63)
            )
            BackgroundTheme.SUNSET_GLOW -> listOf(
                Color(0xFF3F2B96),
                Color(0xFF9E2A2B),
                Color(0xFFE85D04),
                Color(0xFF370617)
            )
            BackgroundTheme.CYBERPUNK_NEON -> listOf(
                Color(0xFF09021F),
                Color(0xFF1E0E3E),
                Color(0xFF301B58),
                Color(0xFF0A0217)
            )
            BackgroundTheme.SAKURA_GARDEN -> listOf(
                Color(0xFFFDE2E4),
                Color(0xFFFFCAD4),
                Color(0xFFE2ECE9),
                Color(0xFF8E9A82)
            )
            BackgroundTheme.DEEP_SPACE -> listOf(
                Color(0xFF040209),
                Color(0xFF0E0720),
                Color(0xFF1A0B3B),
                Color(0xFF020106)
            )
        }

        // 1. Sky / Wall Layer
        val skyBrush = Brush.verticalGradient(
            colors = listOf(topColor, midColor, botColor),
            startY = 0f,
            endY = h * 0.72f
        )
        drawRect(brush = skyBrush, size = Size(w, h * 0.72f))

        // 2. Horizon Glow / Backlight
        val horizonGlow = Brush.radialGradient(
            colors = listOf(
                botColor.copy(alpha = 0.6f),
                Color.Transparent
            ),
            center = Offset(w * 0.5f, h * 0.72f),
            radius = w * 0.75f
        )
        drawRect(brush = horizonGlow, size = Size(w, h * 0.72f))

        // 3. Floor / Room Base
        val floorY = h * 0.70f
        val floorBrush = Brush.verticalGradient(
            colors = listOf(
                floorColor.copy(alpha = 0.95f),
                floorColor
            ),
            startY = floorY,
            endY = h
        )
        drawRect(
            brush = floorBrush,
            topLeft = Offset(0f, floorY),
            size = Size(w, h - floorY)
        )

        // Perspective floor line
        drawLine(
            color = Color.White.copy(alpha = 0.15f),
            start = Offset(0f, floorY),
            end = Offset(w, floorY),
            strokeWidth = 2f
        )

        // Perspective grid lines if Cyberpunk
        if (theme == BackgroundTheme.CYBERPUNK_NEON) {
            val gridColor = Color(0xFF00F5D4).copy(alpha = 0.35f)
            val vanishingPoint = Offset(w * 0.5f, floorY)
            val numLines = 8
            for (i in 0..numLines) {
                val endX = w * (i.toFloat() / numLines)
                drawLine(
                    color = gridColor,
                    start = vanishingPoint,
                    end = Offset(endX, h),
                    strokeWidth = 1.5f
                )
            }
            // Horizontal perspective lines
            for (j in 1..4) {
                val y = floorY + (h - floorY) * (j * j / 16f)
                drawLine(
                    color = gridColor,
                    start = Offset(0f, y),
                    end = Offset(w, y),
                    strokeWidth = 1.2f
                )
            }
        }

        // 4. Ambient Animated Particles (Stars, dust motes, petals, neon sparkles)
        particles.forEach { p ->
            val dynamicY = ((p.initialYRatio + animProgress * p.speed) % 1.0f) * (h * 0.70f)
            val wobbleX = sin(animProgress * 6.28f * p.speed + p.phase) * 16f
            val dynamicX = (p.initialXRatio * w + wobbleX).coerceIn(0f, w)

            val alphaPulse = (sin(animProgress * 6.28f * 1.5f + p.phase) * 0.3f + 0.7f).coerceIn(0.2f, 1f)
            drawCircle(
                color = p.color.copy(alpha = alphaPulse * 0.75f),
                radius = p.radius,
                center = Offset(dynamicX, dynamicY)
            )
        }

        // Cozy room window illustration / decorative room element
        if (theme == BackgroundTheme.COZY_ROOM) {
            drawCozyWindow(w, h)
        }
    }
}

private fun DrawScope.drawCozyWindow(w: Float, h: Float) {
    val winW = w * 0.28f
    val winH = h * 0.22f
    val winX = w * 0.65f
    val winY = h * 0.12f

    // Window frame
    drawRoundRect(
        color = Color(0x60FFFFFF),
        topLeft = Offset(winX, winY),
        size = Size(winW, winH),
        cornerRadius = androidx.compose.ui.geometry.CornerRadius(12f, 12f)
    )
    // Warm sunlight beam
    val beamPath = Path().apply {
        moveTo(winX + winW * 0.2f, winY + winH)
        lineTo(winX + winW * 0.8f, winY + winH)
        lineTo(winX + winW * 1.4f, h * 0.70f)
        lineTo(winX - winW * 0.4f, h * 0.70f)
        close()
    }
    drawPath(
        path = beamPath,
        color = Color(0x18FFD54F)
    )
}
