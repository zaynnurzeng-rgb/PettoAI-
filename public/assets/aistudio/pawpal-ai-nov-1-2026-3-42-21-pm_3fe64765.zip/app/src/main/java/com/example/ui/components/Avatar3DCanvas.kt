package com.example.ui.components

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.input.pointer.pointerInput
import com.example.model.AccessoryStyle
import com.example.model.AvatarCustomization
import com.example.model.AvatarEmotion
import com.example.model.CostumeStyle
import com.example.model.PetSpecies
import com.example.model.TouchZone
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

data class TouchParticle(
    val id: Long,
    val x: Float,
    val y: Float,
    val symbol: String,
    val color: Color,
    val size: Float = 22f
)

@Composable
fun Avatar3DCanvas(
    species: PetSpecies,
    customization: AvatarCustomization,
    emotion: AvatarEmotion,
    isTalking: Boolean,
    onZoneTouched: (TouchZone) -> Unit,
    modifier: Modifier = Modifier
) {
    val coroutineScope = rememberCoroutineScope()

    // 3D Tilt angles (rotationX, rotationY in degrees)
    val tiltX = remember { Animatable(0f) }
    val tiltY = remember { Animatable(0f) }

    // Zone reaction animations
    val headBob = remember { Animatable(0f) }
    val bellyJiggle = remember { Animatable(0f) }
    val handsWave = remember { Animatable(0f) }
    val feetJump = remember { Animatable(0f) }

    // Natural blinking
    var isBlinking by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) {
        while (isActive) {
            delay((3000..5000).random().toLong())
            isBlinking = true
            delay(150)
            isBlinking = false
        }
    }

    // Idle breathing & floating transition
    val infiniteTransition = rememberInfiniteTransition(label = "idle3d")
    val idleFloatY by infiniteTransition.animateFloat(
        initialValue = -4f,
        targetValue = 6f,
        animationSpec = infiniteRepeatable(
            animation = tween(2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "idleFloatY"
    )

    // Tail wagging animation
    val tailWag by infiniteTransition.animateFloat(
        initialValue = -12f,
        targetValue = 15f,
        animationSpec = infiniteRepeatable(
            animation = tween(if (species == PetSpecies.DOG) 320 else 700, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "tailWag"
    )

    // Mouth animation when speaking
    val mouthCycle by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(140, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "mouthCycle"
    )

    // Touch particles list
    val touchParticles = remember { mutableStateListOf<TouchParticle>() }

    // Particle decay loop
    LaunchedEffect(touchParticles.size) {
        if (touchParticles.isNotEmpty()) {
            delay(1200)
            if (touchParticles.isNotEmpty()) {
                touchParticles.removeAt(0)
            }
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            // 3D Drag / Tilt interaction
            .pointerInput(Unit) {
                detectDragGestures(
                    onDrag = { change, dragAmount ->
                        change.consume()
                        coroutineScope.launch {
                            val newY = (tiltY.value + dragAmount.x * 0.18f).coerceIn(-28f, 28f)
                            val newX = (tiltX.value - dragAmount.y * 0.18f).coerceIn(-22f, 22f)
                            tiltY.snapTo(newY)
                            tiltX.snapTo(newX)
                        }
                    },
                    onDragEnd = {
                        // Smoothly spring back to center facing
                        coroutineScope.launch {
                            tiltX.animateTo(0f, spring(dampingRatio = 0.55f, stiffness = 300f))
                        }
                        coroutineScope.launch {
                            tiltY.animateTo(0f, spring(dampingRatio = 0.55f, stiffness = 300f))
                        }
                    }
                )
            }
            // Raycast Touch Listener
            .pointerInput(species) {
                detectTapGestures(
                    onTap = { offset ->
                        // Raycast mapping to 3D zones relative to character center
                        val zone = raycastTouchZone(offset, size.width.toFloat(), size.height.toFloat())
                        onZoneTouched(zone)

                        // Trigger visual reaction & particle burst based on zone
                        coroutineScope.launch {
                            when (zone) {
                                TouchZone.HEAD -> {
                                    headBob.animateTo(10f, spring(dampingRatio = 0.4f, stiffness = 600f))
                                    headBob.animateTo(0f, spring(dampingRatio = 0.6f))
                                }
                                TouchZone.BELLY -> {
                                    bellyJiggle.animateTo(12f, spring(dampingRatio = 0.35f, stiffness = 700f))
                                    bellyJiggle.animateTo(-8f, spring(dampingRatio = 0.45f))
                                    bellyJiggle.animateTo(0f, spring(dampingRatio = 0.6f))
                                }
                                TouchZone.HANDS -> {
                                    handsWave.animateTo(18f, spring(dampingRatio = 0.4f, stiffness = 500f))
                                    handsWave.animateTo(0f, spring(dampingRatio = 0.6f))
                                }
                                TouchZone.FEET -> {
                                    feetJump.animateTo(-24f, spring(dampingRatio = 0.38f, stiffness = 550f))
                                    feetJump.animateTo(0f, spring(dampingRatio = 0.55f))
                                }
                            }
                        }

                        // Spawn zone-specific touch particle
                        val (symbol, color) = when (zone) {
                            TouchZone.HEAD -> "💖" to Color(0xFFFF4081)
                            TouchZone.BELLY -> "✨" to Color(0xFFFFB300)
                            TouchZone.HANDS -> "⭐" to Color(0xFF64B5F6)
                            TouchZone.FEET -> "💫" to Color(0xFF81C784)
                        }
                        touchParticles.add(
                            TouchParticle(
                                id = System.currentTimeMillis() + Random.nextLong(1000),
                                x = offset.x,
                                y = offset.y,
                                symbol = symbol,
                                color = color
                            )
                        )
                    }
                )
            }
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val cx = w * 0.5f
            val cy = h * 0.52f

            // Character scale based on canvas size
            val baseScale = (w.coerceAtMost(h) / 420f).coerceIn(0.75f, 1.35f)

            // Dynamic y offset combining idle floating and feet jump
            val dynamicY = cy + idleFloatY + feetJump.value

            // 1. 3D Ambient Occlusion Shadow on floor
            val shadowWidth = 180f * baseScale * (1f - feetJump.value / 120f)
            val shadowHeight = 44f * baseScale * (1f - feetJump.value / 120f)
            val shadowY = cy + 180f * baseScale
            drawOval(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0x55000000), Color(0x15000000), Color.Transparent),
                    center = Offset(cx + tiltY.value * 1.5f, shadowY),
                    radius = shadowWidth * 0.55f
                ),
                topLeft = Offset(cx - shadowWidth * 0.5f + tiltY.value * 1.5f, shadowY - shadowHeight * 0.5f),
                size = Size(shadowWidth, shadowHeight)
            )

            // 2. Draw 3D Character with 3D tilt transformation
            val rotY = tiltY.value
            val rotX = tiltX.value

            // Perspective translation
            val offsetX3D = rotY * 1.8f
            val offsetY3D = -rotX * 1.2f

            translate(left = offsetX3D, top = offsetY3D) {
                // Apply subtle rotation
                rotate(degrees = rotY * 0.25f, pivot = Offset(cx, dynamicY)) {
                    // Draw species in 3D
                    draw3DCharacterModel(
                        species = species,
                        customization = customization,
                        emotion = emotion,
                        cx = cx,
                        cy = dynamicY,
                        scale = baseScale,
                        rotY = rotY,
                        rotX = rotX,
                        tailWag = tailWag,
                        isTalking = isTalking,
                        isBlinking = isBlinking,
                        mouthCycle = mouthCycle,
                        headBob = headBob.value,
                        bellyJiggle = bellyJiggle.value,
                        handsWave = handsWave.value
                    )
                }
            }

            // 3. Render Floating Touch Particles
            touchParticles.forEach { p ->
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(p.color.copy(alpha = 0.8f), Color.Transparent),
                        center = Offset(p.x, p.y),
                        radius = 28f
                    ),
                    radius = 28f,
                    center = Offset(p.x, p.y)
                )
                // Draw particle sparkles
                drawCircle(
                    color = Color.White,
                    radius = 4f,
                    center = Offset(p.x, p.y)
                )
            }
        }
    }
}

/**
 * Raycast hit detection that maps touch coordinates to one of 4 character zones:
 * HEAD, BELLY, HANDS, FEET
 */
private fun raycastTouchZone(offset: Offset, canvasW: Float, canvasH: Float): TouchZone {
    val cx = canvasW * 0.5f
    val cy = canvasH * 0.52f
    val dx = offset.x - cx
    val dy = offset.y - cy

    return when {
        // Upper area: Head & Ears
        dy < -35f -> TouchZone.HEAD
        // Lower area: Feet / lower paws
        dy > 120f -> TouchZone.FEET
        // Middle side area: Hands / Paws
        kotlin.math.abs(dx) > 65f -> TouchZone.HANDS
        // Middle center: Belly
        else -> TouchZone.BELLY
    }
}

/**
 * Complete 3D Stylized Character Model Renderer with Depth Shading
 */
private fun DrawScope.draw3DCharacterModel(
    species: PetSpecies,
    customization: AvatarCustomization,
    emotion: AvatarEmotion,
    cx: Float,
    cy: Float,
    scale: Float,
    rotY: Float,
    rotX: Float,
    tailWag: Float,
    isTalking: Boolean,
    isBlinking: Boolean,
    mouthCycle: Float,
    headBob: Float,
    bellyJiggle: Float,
    handsWave: Float
) {
    val fur = customization.furColor
    val furDark = fur.darken(0.30f)
    val furLight = fur.lighten(0.35f)
    val bellyColor = fur.lighten(0.55f)

    // 1. 3D Tail (behind body)
    draw3DTail(species, cx, cy, scale, fur, furDark, tailWag, rotY)

    // 2. 3D Body & Belly with depth shading
    val bodyW = (when (species) {
        PetSpecies.BEAR -> 170f
        PetSpecies.CAPYBARA -> 160f
        else -> 140f
    }) * scale
    val bodyH = (when (species) {
        PetSpecies.BEAR -> 160f
        PetSpecies.CAPYBARA -> 140f
        else -> 150f
    }) * scale
    val bodyX = cx - bodyW * 0.5f + bellyJiggle
    val bodyY = cy - 20f * scale

    // 3D Spherical body base
    drawOval(
        brush = Brush.radialGradient(
            colors = listOf(furLight, fur, furDark),
            center = Offset(cx - bodyW * 0.15f + rotY * 1.2f, bodyY + bodyH * 0.35f),
            radius = bodyW * 0.7f
        ),
        topLeft = Offset(bodyX, bodyY),
        size = Size(bodyW, bodyH)
    )

    // 3D Soft Belly patch
    val bellyW = bodyW * 0.62f
    val bellyH = bodyH * 0.68f
    drawOval(
        brush = Brush.radialGradient(
            colors = listOf(Color.White, bellyColor, fur),
            center = Offset(cx + rotY * 1.5f + bellyJiggle, bodyY + bodyH * 0.45f),
            radius = bellyW * 0.65f
        ),
        topLeft = Offset(cx - bellyW * 0.5f + rotY * 1.5f + bellyJiggle, bodyY + bodyH * 0.22f),
        size = Size(bellyW, bellyH)
    )

    // 3. 3D Feet / Lower Paws
    val footW = 42f * scale
    val footH = 34f * scale
    val footY = bodyY + bodyH - 22f * scale
    val footSpacing = (when (species) {
        PetSpecies.BEAR -> 60f
        PetSpecies.CAPYBARA -> 54f
        else -> 46f
    }) * scale

    // Left Foot
    drawOval(
        brush = Brush.radialGradient(
            colors = listOf(furLight, fur, furDark),
            center = Offset(cx - footSpacing, footY + footH * 0.3f),
            radius = footW * 0.7f
        ),
        topLeft = Offset(cx - footSpacing - footW * 0.5f, footY),
        size = Size(footW, footH)
    )
    // Right Foot
    drawOval(
        brush = Brush.radialGradient(
            colors = listOf(furLight, fur, furDark),
            center = Offset(cx + footSpacing, footY + footH * 0.3f),
            radius = footW * 0.7f
        ),
        topLeft = Offset(cx + footSpacing - footW * 0.5f, footY),
        size = Size(footW, footH)
    )

    // 4. 3D Head Base
    val headW = (when (species) {
        PetSpecies.CAPYBARA -> 150f
        PetSpecies.BEAR -> 155f
        else -> 145f
    }) * scale
    val headH = (when (species) {
        PetSpecies.CAPYBARA -> 135f
        PetSpecies.BEAR -> 138f
        else -> 130f
    }) * scale
    val headX = cx - headW * 0.5f + rotY * 1.5f
    val headY = cy - 130f * scale + headBob

    // 5. 3D Ears (drawn according to species)
    draw3DEars(species, cx, headY, headW, scale, fur, furDark, rotY, headBob)

    // 3D Spherical Head Shading
    drawOval(
        brush = Brush.radialGradient(
            colors = listOf(furLight, fur, furDark),
            center = Offset(cx - headW * 0.18f + rotY * 2f, headY + headH * 0.35f),
            radius = headW * 0.75f
        ),
        topLeft = Offset(headX, headY),
        size = Size(headW, headH)
    )

    // Rim light on head top
    drawOval(
        brush = Brush.radialGradient(
            colors = listOf(Color.White.copy(alpha = 0.45f), Color.Transparent),
            center = Offset(cx - headW * 0.2f, headY + 15f),
            radius = headW * 0.35f
        ),
        topLeft = Offset(headX + 10f, headY + 5f),
        size = Size(headW * 0.6f, headH * 0.35f)
    )

    // Capybara's signature Yuzu fruit on top of head!
    if (species == PetSpecies.CAPYBARA) {
        drawYuzuOnHead(cx + rotY * 1.5f, headY, scale)
    }

    // 6. Species-specific 3D Face Features (Snout, Whiskers, Nose, Eyes)
    draw3DFaceFeatures(
        species = species,
        cx = cx + rotY * 1.5f,
        headY = headY,
        headW = headW,
        headH = headH,
        scale = scale,
        fur = fur,
        emotion = emotion,
        isBlinking = isBlinking,
        isTalking = isTalking,
        mouthCycle = mouthCycle,
        rotY = rotY
    )

    // 7. 3D Hands / Front Paws
    val handW = 38f * scale
    val handH = 34f * scale
    val handY = cy + 24f * scale
    val handSpread = (when (species) {
        PetSpecies.BEAR -> 75f
        PetSpecies.CAPYBARA -> 68f
        else -> 60f
    }) * scale

    // Left hand
    val leftHandWaveOffset = if (handsWave > 0f) -handsWave * 1.5f else 0f
    drawOval(
        brush = Brush.radialGradient(
            colors = listOf(furLight, fur, furDark),
            center = Offset(cx - handSpread + rotY, handY + leftHandWaveOffset),
            radius = handW * 0.7f
        ),
        topLeft = Offset(cx - handSpread - handW * 0.5f, handY - handH * 0.5f + leftHandWaveOffset),
        size = Size(handW, handH)
    )

    // Right hand (waves when touched)
    val rightHandWaveOffset = if (handsWave > 0f) -handsWave * 2.2f else 0f
    drawOval(
        brush = Brush.radialGradient(
            colors = listOf(furLight, fur, furDark),
            center = Offset(cx + handSpread + rotY, handY + rightHandWaveOffset),
            radius = handW * 0.7f
        ),
        topLeft = Offset(cx + handSpread - handW * 0.5f, handY - handH * 0.5f + rightHandWaveOffset),
        size = Size(handW, handH)
    )
}

/**
 * 3D Tail drawing per species
 */
private fun DrawScope.draw3DTail(
    species: PetSpecies,
    cx: Float,
    cy: Float,
    scale: Float,
    fur: Color,
    furDark: Color,
    tailWag: Float,
    rotY: Float
) {
    when (species) {
        PetSpecies.CAT -> {
            // Elegant curved cat tail
            val tailBaseX = cx + 55f * scale + rotY
            val tailBaseY = cy + 65f * scale
            val tailPath = Path().apply {
                moveTo(tailBaseX, tailBaseY)
                quadraticTo(
                    tailBaseX + 45f * scale + tailWag * 1.8f,
                    tailBaseY - 40f * scale,
                    tailBaseX + 60f * scale + tailWag * 2.5f,
                    tailBaseY - 80f * scale
                )
            }
            drawPath(
                path = tailPath,
                color = furDark,
                style = Stroke(width = 16f * scale, cap = StrokeCap.Round)
            )
            drawPath(
                path = tailPath,
                color = fur,
                style = Stroke(width = 12f * scale, cap = StrokeCap.Round)
            )
        }
        PetSpecies.RABBIT -> {
            // Fluffy round cotton ball tail
            val tailX = cx + 58f * scale + rotY + tailWag * 0.3f
            val tailY = cy + 72f * scale
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(Color.White, Color(0xFFF0F0F0), Color(0xFFCCCCCC)),
                    center = Offset(tailX - 3f, tailY - 3f),
                    radius = 20f * scale
                ),
                radius = 18f * scale,
                center = Offset(tailX, tailY)
            )
        }
        PetSpecies.DOG -> {
            // Wagging dog tail
            val tailX = cx + 55f * scale + rotY
            val tailY = cy + 60f * scale
            val tailTipX = tailX + 40f * scale + tailWag * 2.2f
            val tailTipY = tailY - 50f * scale + kotlin.math.abs(tailWag) * 0.5f
            val dogTailPath = Path().apply {
                moveTo(tailX, tailY)
                quadraticTo(
                    tailX + 25f * scale + tailWag,
                    tailY - 20f * scale,
                    tailTipX,
                    tailTipY
                )
            }
            drawPath(
                path = dogTailPath,
                color = furDark,
                style = Stroke(width = 20f * scale, cap = StrokeCap.Round)
            )
            drawPath(
                path = dogTailPath,
                color = fur,
                style = Stroke(width = 15f * scale, cap = StrokeCap.Round)
            )
            // White tail tip
            drawCircle(color = Color.White, radius = 9f * scale, center = Offset(tailTipX, tailTipY))
        }
        PetSpecies.CAPYBARA -> {
            // Capybara tiny vestigial tail nub
            val tailX = cx + 64f * scale + rotY
            val tailY = cy + 70f * scale
            drawCircle(color = furDark, radius = 9f * scale, center = Offset(tailX, tailY))
        }
        PetSpecies.BEAR -> {
            // Cute round bear tail
            val tailX = cx + 68f * scale + rotY + tailWag * 0.4f
            val tailY = cy + 68f * scale
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(fur, furDark),
                    center = Offset(tailX - 4f, tailY - 4f),
                    radius = 18f * scale
                ),
                radius = 16f * scale,
                center = Offset(tailX, tailY)
            )
        }
    }
}

/**
 * 3D Ears drawing per species
 */
private fun DrawScope.draw3DEars(
    species: PetSpecies,
    cx: Float,
    headY: Float,
    headW: Float,
    scale: Float,
    fur: Color,
    furDark: Color,
    rotY: Float,
    headBob: Float
) {
    val earInnerPink = Color(0xFFFFB6C1)

    when (species) {
        PetSpecies.CAT -> {
            // Pointed 3D triangular cat ears
            val earW = 44f * scale
            val earH = 50f * scale
            // Left ear
            val leftEarPath = Path().apply {
                moveTo(cx - headW * 0.38f + rotY, headY + 30f * scale)
                lineTo(cx - headW * 0.42f + rotY - 10f * scale, headY - earH + 12f * scale)
                lineTo(cx - headW * 0.12f + rotY, headY + 10f * scale)
                close()
            }
            drawPath(path = leftEarPath, color = furDark)
            // Left inner ear
            val leftInner = Path().apply {
                moveTo(cx - headW * 0.35f + rotY, headY + 24f * scale)
                lineTo(cx - headW * 0.39f + rotY - 6f * scale, headY - earH + 22f * scale)
                lineTo(cx - headW * 0.16f + rotY, headY + 12f * scale)
                close()
            }
            drawPath(path = leftInner, color = earInnerPink)

            // Right ear
            val rightEarPath = Path().apply {
                moveTo(cx + headW * 0.12f + rotY, headY + 10f * scale)
                lineTo(cx + headW * 0.42f + rotY + 10f * scale, headY - earH + 12f * scale)
                lineTo(cx + headW * 0.38f + rotY, headY + 30f * scale)
                close()
            }
            drawPath(path = rightEarPath, color = furDark)
            val rightInner = Path().apply {
                moveTo(cx + headW * 0.16f + rotY, headY + 12f * scale)
                lineTo(cx + headW * 0.39f + rotY + 6f * scale, headY - earH + 22f * scale)
                lineTo(cx + headW * 0.35f + rotY, headY + 24f * scale)
                close()
            }
            drawPath(path = rightInner, color = earInnerPink)
        }
        PetSpecies.RABBIT -> {
            // Long flexible 3D bunny ears
            val earW = 34f * scale
            val earH = 110f * scale
            // Left bunny ear
            drawOval(
                brush = Brush.verticalGradient(listOf(fur, furDark)),
                topLeft = Offset(cx - headW * 0.32f + rotY - earW * 0.5f, headY - earH + 20f * scale),
                size = Size(earW, earH)
            )
            drawOval(
                color = earInnerPink,
                topLeft = Offset(cx - headW * 0.32f + rotY - earW * 0.3f, headY - earH + 30f * scale),
                size = Size(earW * 0.6f, earH * 0.75f)
            )

            // Right bunny ear
            drawOval(
                brush = Brush.verticalGradient(listOf(fur, furDark)),
                topLeft = Offset(cx + headW * 0.32f + rotY - earW * 0.5f, headY - earH + 20f * scale),
                size = Size(earW, earH)
            )
            drawOval(
                color = earInnerPink,
                topLeft = Offset(cx + headW * 0.32f + rotY - earW * 0.3f, headY - earH + 30f * scale),
                size = Size(earW * 0.6f, earH * 0.75f)
            )
        }
        PetSpecies.DOG -> {
            // Floppy curved 3D dog ears
            val earW = 42f * scale
            val earH = 68f * scale
            drawOval(
                brush = Brush.verticalGradient(listOf(furDark, fur)),
                topLeft = Offset(cx - headW * 0.48f + rotY, headY + 20f * scale),
                size = Size(earW, earH)
            )
            drawOval(
                brush = Brush.verticalGradient(listOf(furDark, fur)),
                topLeft = Offset(cx + headW * 0.48f + rotY - earW, headY + 20f * scale),
                size = Size(earW, earH)
            )
        }
        PetSpecies.CAPYBARA -> {
            // Small round cute capybara ears on side of head
            val earR = 18f * scale
            drawCircle(
                color = furDark,
                radius = earR,
                center = Offset(cx - headW * 0.44f + rotY, headY + 34f * scale)
            )
            drawCircle(
                color = Color(0xFF5D4037),
                radius = earR * 0.6f,
                center = Offset(cx - headW * 0.44f + rotY, headY + 34f * scale)
            )

            drawCircle(
                color = furDark,
                radius = earR,
                center = Offset(cx + headW * 0.44f + rotY, headY + 34f * scale)
            )
            drawCircle(
                color = Color(0xFF5D4037),
                radius = earR * 0.6f,
                center = Offset(cx + headW * 0.44f + rotY, headY + 34f * scale)
            )
        }
        PetSpecies.BEAR -> {
            // Big round cupped 3D bear ears
            val earR = 26f * scale
            // Left bear ear
            drawCircle(
                brush = Brush.radialGradient(listOf(fur, furDark)),
                radius = earR,
                center = Offset(cx - headW * 0.36f + rotY, headY + 12f * scale)
            )
            drawCircle(
                color = earInnerPink.copy(alpha = 0.85f),
                radius = earR * 0.55f,
                center = Offset(cx - headW * 0.36f + rotY, headY + 12f * scale)
            )

            // Right bear ear
            drawCircle(
                brush = Brush.radialGradient(listOf(fur, furDark)),
                radius = earR,
                center = Offset(cx + headW * 0.36f + rotY, headY + 12f * scale)
            )
            drawCircle(
                color = earInnerPink.copy(alpha = 0.85f),
                radius = earR * 0.55f,
                center = Offset(cx + headW * 0.36f + rotY, headY + 12f * scale)
            )
        }
    }
}

/**
 * Capybara's signature 3D Yuzu citrus fruit sitting on head!
 */
private fun DrawScope.drawYuzuOnHead(headCx: Float, headY: Float, scale: Float) {
    val yuzuR = 22f * scale
    val yuzuY = headY - 14f * scale

    // Yuzu shadow on head
    drawOval(
        color = Color(0x40000000),
        topLeft = Offset(headCx - yuzuR * 0.9f, yuzuY + yuzuR * 0.6f),
        size = Size(yuzuR * 1.8f, yuzuR * 0.7f)
    )

    // 3D Spherical Yuzu citrus
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(Color(0xFFFFF176), Color(0xFFFFD54F), Color(0xFFF57F17)),
            center = Offset(headCx - yuzuR * 0.3f, yuzuY - yuzuR * 0.3f),
            radius = yuzuR
        ),
        radius = yuzuR,
        center = Offset(headCx, yuzuY)
    )

    // Stem and green leaf
    drawCircle(color = Color(0xFF558B2F), radius = 3.5f * scale, center = Offset(headCx, yuzuY - yuzuR * 0.9f))
    val leafPath = Path().apply {
        moveTo(headCx, yuzuY - yuzuR * 0.9f)
        quadraticTo(headCx + 14f * scale, yuzuY - yuzuR * 1.5f, headCx + 18f * scale, yuzuY - yuzuR * 1.1f)
        quadraticTo(headCx + 10f * scale, yuzuY - yuzuR * 0.8f, headCx, yuzuY - yuzuR * 0.9f)
        close()
    }
    drawPath(path = leafPath, color = Color(0xFF7CB342))
}

/**
 * 3D Face Features (Eyes, Snout, Whiskers, Mouth) per species
 */
private fun DrawScope.draw3DFaceFeatures(
    species: PetSpecies,
    cx: Float,
    headY: Float,
    headW: Float,
    headH: Float,
    scale: Float,
    fur: Color,
    emotion: AvatarEmotion,
    isBlinking: Boolean,
    isTalking: Boolean,
    mouthCycle: Float,
    rotY: Float
) {
    val eyeY = headY + headH * 0.42f
    val eyeSpacing = (when (species) {
        PetSpecies.CAPYBARA -> 46f
        PetSpecies.BEAR -> 44f
        else -> 38f
    }) * scale

    // 1. Eyes
    if (isBlinking || emotion == AvatarEmotion.SLEEPY) {
        // Closed / sleepy curved lines
        val strokeW = 3.5f * scale
        drawLine(
            color = Color(0xFF263238),
            start = Offset(cx - eyeSpacing - 12f * scale, eyeY),
            end = Offset(cx - eyeSpacing + 12f * scale, eyeY),
            strokeWidth = strokeW,
            cap = StrokeCap.Round
        )
        drawLine(
            color = Color(0xFF263238),
            start = Offset(cx + eyeSpacing - 12f * scale, eyeY),
            end = Offset(cx + eyeSpacing + 12f * scale, eyeY),
            strokeWidth = strokeW,
            cap = StrokeCap.Round
        )
    } else {
        // Expressive 3D Eyes
        val eyeR = (if (species == PetSpecies.CAPYBARA) 11f else 14f) * scale
        // Left eye
        drawCircle(
            color = Color(0xFF1E293B),
            radius = eyeR,
            center = Offset(cx - eyeSpacing, eyeY)
        )
        // Eye specular highlights
        drawCircle(
            color = Color.White,
            radius = eyeR * 0.38f,
            center = Offset(cx - eyeSpacing - eyeR * 0.3f, eyeY - eyeR * 0.3f)
        )
        drawCircle(
            color = Color.White,
            radius = eyeR * 0.18f,
            center = Offset(cx - eyeSpacing + eyeR * 0.28f, eyeY + eyeR * 0.28f)
        )

        // Right eye
        drawCircle(
            color = Color(0xFF1E293B),
            radius = eyeR,
            center = Offset(cx + eyeSpacing, eyeY)
        )
        drawCircle(
            color = Color.White,
            radius = eyeR * 0.38f,
            center = Offset(cx + eyeSpacing - eyeR * 0.3f, eyeY - eyeR * 0.3f)
        )
        drawCircle(
            color = Color.White,
            radius = eyeR * 0.18f,
            center = Offset(cx + eyeSpacing + eyeR * 0.28f, eyeY + eyeR * 0.28f)
        )
    }

    // 2. 3D Muzzle / Snout Base
    val muzzleY = headY + headH * 0.58f
    when (species) {
        PetSpecies.CAPYBARA -> {
            // Blocky rounded capybara snout with nostrils
            val snoutW = 68f * scale
            val snoutH = 46f * scale
            drawRoundRect(
                brush = Brush.verticalGradient(listOf(Color(0xFF6D4C41), Color(0xFF4E342E))),
                topLeft = Offset(cx - snoutW * 0.5f, muzzleY - 6f * scale),
                size = Size(snoutW, snoutH),
                cornerRadius = CornerRadius(16f * scale, 16f * scale)
            )
            // Capybara nostrils
            drawOval(
                color = Color(0xFF271C19),
                topLeft = Offset(cx - 16f * scale, muzzleY + 8f * scale),
                size = Size(8f * scale, 6f * scale)
            )
            drawOval(
                color = Color(0xFF271C19),
                topLeft = Offset(cx + 8f * scale, muzzleY + 8f * scale),
                size = Size(8f * scale, 6f * scale)
            )
        }
        PetSpecies.BEAR -> {
            // Wide rounded bear muzzle
            val muzzleW = 66f * scale
            val muzzleH = 48f * scale
            drawOval(
                brush = Brush.radialGradient(
                    colors = listOf(Color(0xFFD7CCC8), Color(0xFFBCAAA4)),
                    center = Offset(cx, muzzleY + 12f * scale),
                    radius = muzzleW * 0.6f
                ),
                topLeft = Offset(cx - muzzleW * 0.5f, muzzleY - 4f * scale),
                size = Size(muzzleW, muzzleH)
            )
            // Big dark bear nose
            drawOval(
                color = Color(0xFF212121),
                topLeft = Offset(cx - 14f * scale, muzzleY),
                size = Size(28f * scale, 18f * scale)
            )
        }
        PetSpecies.DOG -> {
            // Rounded 3D dog snout
            val muzzleW = 60f * scale
            val muzzleH = 44f * scale
            drawOval(
                brush = Brush.radialGradient(
                    colors = listOf(Color.White, Color(0xFFFFF8E1), Color(0xFFFFECB3)),
                    center = Offset(cx, muzzleY + 10f * scale),
                    radius = muzzleW * 0.6f
                ),
                topLeft = Offset(cx - muzzleW * 0.5f, muzzleY - 4f * scale),
                size = Size(muzzleW, muzzleH)
            )
            // Wet black dog nose with shine
            drawOval(
                color = Color(0xFF1E293B),
                topLeft = Offset(cx - 12f * scale, muzzleY + 2f * scale),
                size = Size(24f * scale, 16f * scale)
            )
            drawCircle(
                color = Color.White.copy(alpha = 0.7f),
                radius = 3.5f * scale,
                center = Offset(cx - 4f * scale, muzzleY + 6f * scale)
            )
        }
        PetSpecies.CAT -> {
            // Cute small cat nose & whiskers
            drawOval(
                color = Color(0xFFFF8DA1),
                topLeft = Offset(cx - 9f * scale, muzzleY + 6f * scale),
                size = Size(18f * scale, 12f * scale)
            )
            // Whiskers
            val wColor = Color(0xFF455A64)
            val wStroke = 2f * scale
            // Left whiskers
            drawLine(wColor, Offset(cx - 20f * scale, muzzleY + 12f * scale), Offset(cx - 65f * scale, muzzleY + 6f * scale), wStroke, StrokeCap.Round)
            drawLine(wColor, Offset(cx - 20f * scale, muzzleY + 16f * scale), Offset(cx - 62f * scale, muzzleY + 22f * scale), wStroke, StrokeCap.Round)
            // Right whiskers
            drawLine(wColor, Offset(cx + 20f * scale, muzzleY + 12f * scale), Offset(cx + 65f * scale, muzzleY + 6f * scale), wStroke, StrokeCap.Round)
            drawLine(wColor, Offset(cx + 20f * scale, muzzleY + 16f * scale), Offset(cx + 62f * scale, muzzleY + 22f * scale), wStroke, StrokeCap.Round)
        }
        PetSpecies.RABBIT -> {
            // Soft pink twitchy rabbit nose
            drawOval(
                color = Color(0xFFFFB6C1),
                topLeft = Offset(cx - 8f * scale, muzzleY + 8f * scale),
                size = Size(16f * scale, 11f * scale)
            )
            // Rabbit whiskers
            val wColor = Color(0xFFB0BEC5)
            drawLine(wColor, Offset(cx - 15f * scale, muzzleY + 14f * scale), Offset(cx - 52f * scale, muzzleY + 10f * scale), 1.8f * scale, StrokeCap.Round)
            drawLine(wColor, Offset(cx + 15f * scale, muzzleY + 14f * scale), Offset(cx + 52f * scale, muzzleY + 10f * scale), 1.8f * scale, StrokeCap.Round)
        }
    }

    // 3. Mouth (talking open/close or smiling)
    val mouthY = muzzleY + 26f * scale
    if (isTalking) {
        val mouthHeight = 12f * scale * (0.3f + mouthCycle * 0.7f)
        drawOval(
            color = Color(0xFF880E4F),
            topLeft = Offset(cx - 11f * scale, mouthY - mouthHeight * 0.5f),
            size = Size(22f * scale, mouthHeight)
        )
        // Little tongue
        drawOval(
            color = Color(0xFFFF80AB),
            topLeft = Offset(cx - 6f * scale, mouthY + mouthHeight * 0.1f),
            size = Size(12f * scale, mouthHeight * 0.5f)
        )
    } else {
        // Gentle happy smile curve
        val smilePath = Path().apply {
            moveTo(cx - 12f * scale, mouthY)
            quadraticTo(cx, mouthY + 8f * scale, cx + 12f * scale, mouthY)
        }
        drawPath(path = smilePath, color = Color(0xFF37474F), style = Stroke(width = 2.5f * scale, cap = StrokeCap.Round))
    }
}

// Color extension helpers for 3D depth lighting
private fun Color.darken(factor: Float): Color = Color(
    red = (red * (1f - factor)).coerceIn(0f, 1f),
    green = (green * (1f - factor)).coerceIn(0f, 1f),
    blue = (blue * (1f - factor)).coerceIn(0f, 1f),
    alpha = alpha
)

private fun Color.lighten(factor: Float): Color = Color(
    red = (red + (1f - red) * factor).coerceIn(0f, 1f),
    green = (green + (1f - green) * factor).coerceIn(0f, 1f),
    blue = (blue + (1f - blue) * factor).coerceIn(0f, 1f),
    alpha = alpha
)
