package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = CoralOrangePrimaryDark,
    onPrimary = Color(0xFF431B00),
    primaryContainer = Color(0xFF6B2D00),
    onPrimaryContainer = Color(0xFFFFDBCF),
    secondary = MintSecondaryDark,
    onSecondary = Color(0xFF00382E),
    tertiary = SunGoldTertiaryDark,
    onTertiary = Color(0xFF402D00),
    background = DarkAppBackground,
    onBackground = Color(0xFFEDE0D9),
    surface = DarkSurface,
    onSurface = Color(0xFFEDE0D9),
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = Color(0xFFD6C3B9)
)

private val LightColorScheme = lightColorScheme(
    primary = CoralOrangePrimary,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFFDBCF),
    onPrimaryContainer = Color(0xFF381400),
    secondary = MintSecondary,
    onSecondary = Color.White,
    tertiary = SunGoldTertiary,
    onTertiary = Color(0xFF261900),
    background = CreamBackground,
    onBackground = Color(0xFF231A15),
    surface = WarmCardSurface,
    onSurface = Color(0xFF231A15),
    surfaceVariant = WarmCardSurfaceVariant,
    onSurfaceVariant = Color(0xFF51443D)
)

@Composable
fun PawPalTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Keep branded warm palette by default
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) = PawPalTheme(darkTheme = darkTheme, dynamicColor = dynamicColor, content = content)
