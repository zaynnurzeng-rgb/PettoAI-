package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Warm & Cozy Pet Avatar Palette
val CoralOrangePrimary = Color(0xFFFF6F3C)
val CoralOrangePrimaryDark = Color(0xFFFF9E79)

val MintSecondary = Color(0xFF2EAA8E)
val MintSecondaryDark = Color(0xFF72D4BD)

val SunGoldTertiary = Color(0xFFFFB703)
val SunGoldTertiaryDark = Color(0xFFFFD166)

val CreamBackground = Color(0xFFFFFDF8)
val WarmCardSurface = Color(0xFFFFFFFF)
val WarmCardSurfaceVariant = Color(0xFFF7F2EC)

val DarkAppBackground = Color(0xFF1A1715)
val DarkSurface = Color(0xFF26211E)
val DarkSurfaceVariant = Color(0xFF332D28)

// Semantic colors
val AffectionPink = Color(0xFFFF4081)
val EnergyBlue = Color(0xFF00B4D8)
val SuccessGreen = Color(0xFF4CAF50)
val PlayfulPurple = Color(0xFF8338EC)
