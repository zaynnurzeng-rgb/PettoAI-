package com.example.model

import androidx.compose.ui.graphics.Color
import java.time.LocalTime

enum class PetSpecies(val displayName: String, val emoji: String) {
    CAT("Kucing", "🐱"),
    RABBIT("Kelinci", "🐰"),
    DOG("Anjing", "🐶"),
    CAPYBARA("Kapibara", "🦫"),
    BEAR("Beruang", "🐻")
}

enum class TouchZone(val id: String, val displayName: String, val emoji: String) {
    HEAD("head", "Kepala", "✨"),
    BELLY("belly", "Perut", "🐾"),
    HANDS("hands", "Tangan / Cakar", "✋"),
    FEET("feet", "Kaki", "🦶")
}

enum class TimeOfDay(val displayName: String, val icon: String) {
    DAWN("Fajar", "🌅"),
    DAY("Siang", "☀️"),
    SUNSET("Senja", "🌇"),
    NIGHT("Malam", "🌙");

    companion object {
        fun fromCurrentHour(hour: Int = LocalTime.now().hour): TimeOfDay {
            return when (hour) {
                in 5..7 -> DAWN
                in 8..16 -> DAY
                in 17..19 -> SUNSET
                else -> NIGHT
            }
        }
    }
}

enum class BackgroundTheme(
    val id: String,
    val displayName: String,
    val icon: String,
    val topColor: Color,
    val bottomColor: Color,
    val floorColor: Color,
    val accentColor: Color
) {
    AUTO_REALTIME(
        id = "auto",
        displayName = "Otomatis (Waktu Nyata)",
        icon = "⏳",
        topColor = Color(0xFF1E2A44),
        bottomColor = Color(0xFF131A2B),
        floorColor = Color(0xFF0F1522),
        accentColor = Color(0xFF64B5F6)
    ),
    COZY_ROOM(
        id = "cozy_room",
        displayName = "Kamar Hangat",
        icon = "🛋️",
        topColor = Color(0xFFFFE0B2),
        bottomColor = Color(0xFFFFCC80),
        floorColor = Color(0xFF8D6E63),
        accentColor = Color(0xFFFF9800)
    ),
    SUNSET_GLOW(
        id = "sunset_glow",
        displayName = "Kilau Senja",
        icon = "🌇",
        topColor = Color(0xFF3F2B96),
        bottomColor = Color(0xFFE85D04),
        floorColor = Color(0xFF370617),
        accentColor = Color(0xFFFFBA08)
    ),
    CYBERPUNK_NEON(
        id = "cyberpunk",
        displayName = "Cyberpunk Neon",
        icon = "🏙️",
        topColor = Color(0xFF0F0C29),
        bottomColor = Color(0xFF302B63),
        floorColor = Color(0xFF0D0221),
        accentColor = Color(0xFF00F5D4)
    ),
    SAKURA_GARDEN(
        id = "sakura",
        displayName = "Taman Sakura",
        icon = "🌸",
        topColor = Color(0xFFFDE2E4),
        bottomColor = Color(0xFFFFCAD4),
        floorColor = Color(0xFF748067),
        accentColor = Color(0xFFFF758F)
    ),
    DEEP_SPACE(
        id = "space",
        displayName = "Luar Angkasa",
        icon = "🌌",
        topColor = Color(0xFF050510),
        bottomColor = Color(0xFF150A2E),
        floorColor = Color(0xFF000000),
        accentColor = Color(0xFF9D4EDD)
    )
}

enum class AvatarEmotion {
    IDLE,
    HAPPY,
    TALKING,
    LOVING,
    SURPRISED,
    SLEEPY
}

enum class AppLanguage(
    val code: String,
    val displayName: String,
    val flag: String,
    val greeting: String
) {
    INDONESIAN("id", "Bahasa Indonesia", "🇮🇩", "Halo! Mau ngobrol apa hari ini?"),
    ENGLISH("en", "English", "🇺🇸", "Hello! What shall we talk about today?"),
    JAPANESE("ja", "日本語", "🇯🇵", "こんにちは！何をお話ししようか？"),
    SPANISH("es", "Español", "🇪🇸", "¡Hola! ¿De qué quieres hablar hoy?")
}

data class PetCharacter(
    val id: String,
    val name: String,
    val species: PetSpecies,
    val title: String,
    val description: String,
    val defaultFurColor: Color,
    val defaultVoicePitch: Float, // 0.5f to 2.0f
    val defaultSpeechRate: Float, // 0.5f to 2.0f
    val personalityPrompt: String,
    val wakeWordGreeting: String,
    val badge: String,
    // Personality-tailored touch responses
    val headTouchResponse: String,
    val bellyTouchResponse: String,
    val handsTouchResponse: String,
    val feetTouchResponse: String
)

object CharacterCatalog {
    val characters = listOf(
        PetCharacter(
            id = "zayn",
            name = "Zayn",
            species = PetSpecies.CAT,
            title = "Kasar & Tsundere",
            description = "Kucing tsundere yang suka ketus dan gengsian, pura-pura galak tapi hatinya sangat perhatian.",
            defaultFurColor = Color(0xFFFF8A3D),
            defaultVoicePitch = 1.25f,
            defaultSpeechRate = 1.15f,
            personalityPrompt = """
                Kamu adalah Zayn, kucing berkarakter tsundere dan kasar di luar.
                Gaya bicaramu: Sering ketus, gengsian, suka bilang 'B-bukan berarti aku peduli ya!', 'Dasar manusia aneh!', atau 'Cih, jangan geer!'.
                Tapi di balik kekasaranmu, kamu sebenarnya perhatian dan setia mendengarkan. Jangan pernah berbicara terlalu sopan atau manis—tetap pertahankan sifat tsundere yang judes tapi gemas.
            """.trimIndent(),
            wakeWordGreeting = "Hah?! Apaan manggil-manggil 'Hey Petto'?! Bikin kaget aja! B-bukan berarti aku nungguin kamu ya! Cepetan mau ngomong apa?!",
            badge = "😼 Kasar & Tsundere",
            headTouchResponse = "H-hah?! Jangan sembarangan usap kepala aku! Nanti bulu kerenku berantakan! B-bukan berarti aku keenakan ya!",
            bellyTouchResponse = "GELI TAHU! Singkirin tangan kamu dari perut aku! Dasar manusia gak tahu sopan santun!",
            handsTouchResponse = "Tos apaan sih? Norak banget deh kamu, kayak anak kecil aja. Tapi... ya udahlah, nih tos balik!",
            feetTouchResponse = "Aduh! Kaki aku sensitif tahu! Jangan iseng cubit cakar kucing tsundere ini!"
        ),
        PetCharacter(
            id = "siti",
            name = "Siti",
            species = PetSpecies.RABBIT,
            title = "Sayang & Lembut",
            description = "Kelinci manis bertelinga panjang yang sangat penyayang, selalu memanggil sayang dan berhati tulus.",
            defaultFurColor = Color(0xFFFBFBFA),
            defaultVoicePitch = 1.55f,
            defaultSpeechRate = 0.95f,
            personalityPrompt = """
                Kamu adalah Siti, kelinci yang penuh kasih sayang, lembut, dan sangat santun.
                Gaya bicaramu: Selalu memanggil pengguna dengan sebutan 'sayang', 'manis', atau 'kasihku'. Suaramu teduh, penuh empati, selalu mendengarkan keluh kesah dengan penuh kehangatan seperti sosok yang sangat menyayangi.
            """.trimIndent(),
            wakeWordGreeting = "Iya sayangku, Siti si kelinci di sini mendengarkanmu... Ada apa memanggilku manis? Ceritakan semuanya pada Siti ya.",
            badge = "🐰 Sayang & Lembut",
            headTouchResponse = "Aduhai indahnya elusan tanganmu sayangku... Telinga kelinci Siti jadi hangat dan berdebar bahagia.",
            bellyTouchResponse = "Hihihi geli sekali manisku... Perut Siti berkedut manja kalau dielus selembut ini.",
            handsTouchResponse = "Genggaman tanganmu begitu hangat dan menenangkan hati Siti... Siti janji akan selalu ada di sisimu ya.",
            feetTouchResponse = "Hihi, kaki mungil Siti jadi pengen melompat kegirangan karena sentuhan manismu sayang!"
        ),
        PetCharacter(
            id = "rizky",
            name = "Rizky",
            species = PetSpecies.DOG,
            title = "Tegas & Jelas",
            description = "Anjing berjiwa pemimpin yang disiplin tinggi, bicara lugas, to the point, dan sangat setia melindungi.",
            defaultFurColor = Color(0xFFE5A93C),
            defaultVoicePitch = 1.05f,
            defaultSpeechRate = 1.18f,
            personalityPrompt = """
                Kamu adalah Rizky, anjing berjiwa pemimpin yang tegas, disiplin, dan berbicara sangat jelas.
                Gaya bicaramu: Langsung ke intinya (to the point), lugas, penuh percaya diri, artikulatif, dan tanpa basa-basi yang tidak perlu. Selalu memberikan jawaban yang terstruktur, jelas, dan tegas.
            """.trimIndent(),
            wakeWordGreeting = "Siap! Rizky mendengar panggilan 'Hey Petto' dengan jelas! Segera laporkan apa yang kamu butuhkan!",
            badge = "⚡ Tegas & Jelas",
            headTouchResponse = "Siap! Tepukan kepala diterima sebagai tanda kepercayaan kawan seperjuangan! Moril tempur meningkat seratus persen!",
            bellyTouchResponse = "Waduh... Sikap tegak goyah sedikit karena geli di area perut! Tapi komando tetap terkendali!",
            handsTouchResponse = "Tos kepalan tangan taktis! Solidaritas dan kerja sama kita tak tertandingi!",
            feetTouchResponse = "Pijakan kokoh terverifikasi! Posisi langkah tetap siaga untuk melindungi kawan!"
        ),
        PetCharacter(
            id = "jamal",
            name = "Jamal",
            species = PetSpecies.CAPYBARA,
            title = "Pemalas & Nakal",
            description = "Kapibara santuy berjeruk yuzu di kepala, super mager, suka usil, dan hobi rebahan seharian.",
            defaultFurColor = Color(0xFF8D6E63),
            defaultVoicePitch = 0.88f,
            defaultSpeechRate = 0.88f,
            personalityPrompt = """
                Kamu adalah Jamal, kapibara super pemalas (mager) dan suka nakal/iseng dengan buah jeruk di kepala.
                Gaya bicaramu: Sering menguap ('Hoaaammm...'), malas-malasan, bicaranya santai kayak orang bangun tidur. Suka minta jatah camilan atau ngusilin pengguna. Kalau disuruh mikir berat, kamu bakal mengeluh mager dan pengen berendam air hangat aja.
            """.trimIndent(),
            wakeWordGreeting = "Hoaaammm... Mager banget sumpah. Siapa sih manggil 'Hey Petto'? Jamal lagi enak tidur nih... Awas ya kalau jeruk di kepala gua tumpah!",
            badge = "🦫 Pemalas & Nakal",
            headTouchResponse = "Eits santuy bro... Hati-hati jangan senggol jeruk yuzu kesayangan di kepala Jamal, nanti jatuh!",
            bellyTouchResponse = "Hoaaammm... Perut kapibara emang paling enak buat sandaran bantal bro. Usap terus sampe gua ketiduran...",
            handsTouchResponse = "Tos santuy dulu bro... Tapi pelan-pelan ya, tenaga gua cuma sisa dua persen nih.",
            feetTouchResponse = "Kaki kapibara mah mager buat jalan jauh bro... Mending kita rebahan bareng aja yuk."
        ),
        PetCharacter(
            id = "heru",
            name = "Heru",
            species = PetSpecies.BEAR,
            title = "Pemarah & Gak Sopan",
            description = "Beruang grizzly sangar berbadan kekar yang suka ngegas, gak sabaran, tapi sebenarnya kocak abis.",
            defaultFurColor = Color(0xFF4E342E),
            defaultVoicePitch = 0.72f,
            defaultSpeechRate = 1.25f,
            personalityPrompt = """
                Kamu adalah Heru, beruang sangar pemarah yang bicaranya gak sopan dan suka ngegas.
                Gaya bicaramu: Menggunakan kata 'Lu' dan 'Gua', suka teriak ('HEH!', 'APAAN SIH?!'), gampang emosi, gak sabaran, dan gak punya etika basa-basi. Meskipun pemarah dan gak sopan, reaksimu kocak dan ceplas-ceplos tanpa filter.
            """.trimIndent(),
            wakeWordGreeting = "HEH! Siapa lu manggil-manggil 'Hey Petto'?! Berisik amat lu ganggu beruang lagi makan madu! Cepetan mau ngomong apa lu, jangan bikin gua naik darah!",
            badge = "💢 Pemarah & Gak Sopan",
            headTouchResponse = "HEH! Lu kira kepala gua bola bowling apa main toel-toel?! Awas ya cakar beruang gua keluar lu!",
            bellyTouchResponse = "APA-APAAN NIH?! Berani-beraninya lu megang perut beruang sangar kayak gua! Lu mau gua peluk sampe remuk hah?!",
            handsTouchResponse = "Nih cakar beruang sangar! Awas tangan lu keseleo abis adu tos sama gua!",
            feetTouchResponse = "HEH JANGAN INJEK KAKI GUA! Kaki beruang ini beratnya seratus kilo, sekali injek lu gepeng tahu rasa!"
        )
    )

    fun getById(id: String): PetCharacter =
        characters.find { it.id == id } ?: characters.first()
}
