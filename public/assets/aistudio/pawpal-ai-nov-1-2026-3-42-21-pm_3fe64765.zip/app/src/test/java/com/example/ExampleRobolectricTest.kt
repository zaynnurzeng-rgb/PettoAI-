package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.ai.GeminiChatService
import com.example.model.AppLanguage
import com.example.model.CharacterCatalog
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("PawPal AI", appName)
    }

    @Test
    fun `direct intent solves math accurately`() {
        val aiService = GeminiChatService()
        val zayn = CharacterCatalog.getById("zayn")
        val answer = aiService.trySolveDirectIntent("5 x 9 apa", zayn, AppLanguage.INDONESIAN)
        assertNotNull(answer)
        assertTrue(answer!!.contains("45"))
    }

    @Test
    fun `direct intent answers president of indonesia accurately`() {
        val aiService = GeminiChatService()
        val zayn = CharacterCatalog.getById("zayn")
        val siti = CharacterCatalog.getById("siti")
        val heru = CharacterCatalog.getById("heru")

        val zaynReply = aiService.trySolveDirectIntent("siapa presiden Indonesia", zayn, AppLanguage.INDONESIAN)
        assertNotNull(zaynReply)
        assertTrue(zaynReply!!.contains("Prabowo Subianto"))

        val sitiReply = aiService.trySolveDirectIntent("siapa presiden Indonesia sekarang", siti, AppLanguage.INDONESIAN)
        assertNotNull(sitiReply)
        assertTrue(sitiReply!!.contains("Prabowo Subianto"))

        val heruReply = aiService.trySolveDirectIntent("presiden ri siapa", heru, AppLanguage.INDONESIAN)
        assertNotNull(heruReply)
        assertTrue(heruReply!!.contains("Prabowo Subianto"))
    }

    @Test
    fun `compliment kamu cantik deh is recognized as compliment and not mistaken for question`() {
        val aiService = GeminiChatService()
        for (char in CharacterCatalog.characters) {
            val reply = aiService.getFastFallbackReply("kamu cantik deh", char, AppLanguage.INDONESIAN)
            assertNotNull(reply.text)
            // Must NOT think it's a question or reject it with "ngapain nanya"
            assertFalse(reply.text.contains("ngapain kamu nanya"))
            assertFalse(reply.text.contains("ngapain nanya-nanya"))

            when (char.id) {
                "zayn" -> assertTrue("Zayn should blush tsundere", reply.text.contains("H-hah") || reply.text.contains("merah") || reply.text.contains("baka"))
                "siti" -> assertTrue("Siti should be loving", reply.text.contains("sayang") || reply.text.contains("manis") || reply.text.contains("berdebar"))
                "rizky" -> assertTrue("Rizky should be disciplined", reply.text.contains("Siap") || reply.text.contains("apresiasi") || reply.text.contains("disiplin"))
                "jamal" -> assertTrue("Jamal should be cheeky and lazy", reply.text.contains("Jamal") || reply.text.contains("whiskas") || reply.text.contains("martabak"))
                "heru" -> assertTrue("Heru should be loud bulldog", reply.text.contains("HEH") || reply.text.contains("bulldog") || reply.text.contains("sangar") || reply.text.contains("ganteng"))
            }
        }
    }

    @Test
    fun `casual chatter statement is not treated as a question`() {
        val aiService = GeminiChatService()
        val heru = CharacterCatalog.getById("heru")
        val reply = aiService.getFastFallbackReply("hari ini hujan lebat banget di luar", heru, AppLanguage.INDONESIAN)
        assertNotNull(reply.text)
        assertFalse(reply.text.contains("ngapain nanya-nanya"))
    }

    @Test
    fun `touch zones generate valid responses for all characters`() {
        for (char in CharacterCatalog.characters) {
            assertNotNull(char.headTouchResponse)
            assertNotNull(char.bellyTouchResponse)
            assertNotNull(char.handsTouchResponse)
            assertNotNull(char.feetTouchResponse)
            assertTrue(char.headTouchResponse.isNotBlank())
            assertTrue(char.bellyTouchResponse.isNotBlank())
            assertTrue(char.handsTouchResponse.isNotBlank())
            assertTrue(char.feetTouchResponse.isNotBlank())
        }
    }

    @Test
    fun `audio synthesizer generates non-empty audio without crash`() {
        for (species in com.example.model.PetSpecies.values()) {
            for (zone in com.example.model.TouchZone.values()) {
                com.example.audio.ExpressiveAudioSynthesizer.playTouchReactionSound(species, zone)
            }
        }
    }
}
